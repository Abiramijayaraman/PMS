from datetime import date
from decimal import Decimal

from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.market_data import service
from app.modules.market_data.schemas import (
    SecurityPriceHistoryOut,
    BenchmarkPriceHistoryOut,
)


CUTOFF_DATE = date(2026, 9, 24)


def check(condition, message):
    if not condition:
        raise AssertionError(message)

    print(f"PASS: {message}")


def test_market_data():
    with get_connection() as conn:
        with conn.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Full HDFCBANK history
            prices = service.get_security_price_history(
                db=db,
                symbol="HDFCBANK",
            )

            check(len(prices) == 992,
                  "HDFCBANK returns 992 records")

            check(
                prices[0]["price_date"]
                == date(2022, 9, 26),
                "HDFCBANK earliest date is correct",
            )

            check(
                prices[-1]["price_date"] == CUTOFF_DATE,
                "HDFCBANK latest date matches cutoff",
            )

            check(
                all(
                    prices[i]["price_date"]
                    <= prices[i + 1]["price_date"]
                    for i in range(len(prices) - 1)
                ),
                "Security prices are date-ordered",
            )

            # 2. Security date-range filtering
            filtered = service.get_security_price_history(
                db=db,
                symbol="HDFCBANK",
                start_date=CUTOFF_DATE,
                end_date=CUTOFF_DATE,
            )

            check(
                len(filtered) == 1,
                "Same-day security filter returns one row",
            )

            check(
                filtered[0]["price_date"] == CUTOFF_DATE,
                "Security date filter returns requested date",
            )

            # 3. Unknown security
            unknown = service.get_security_price_history(
                db=db,
                symbol="NOT_A_REAL_SECURITY",
            )

            check(
                unknown == [],
                "Unknown security returns an empty list",
            )

            # 4. Full benchmark history
            benchmark = service.get_benchmark_price_history(
                db=db,
                benchmark_symbol="^NSEI",
            )

            check(
                len(benchmark) == 991,
                "NIFTY 50 returns 991 records",
            )

            check(
                benchmark[0]["price_date"]
                == date(2022, 9, 26),
                "Benchmark earliest date is correct",
            )

            check(
                benchmark[-1]["price_date"] == CUTOFF_DATE,
                "Benchmark latest date matches cutoff",
            )

            check(
                all(
                    benchmark[i]["price_date"]
                    <= benchmark[i + 1]["price_date"]
                    for i in range(len(benchmark) - 1)
                ),
                "Benchmark prices are date-ordered",
            )

            # 5. Benchmark date-range filtering
            benchmark_day = (
                service.get_benchmark_price_history(
                    db=db,
                    benchmark_symbol="^NSEI",
                    start_date=CUTOFF_DATE,
                    end_date=CUTOFF_DATE,
                )
            )

            check(
                len(benchmark_day) == 1,
                "Same-day benchmark filter returns one row",
            )

            # 6. Unknown benchmark
            unknown_benchmark = (
                service.get_benchmark_price_history(
                    db=db,
                    benchmark_symbol="NOT_A_BENCHMARK",
                )
            )

            check(
                unknown_benchmark == [],
                "Unknown benchmark returns an empty list",
            )

            # 7. Invalid date range
            try:
                service.get_security_price_history(
                    db=db,
                    symbol="HDFCBANK",
                    start_date=date(2026, 9, 25),
                    end_date=CUTOFF_DATE,
                )
            except ValueError:
                check(True, "Reversed date range is rejected")
            else:
                raise AssertionError(
                    "Reversed date range was not rejected"
                )

            # 8. Empty symbol
            try:
                service.get_security_price_history(
                    db=db,
                    symbol="   ",
                )
            except ValueError:
                check(True, "Blank security symbol is rejected")
            else:
                raise AssertionError(
                    "Blank security symbol was not rejected"
                )

            # 9. Pydantic schema validation
            security_model = SecurityPriceHistoryOut.model_validate(
                prices[0]
            )

            check(
                isinstance(security_model.close_price, Decimal),
                "Security schema preserves Decimal price",
            )

            benchmark_model = (
                BenchmarkPriceHistoryOut.model_validate(
                    benchmark[0]
                )
            )

            check(
                isinstance(
                    benchmark_model.close_price,
                    Decimal,
                ),
                "Benchmark schema preserves Decimal price",
            )

            # 10. Every active security has a cutoff price
            db.execute(
                """
                SELECT
                    s.symbol,
                    ph.price_date,
                    ph.close_price
                FROM securities AS s
                LEFT JOIN price_history AS ph
                    ON ph.security_id = s.security_id
                   AND ph.price_date = %s
                WHERE s.is_active = TRUE
                ORDER BY s.symbol;
                """,
                (CUTOFF_DATE,),
            )

            coverage = db.fetchall()

            check(
                len(coverage) == 22,
                "All 22 active securities are checked",
            )

            missing = [
                row["symbol"]
                for row in coverage
                if row["price_date"] is None
                or row["close_price"] is None
            ]

            check(
                not missing,
                "All active securities have a cutoff price"
                if not missing
                else f"Missing cutoff prices: {missing}",
            )

            # 11. Both tables share the cutoff
            db.execute(
                """
                SELECT
                    (SELECT MAX(price_date)
                     FROM price_history) AS latest_security_date,
                    (SELECT MAX(price_date)
                     FROM benchmark_history) AS latest_benchmark_date;
                """
            )

            latest = db.fetchone()

            check(
                latest["latest_security_date"] == CUTOFF_DATE,
                "Security history ends at cutoff",
            )

            check(
                latest["latest_benchmark_date"] == CUTOFF_DATE,
                "Benchmark history ends at cutoff",
            )

    print("\nAll Market Data checks passed.")


if __name__ == "__main__":
    test_market_data()