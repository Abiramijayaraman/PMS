import json
import getpass
import urllib.error
import urllib.request

BASE_URL = "http://127.0.0.1:8000"


def request_api(method, path, token=None, body=None):
    headers = {"Accept": "application/json"}

    if token:
        headers["Authorization"] = f"Bearer {token}"

    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")

    req = urllib.request.Request(
        BASE_URL + path,
        data=data,
        headers=headers,
        method=method,
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            return response.status, response.read().decode(
                "utf-8", errors="replace"
            )

    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode(
            "utf-8", errors="replace"
        )

    except Exception as exc:
        return 0, str(exc)


def main():
    print("\n=== PMS Write Validation Tests ===")

    email = input("Login email: ").strip()
    password = getpass.getpass("Login password: ")

    status, response = request_api(
        "POST",
        "/auth/login",
        body={"email": email, "password": password},
    )

    if not 200 <= status < 300:
        print(f"Login failed: HTTP {status}")
        print(response)
        return

    try:
        token = json.loads(response).get("access_token")
    except (json.JSONDecodeError, AttributeError):
        token = None

    if not token:
        print("Could not obtain access token.")
        print(response)
        return

    tests = [
        (
            "Create portfolio with empty body",
            "/portfolios",
            {},
        ),
        (
            "Create holding with empty body",
            "/portfolios/1/holdings",
            {},
        ),
        (
            "Create issuer with empty body",
            "/classification/issuers",
            {},
        ),
        (
            "Create classification with empty body",
            "/classification/classifications",
            {},
        ),
    ]

    passed = 0
    failed = 0

    for name, path, body in tests:
        status, response = request_api(
            "POST",
            path,
            token=token,
            body=body,
        )

        # These requests should fail request-body validation.
        ok = status == 422

        if ok:
            passed += 1
        else:
            failed += 1

        print(
            f"[{'PASS' if ok else 'FAIL'}] "
            f"{name}: HTTP {status}"
        )

        if not ok:
            print(f"       Response: {response[:500]}")

    print("\n=== Summary ===")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"Total : {passed + failed}")


if __name__ == "__main__":
    main()