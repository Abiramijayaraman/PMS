from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.performance import service as performance_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Fetch HDFCBANK details
            db.execute(
                """
                SELECT
                    s.security_id,
                    s.symbol,
                    s.asset_id,
                    ac.asset_class,
                    s.sector,
                    s.last_price
                FROM securities s
                JOIN asset_classes ac
                    ON ac.asset_id = s.asset_id
                WHERE s.security_id = %s
                """,
                (4,),
            )

            # Fetch the result only once
            security = db.fetchone()

            assert security is not None, (
                "HDFCBANK was not found"
            )

            assert security["last_price"] is not None, (
                "HDFCBANK has no current price"
            )

            current_price = Decimal(
                str(security["last_price"])
            )

            print("Security:", security["symbol"])
            print("Asset class:", security["asset_class"])
            print("Sector:", security["sector"])
            print("Current price:", current_price)

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_PERFORMANCE_SECTOR_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one HDFCBANK share
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=security["security_id"],
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            # 4. Get the sector breakdown
            # 4. Diagnose the inserted holding
            db.execute(
                """
                SELECT
                    h.portfolio_id,
                    h.security_id,
                    h.quantity,
                    s.symbol,
                    s.last_price,
                    s.sector,
                    ac.asset_class
                FROM holdings h
                JOIN securities s
                    ON s.security_id = h.security_id
                JOIN asset_classes ac
                    ON ac.asset_id = s.asset_id
                WHERE h.portfolio_id = %s
                """,
                (portfolio_id,),
            )

            print("\nDiagnostic: inserted holding")
            print(db.fetchall())

            # 5. Call the actual Performance service
            breakdown = performance_service.get_sector_breakdown(
                db, portfolio_id
            )

            print("\nPortfolio ID:", portfolio_id)
            print("Sector breakdown:")

            for row in breakdown:
                print(dict(row))

            # 5. Verify the Financials sector
            financials = next(
                (
                    row for row in breakdown
                    if row["sector"] == "Financials"
                ),
                None,
            )

            assert financials is not None, (
                "Financials sector was not returned"
            )

            actual_value = Decimal(
                str(financials["current_value"])
            )

            assert actual_value == current_price, (
                f"Expected sector value {current_price}, "
                f"got {actual_value}"
            )

            print(
                "\nPASS: Sector breakdown values are correct."
            )

    finally:
        # Roll back the temporary portfolio and holding
        connection.rollback()
        print("Test transaction rolled back.")