from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.market_data import service


with get_connection() as conn:
    with conn.cursor(cursor_factory=RealDictCursor) as db:

        # Test 1: HDFCBANK historical prices
        prices = service.get_security_price_history(
            db=db,
            symbol="HDFCBANK"
        )

        print("HDFCBANK records:", len(prices))
        print("First record:", prices[0] if prices else None)
        print("Last record:", prices[-1] if prices else None)

        # Test 2: NIFTY 50 benchmark history
        benchmark = service.get_benchmark_price_history(
            db=db,
            benchmark_symbol="^NSEI"
        )

        print("NIFTY 50 records:", len(benchmark))
        print("First record:", benchmark[0] if benchmark else None)
        print("Last record:", benchmark[-1] if benchmark else None)