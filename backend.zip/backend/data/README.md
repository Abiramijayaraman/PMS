Place the extracted DATA_PMS folder here for local development, or set DATA_DIR in .env. Keep raw source data unchanged. Do not commit if your repository policy excludes datasets.
