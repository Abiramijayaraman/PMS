from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.performance import service as performance_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Get the current NIFTYBEES price
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE security_id = %s
                """,
                (6,),
            )

            security = db.fetchone()

            assert security is not None, "NIFTYBEES not found"
            assert security["last_price"] is not None, (
                "NIFTYBEES has no current price"
            )

            current_price = Decimal(str(security["last_price"]))

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_PERFORMANCE_HISTORY_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one NIFTYBEES unit
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=6,
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            # 4. Call the actual Performance service
            result = performance_service.get_performance(
                db, portfolio_id
            )

            portfolio_series = result["portfolio_series"]
            benchmark_series = result["benchmark_series"]

            print("Portfolio ID:", portfolio_id)
            print("Portfolio history rows:", len(portfolio_series))
            print("Benchmark history rows:", len(benchmark_series))

            # 5. Verify both histories were returned
            assert portfolio_series, (
                "Portfolio history is empty"
            )

            assert benchmark_series, (
                "Benchmark history is empty"
            )

            # 6. Inspect the first and last portfolio records
            print("\nFirst portfolio record:")
            print(dict(portfolio_series[0]))

            print("\nLast portfolio record:")
            print(dict(portfolio_series[-1]))

            print("\nFirst benchmark record:")
            print(dict(benchmark_series[0]))

            print("\nLast benchmark record:")
            print(dict(benchmark_series[-1]))

            # 7. Verify chronological ordering
            portfolio_dates = [
                row["price_date"] for row in portfolio_series
            ]

            benchmark_dates = [
                row["price_date"] for row in benchmark_series
            ]

            assert portfolio_dates == sorted(portfolio_dates), (
                "Portfolio history is not chronological"
            )

            assert benchmark_dates == sorted(benchmark_dates), (
                "Benchmark history is not chronological"
            )

            print("\nPASS: Portfolio and benchmark histories returned.")

    finally:
        # Remove temporary portfolio and holding
        connection.rollback()
        print("Test transaction rolled back.")