-- =========================================================
-- SECURITIES MASTER — DEMO UNIVERSE
-- 15 NSE equities + 4 must-have non-equity instruments
-- =========================================================

-- ---- Equities (asset_code = EQUITY) ----
INSERT INTO securities (
    exchange, symbol, isin, security_name, asset_id,
    sector, industry, equity_category, country, currency
)
SELECT 'NSE', v.symbol, v.isin, v.name, a.asset_id,
       v.sector, v.industry, v.equity_category, 'India', 'INR'
FROM (VALUES
    ('RELIANCE',  'INE002A01018', 'Reliance Industries Ltd',            'Energy',     'Oil & Gas',         'LARGE_CAP'),
    ('HDFCBANK',  'INE040A01034', 'HDFC Bank Ltd',                      'Financials', 'Banking',           'LARGE_CAP'),
    ('ICICIBANK', 'INE090A01021', 'ICICI Bank Ltd',                     'Financials', 'Banking',           'LARGE_CAP'),
    ('INFY',      'INE009A01021', 'Infosys Ltd',                        'IT',         'IT Services',       'LARGE_CAP'),
    ('TCS',       'INE467B01029', 'Tata Consultancy Services Ltd',      'IT',         'IT Services',       'LARGE_CAP'),
    ('BHARTIARTL','INE397D01024', 'Bharti Airtel Ltd',                  'Telecom',    'Telecom Services',  'LARGE_CAP'),
    ('LT',        'INE018A01030', 'Larsen & Toubro Ltd',                'Industrials','Construction',      'LARGE_CAP'),
    ('ITC',       'INE154A01025', 'ITC Ltd',                            'Consumer',   'FMCG',              'LARGE_CAP'),
    ('SBIN',      'INE062A01020', 'State Bank of India',                'Financials', 'Banking',           'LARGE_CAP'),
    ('AXISBANK',  'INE238A01034', 'Axis Bank Ltd',                      'Financials', 'Banking',           'LARGE_CAP'),
    ('KOTAKBANK', 'INE237A01028', 'Kotak Mahindra Bank Ltd',            'Financials', 'Banking',           'LARGE_CAP'),
    ('MARUTI',    'INE585B01010', 'Maruti Suzuki India Ltd',            'Consumer',   'Automobile',        'LARGE_CAP'),
    ('SUNPHARMA', 'INE044A01036', 'Sun Pharmaceutical Industries Ltd',  'Healthcare', 'Pharmaceuticals',   'LARGE_CAP'),
    ('HCLTECH',   'INE860A01027', 'HCL Technologies Ltd',               'IT',         'IT Services',       'LARGE_CAP'),
    ('TITAN',     'INE280A01028', 'Titan Company Ltd',                  'Consumer',   'Consumer Durables', 'LARGE_CAP')
) AS v(symbol, isin, name, sector, industry, equity_category)
JOIN asset_classes a ON a.asset_code = 'EQUITY'
ON CONFLICT (exchange, symbol) DO NOTHING;

-- ---- Non-equity instruments (ISIN left NULL — verify before relying on it) ----
INSERT INTO securities (
    exchange, symbol, security_name, asset_id, sector, country, currency
)
SELECT 'NSE', v.symbol, v.name, a.asset_id, v.sector, 'India', 'INR'
FROM (VALUES
    ('NIFTYBEES',  'Nippon India ETF Nifty BeES',  'BROAD_ETF', 'Diversified'),
    ('GOLDBEES',   'Nippon India ETF Gold BeES',   'GOLD',      'Commodities'),
    ('LIQUIDBEES', 'Nippon India ETF Liquid BeES', 'DEBT',      'Money Market'),
    ('EMBASSY',    'Embassy Office Parks REIT',    'REIT',      'Real Estate')
) AS v(symbol, name, asset_code, sector)
JOIN asset_classes a ON a.asset_code = v.asset_code
ON CONFLICT (exchange, symbol) DO NOTHING;
