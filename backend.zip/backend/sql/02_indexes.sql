-- Portfolios displayed on the manager's home page
CREATE INDEX IF NOT EXISTS idx_portfolios_user_status
    ON portfolios (user_id, status, updated_at DESC);

-- Holdings grid for a selected portfolio
CREATE INDEX IF NOT EXISTS idx_holdings_portfolio
    ON holdings (portfolio_id, holding_id);

-- Security filters
CREATE INDEX IF NOT EXISTS idx_securities_asset
    ON securities (asset_id, is_active, symbol);

CREATE INDEX IF NOT EXISTS idx_securities_sector
    ON securities (sector, industry);

CREATE INDEX IF NOT EXISTS idx_securities_name
    ON securities (security_name);

-- Latest prices and date-range history
CREATE INDEX IF NOT EXISTS idx_price_history_date
    ON price_history (price_date, security_id);

CREATE INDEX IF NOT EXISTS idx_transactions_portfolio_date
    ON transactions (portfolio_id, txn_date DESC);

-- Recent data imports
CREATE INDEX IF NOT EXISTS idx_import_runs_started
    ON data_import_runs (started_at DESC);
