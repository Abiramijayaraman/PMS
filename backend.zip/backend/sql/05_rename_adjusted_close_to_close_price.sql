ALTER TABLE price_history
RENAME COLUMN adjusted_close TO close_price;

ALTER TABLE benchmark_history
RENAME COLUMN adjusted_close TO close_price;