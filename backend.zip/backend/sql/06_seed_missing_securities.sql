BEGIN;

INSERT INTO securities (
    exchange,
    symbol,
    security_name,
    asset_id
)
VALUES
    -- Equities (asset_id = 1)
    ('NSE', 'AXISBANK',  'Axis Bank',                         1),
    ('NSE', 'BHARTIARTL','Bharti Airtel',                     1),
    ('NSE', 'HCLTECH',  'HCL Technologies',                  1),
    ('NSE', 'ITC',      'ITC',                               1),
    ('NSE', 'KOTAKBANK','Kotak Mahindra Bank',               1),
    ('NSE', 'LT',       'Larsen & Toubro',                   1),
    ('NSE', 'MARUTI',   'Maruti Suzuki India',               1),
    ('NSE', 'SBIN',     'State Bank of India',               1),
    ('NSE', 'SUNPHARMA','Sun Pharmaceutical Industries',     1),
    ('NSE', 'TITAN',    'Titan Company',                     1),

    -- ETF (asset_id = 2)
    ('NSE', 'ITBEES',   'ITBEES',                             2),

    -- Fixed income ETF (asset_id = 5)
    ('NSE', 'EBBETF0430','EBBETF0430',                       5),

    -- REIT (asset_id = 4)
    ('NSE', 'MINDSPACE','Mindspace Business Parks REIT',     4)

ON CONFLICT (exchange, symbol) DO NOTHING;

COMMIT;