import csv
import json
import getpass
import urllib.error
import urllib.parse
import urllib.request
from datetime import date

BASE_URL = "http://127.0.0.1:8000"

# Update these IDs if your local database uses different ones.
PORTFOLIO_ID = 1
THEME_ID = 1
ISSUER_ID = 1

START_DATE = "2022-10-03"
END_DATE = date.today().isoformat()


def request_api(method, path, token=None, body=None):
    url = BASE_URL + path

    headers = {"Accept": "application/json"}

    if token:
        headers["Authorization"] = f"Bearer {token}"

    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=data,
        headers=headers,
        method=method,
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read().decode("utf-8", errors="replace")
            return response.status, raw

    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        return exc.code, raw

    except Exception as exc:
        return 0, str(exc)


def main():
    print("\n=== PMS API Regression Test ===")

    email = input("Login email: ").strip()
    password = getpass.getpass("Login password: ")

    # Login
    status, response = request_api(
        "POST",
        "/auth/login",
        body={"email": email, "password": password},
    )

    if status < 200 or status >= 300:
        print(f"\nLOGIN FAILED: HTTP {status}")
        print(response)
        return

    try:
        login_data = json.loads(response)
    except json.JSONDecodeError:
        print("Login response was not valid JSON.")
        print(response)
        return

    token = login_data.get("access_token")

    if not token:
        print("Could not find 'access_token' in login response.")
        print("Check the login response format.")
        return

    print("\nLogin successful. Running GET tests...\n")

    portfolio = f"/portfolios/{PORTFOLIO_ID}"
    encoded_benchmark = urllib.parse.quote("^NSEI", safe="")

    tests = [
        ("Health", "GET", "/health"),
        ("Portfolios list", "GET", "/portfolios"),
        ("Portfolio details", "GET", portfolio),
        ("Portfolio holdings", "GET", portfolio + "/holdings"),
        ("Portfolio budget", "GET", portfolio + "/budget"),
        ("Portfolio transactions", "GET", portfolio + "/transactions"),

        ("Security search", "GET",
         "/securities/search?q=RELIANCE"),

        ("Themes", "GET", "/themes"),
        ("Theme allocation", "GET",
         f"/themes/{THEME_ID}/allocation"),

        ("Asset classes", "GET", "/asset-classes"),
        ("Portfolio allocation", "GET", portfolio + "/allocation"),
        ("Portfolio performance", "GET", portfolio + "/performance"),
        ("Portfolio sector breakdown", "GET",
         portfolio + "/sector-breakdown"),
        ("Portfolio drift", "GET", portfolio + "/drift"),
        ("Rebalance preview", "GET",
         portfolio + "/rebalance/preview"),

        ("Security price history", "GET",
         "/market-data/securities/RELIANCE/history?"
         + urllib.parse.urlencode({
             "start_date": START_DATE,
             "end_date": END_DATE,
         })),

        ("Benchmark history", "GET",
         f"/market-data/benchmarks/{encoded_benchmark}/history?"
         + urllib.parse.urlencode({
             "start_date": START_DATE,
             "end_date": END_DATE,
         })),

        ("Database summary", "GET",
         "/data-quality/database-summary"),
        ("Duplicate counts", "GET",
         "/data-quality/duplicate-counts"),
        ("Price history coverage", "GET",
         "/data-quality/price-history-coverage"),
        ("Import runs", "GET",
         "/data-quality/import-runs?limit=10"),

        ("Issuer list", "GET", "/classification/issuers"),
        ("Issuer details", "GET",
         f"/classification/issuers/{ISSUER_ID}"),
        ("Issuer classifications", "GET",
         f"/classification/issuers/{ISSUER_ID}/classifications"),
    ]

    results = []

    # Authentication check: a protected route should reject no token.
    status, response = request_api("GET", "/portfolios")

    passed = status in (401, 403)
    results.append({
        "test": "Protected route rejects missing token",
        "status": status,
        "result": "PASS" if passed else "FAIL",
        "details": response[:500],
    })

    # Run the endpoint tests using the login token.
    for name, method, path in tests:
        status, response = request_api(method, path, token=token)

        passed = 200 <= status < 300

        results.append({
            "test": name,
            "status": status,
            "result": "PASS" if passed else "FAIL",
            "details": response[:500],
        })

        print(
            f"[{'PASS' if passed else 'FAIL'}] "
            f"{name:<38} HTTP {status}"
        )

        if not passed:
            print(f"       Response: {response[:300]}")

    # Save a CSV report.
    report_file = "regression_report.csv"

    with open(report_file, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=["test", "status", "result", "details"],
        )
        writer.writeheader()
        writer.writerows(results)

    passed_count = sum(r["result"] == "PASS" for r in results)
    failed_count = len(results) - passed_count

    print("\n=== Regression Summary ===")
    print(f"Total tests : {len(results)}")
    print(f"Passed      : {passed_count}")
    print(f"Failed      : {failed_count}")
    print(f"Report      : {report_file}")


if __name__ == "__main__":
    main()