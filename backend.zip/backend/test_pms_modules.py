"""
PMS module diagnostic tests.

Run from the backend directory:
    python -m pip install pytest
    python -m pytest -q test_pms_modules.py

These are SAFE unit/contract tests: they do not connect to PostgreSQL, mutate data,
or import the FastAPI application/router. Database integration tests should use a
dedicated test database and be added separately.
"""
import importlib
from decimal import Decimal
from unittest.mock import Mock

import pytest
from pydantic import ValidationError as PydanticValidationError


# ---------- Import / structure smoke tests ----------

MODULES = [
    "app.modules.portfolios.schemas",
    "app.modules.portfolios.repository",
    "app.modules.portfolios.service",
    "app.modules.holdings.schemas",
    "app.modules.holdings.repository",
    "app.modules.holdings.service",
    "app.modules.securities.schemas",
    "app.modules.securities.repository",
    "app.modules.securities.service",
    "app.modules.asset_classes.schemas",
    "app.modules.asset_classes.repository",
    "app.modules.asset_classes.service",
    "app.modules.themes.schemas",
    "app.modules.themes.repository",
    "app.modules.themes.service",
    "app.modules.performance.schemas",
    "app.modules.performance.repository",
    "app.modules.performance.service",
    "app.modules.rebalancing.schemas",
    "app.modules.rebalancing.repository",
    "app.modules.rebalancing.service",
    "app.modules.auth.schemas",
    "app.modules.auth.repository",
    "app.modules.auth.service",
    "app.modules.data_quality.repository",
    "app.modules.data_quality.service",
    "app.common.validation.dates",
    "app.common.validation.decimals",
    "app.common.validation.numbers",
    "app.common.validation.required",
    "app.common.validation.symbols",
]


@pytest.mark.parametrize("module_name", MODULES)
def test_module_imports(module_name):
    importlib.import_module(module_name)


# ---------- Shared validation ----------

def test_symbol_normalization_and_rejection():
    import pytest
    from app.common.validation.symbols import normalize_symbol

    assert normalize_symbol("  hdfcbank ") == "HDFCBANK"

    with pytest.raises(ValueError):
        normalize_symbol("^nsei")


def test_date_parser_contract():
    from datetime import date
    from app.common.validation.dates import parse_date
    assert parse_date("2026-09-26") == date(2026, 9, 26)
    with pytest.raises(ValueError):
        parse_date("26-Sep-2026")
    with pytest.raises(ValueError):
        parse_date("2026-02-30")


@pytest.mark.parametrize("value, expected", [
    ("125.50", Decimal("125.50")),
    (100, Decimal("100")),
    (Decimal("0.01"), Decimal("0.01")),
])
def test_decimal_parser_valid_values(value, expected):
    from app.common.validation.decimals import parse_decimal
    assert parse_decimal(value) == expected


@pytest.mark.parametrize("value", [True, 1.25, "NaN", "Infinity", "not-a-number"])
def test_decimal_parser_rejects_unsafe_values(value):
    from app.common.validation.decimals import parse_decimal
    with pytest.raises(ValueError):
        parse_decimal(value)


def test_require_positive_boundaries():
    from app.common.validation.numbers import require_positive
    assert require_positive("0.01") == Decimal("0.01")
    for value in ("0", "-1"):
        with pytest.raises(ValueError):
            require_positive(value)


def test_require_value_contract():
    from app.common.validation.required import require_value
    assert require_value(0, "amount") == 0
    assert require_value(False, "flag") is False
    for value in (None, "", "   "):
        with pytest.raises(ValueError):
            require_value(value, "field")


# ---------- Pydantic schema contracts ----------

def test_portfolio_create_validates_and_trims_name():
    from app.modules.portfolios.schemas import PortfolioCreate
    item = PortfolioCreate(
        portfolio_name="  Long Term  ",
        portfolio_type="AMOUNT",
        theme_id=1,
        rebalancing_frequency="MONTHLY",
        initial_investment="10000",
    )
    assert item.portfolio_name == "Long Term"
    assert item.initial_investment == Decimal("10000")


@pytest.mark.parametrize("overrides", [
    {"portfolio_name": "   "},
    {"portfolio_type": "INVALID"},
    {"theme_id": 0},
    {"rebalancing_frequency": "WEEKLY"},
    {"initial_investment": "0"},
    {"initial_investment": "-10"},
])
def test_portfolio_create_rejects_invalid_values(overrides):
    from app.modules.portfolios.schemas import PortfolioCreate
    data = dict(
        portfolio_name="Test",
        portfolio_type="AMOUNT",
        theme_id=1,
        rebalancing_frequency="MONTHLY",
        initial_investment="1000",
    )
    data.update(overrides)
    with pytest.raises(PydanticValidationError):
        PortfolioCreate(**data)


def test_holding_schema_boundaries():
    from app.modules.holdings.schemas import HoldingCreate, HoldingUpdate
    assert HoldingCreate(security_id=1, quantity="1", avg_price="0").avg_price == 0
    assert HoldingUpdate(quantity="0.5").quantity == Decimal("0.5")
    for data in (
        {"security_id": 0, "quantity": "1", "avg_price": "10"},
        {"security_id": 1, "quantity": "0", "avg_price": "10"},
        {"security_id": 1, "quantity": "1", "avg_price": "-1"},
    ):
        with pytest.raises(PydanticValidationError):
            HoldingCreate(**data)
    with pytest.raises(PydanticValidationError):
        HoldingUpdate(quantity=0)


def test_auth_login_schema_requires_valid_email():
    from app.modules.auth.schemas import LoginRequest
    with pytest.raises(PydanticValidationError):
        LoginRequest(email="not-an-email", password="x")
    assert LoginRequest(email="lana@example.com", password="x").password == "x"


# ---------- Service behavior with repositories mocked ----------

def test_portfolio_service_missing_get_raises_not_found(monkeypatch):
    from app.core.exceptions import NotFoundError
    from app.modules.portfolios import service, repository
    monkeypatch.setattr(repository, "get_portfolio", lambda db, pid: None)
    with pytest.raises(NotFoundError):
        service.get_portfolio_or_404(object(), 999999)


def test_portfolio_update_filters_none_fields(monkeypatch):
    from app.modules.portfolios import service, repository
    monkeypatch.setattr(repository, "get_portfolio", lambda db, pid: {"portfolio_id": pid})
    captured = {}
    def fake_update(db, pid, fields):
        captured.update(fields)
        return {"portfolio_id": pid, **fields}
    monkeypatch.setattr(repository, "update_portfolio", fake_update)
    result = service.update_portfolio(object(), 1, {"portfolio_name": "Updated", "benchmark_symbol": None})
    assert captured == {"portfolio_name": "Updated"}
    assert result["portfolio_name"] == "Updated"


def test_performance_services_reject_missing_portfolio(monkeypatch):
    from app.core.exceptions import NotFoundError
    from app.modules.portfolios import repository as portfolios_repository
    from app.modules.performance import service
    monkeypatch.setattr(service, "get_portfolio", lambda db, pid: None)
    for fn in (service.get_allocation, service.get_performance, service.get_sector_breakdown):
        with pytest.raises(NotFoundError):
            fn(object(), 999999)


def test_holding_add_rejects_missing_portfolio(monkeypatch):
    from app.core.exceptions import NotFoundError
    from app.modules.portfolios import repository as portfolios_repository
    from app.modules.holdings import service
    monkeypatch.setattr(service,"get_portfolio",lambda db, pid: None)
    with pytest.raises(NotFoundError):
        service.add_holding(object(), 999999, 1, Decimal("1"), Decimal("10"))


def test_holding_add_rejects_missing_security(monkeypatch):
    from app.core.exceptions import NotFoundError
    from app.modules.portfolios import repository as portfolios_repository
    from app.modules.holdings import service, repository as holdings_repository
    db = Mock()
    db.fetchone.return_value = None
    monkeypatch.setattr(portfolios_repository, "get_portfolio", lambda db, pid: {
        "portfolio_id": pid, "theme_id": 1, "initial_investment": Decimal("10000")
    })
    with pytest.raises(NotFoundError):
        service.add_holding(db, 1, 999999, Decimal("1"), Decimal("10"))


def test_holding_add_enforces_theme_budget(monkeypatch):
    from app.core.exceptions import ValidationError
    from app.modules.portfolios import repository as portfolios_repository
    from app.modules.holdings import service, repository as holdings_repository
    from app.modules.rebalancing import repository as rebalancing_repository
    db = Mock()
    db.fetchone.return_value = {"asset_id": 1}
    monkeypatch.setattr(service, "get_portfolio", lambda db, pid: {
        "portfolio_id": pid, "theme_id": 1, "initial_investment": Decimal("1000")
    })
    monkeypatch.setattr(holdings_repository, "get_theme_limit", lambda db, theme, asset: 20)
    monkeypatch.setattr(holdings_repository, "get_invested_value_by_asset_class", lambda db, pid: [])
    with pytest.raises(ValidationError):
        service.add_holding(db, 1, 1, Decimal("3"), Decimal("100"))


def test_security_service_delegates_search(monkeypatch):
    from app.modules.securities import service, repository
    expected = [{"symbol": "HDFCBANK"}]
    monkeypatch.setattr(repository, "search_securities", lambda db, q: expected)
    assert service.search(object(), "HDFC") == expected


def test_asset_class_service_delegates(monkeypatch):
    from app.modules.asset_classes import service, repository
    expected = [{"asset_id": 1, "asset_class": "Equity"}]
    monkeypatch.setattr(repository, "list_asset_classes", lambda db: expected)
    assert service.list_asset_classes(object()) == expected


def test_theme_service_delegates(monkeypatch):
    from app.modules.themes import service, repository
    expected = [{"theme_id": 1}]
    monkeypatch.setattr(repository, "list_themes", lambda db: expected)
    monkeypatch.setattr(repository, "get_theme_allocation", lambda db, tid: [{"asset_id": 1}])
    assert service.list_themes(object()) == expected
    assert service.get_theme_allocation(object(), 1) == [{"asset_id": 1}]


def test_rebalancing_rejects_missing_portfolio(monkeypatch):
    from app.core.exceptions import NotFoundError
    from app.modules.portfolios import repository as portfolios_repository
    from app.modules.rebalancing import service
    monkeypatch.setattr(service, "get_portfolio", lambda db, pid: None)
    with pytest.raises(NotFoundError):
        service.get_drift(object(), 999999)


def test_auth_login_rejects_unknown_user(monkeypatch):
    from app.core.exceptions import AuthError
    from app.modules.auth import service, repository
    monkeypatch.setattr(repository, "get_user_by_email", lambda db, email: None)
    with pytest.raises(AuthError):
        service.login(object(), "nobody@example.com", "wrong-password")


# ---------- Known structural gaps that should be visible ----------

def test_market_data_module_is_implemented():
    """
    This deliberately fails while market_data repository/service are placeholders.
    Once implemented, replace this assertion with behavior tests.
    """
    from app.modules import market_data
    from app.modules.market_data import repository, service
    assert repository.__file__ and service.__file__
    assert not hasattr(repository, "_Empty"), "market_data.repository is still a placeholder"
    assert not hasattr(service, "_Empty"), "market_data.service is still a placeholder"
