from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.rebalancing import service as rebalancing_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Get NIFTYBEES and its current price
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE symbol = %s
                """,
                ("NIFTYBEES",),
            )

            security = db.fetchone()

            assert security is not None, (
                "NIFTYBEES was not found"
            )
            assert security["last_price"] is not None, (
                "NIFTYBEES has no current price"
            )

            current_price = Decimal(
                str(security["last_price"])
            )

            print("Security:", security["symbol"])
            print("Current price:", current_price)

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_REBALANCING_DRIFT_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one NIFTYBEES unit
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=security["security_id"],
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            # 4. Calculate allocation drift
            drift = rebalancing_service.get_drift(
                db, portfolio_id
            )

            print("\nPortfolio ID:", portfolio_id)
            print("Drift result:")

            if isinstance(drift, list):
                for row in drift:
                    print(dict(row))
            else:
                print(drift)

            print("\nPASS: get_drift() returned successfully.")

    finally:
        # Undo temporary test data
        connection.rollback()
        print("Test transaction rolled back.")