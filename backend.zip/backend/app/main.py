from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.logging_config import configure_logging
from app.core.exceptions import NotFoundError, ValidationError, AuthError
from app.api.router import api_router

configure_logging()

app = FastAPI(title="Portfolio Management System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # Vite dev server
    allow_credentials=True,  # required so the httpOnly refresh cookie is sent
    allow_methods=["*"],
    allow_headers=["*"],
)

# Centralized error handling: services raise domain exceptions,
# routers never write try/except HTTPException blocks themselves.
@app.exception_handler(NotFoundError)
async def not_found_handler(request: Request, exc: NotFoundError):
    return JSONResponse(status_code=404, content={"detail": str(exc)})

@app.exception_handler(ValidationError)
async def validation_handler(request: Request, exc: ValidationError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})

@app.exception_handler(AuthError)
async def auth_handler(request: Request, exc: AuthError):
    return JSONResponse(status_code=401, content={"detail": str(exc)})

app.include_router(api_router)

@app.get("/health")
def health():
    return {"status": "ok"}
