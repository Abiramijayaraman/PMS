# Core cache adapter
Reserved for a small cache interface (get/set/delete/delete-by-prefix) and optional Redis implementation. Keep business modules independent of the Redis client. Implement only when the cache module is reached and dependency/configuration are approved.
