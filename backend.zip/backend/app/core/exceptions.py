"""Custom exceptions so services raise domain errors, not raw HTTPExceptions."""

class NotFoundError(Exception):
    def __init__(self, entity: str, identifier):
        self.entity = entity
        self.identifier = identifier
        super().__init__(f"{entity} {identifier} not found")

class ValidationError(Exception):
    """Raised for business-rule violations, e.g. theme allocation breached."""
    pass

class AuthError(Exception):
    """Raised for bad credentials or invalid/expired tokens."""
    pass
