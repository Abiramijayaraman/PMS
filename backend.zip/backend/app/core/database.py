"""
PostgreSQL connection pool + FastAPI dependencies.

Provides:
- A pooled PostgreSQL connection
- A database cursor dependency
- JWT bearer-token authentication for protected routes
"""

from contextlib import contextmanager

from psycopg2 import pool
from psycopg2.extras import RealDictCursor

from fastapi import Depends
from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials,
)

from app.core.config import settings
from app.common.security_utils import decode_token
from app.core.exceptions import AuthError


# --------------------------------------------------
# PostgreSQL Connection Pool
# --------------------------------------------------

_pool = pool.ThreadedConnectionPool(
    minconn=1,
    maxconn=10,
    dsn=settings.database_url,
)


@contextmanager
def get_connection():
    """
    Get a connection from the pool and return it
    after the operation completes.

    Commit on success and rollback on failure.
    """
    conn = _pool.getconn()

    try:
        yield conn
        conn.commit()

    except Exception:
        conn.rollback()
        raise

    finally:
        _pool.putconn(conn)


# --------------------------------------------------
# Database Dependency
# --------------------------------------------------

def get_db():
    """
    FastAPI dependency.

    Provides a RealDictCursor so database rows are
    returned as dictionaries.
    """
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            yield cur


# --------------------------------------------------
# Authentication Dependency
# --------------------------------------------------

# Registers HTTP Bearer authentication with FastAPI.
# This enables the Authorize button in Swagger UI.
_bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(
        _bearer_scheme
    ),
    db=Depends(get_db),
) -> dict:
    """
    Read the Bearer token from the Authorization header,
    validate the JWT, and return the authenticated user.

    Protected routes use:
        user = Depends(get_current_user)
    """

    # 1. Ensure a bearer token was provided
    if credentials is None:
        raise AuthError("Missing bearer token")

    # 2. Extract the token (without the 'Bearer' prefix)
    token = credentials.credentials

    # 3. Decode and validate the JWT
    payload = decode_token(token)

    # 4. Ensure this is an access token, not a refresh token
    if payload.get("type") != "access":
        raise AuthError("Not an access token")

    # 5. Extract the user ID from the token
    user_id = int(payload["sub"])

    # 6. Fetch the authenticated user from PostgreSQL
    db.execute(
        """
        SELECT user_id, name, email, role
        FROM users
        WHERE user_id = %s
        """,
        (user_id,),
    )

    user = db.fetchone()

    # 7. Ensure the user exists
    if not user:
        raise AuthError("User not found")

    # 8. Return the authenticated user
    return user