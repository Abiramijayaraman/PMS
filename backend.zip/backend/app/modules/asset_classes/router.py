from fastapi import APIRouter, Depends
from app.core.database import get_db, get_current_user
from app.modules.asset_classes import service

router = APIRouter()

@router.get("")
def list_asset_classes(db=Depends(get_db), user=Depends(get_current_user)):
    return service.list_asset_classes(db)
