from pydantic import BaseModel

class AssetClassOut(BaseModel):
    asset_id: int
    asset_class: str
    risk: str | None
