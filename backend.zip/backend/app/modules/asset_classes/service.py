from app.modules.asset_classes import repository

def list_asset_classes(db) -> list:
    return repository.list_asset_classes(db)
