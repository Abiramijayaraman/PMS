def list_asset_classes(db) -> list:
    db.execute("SELECT * FROM asset_classes WHERE is_active = TRUE ORDER BY asset_class")
    return db.fetchall()
