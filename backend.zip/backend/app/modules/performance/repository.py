"""
Repository queries for portfolio performance and analytics.

Uses the existing psycopg2 database wrapper:
    db.execute(...)
    db.fetchall()

No database writes are performed by this module.
"""


def get_allocation_vs_target(db, portfolio_id: int) -> list:
    """
    Return all asset classes in the portfolio's investment theme.

    Asset classes with no current holdings are included with
    current_value = 0.
    """
    db.execute(
        """
        WITH current_values AS (
            SELECT
                s.asset_id,
                SUM(
                    h.quantity * COALESCE(s.last_price, 0)
                ) AS current_value
            FROM holdings h
            JOIN securities s
                ON s.security_id = h.security_id
            WHERE h.portfolio_id = %s
            GROUP BY s.asset_id
        )
        SELECT
            ac.asset_id,
            ac.asset_class,
            COALESCE(cv.current_value, 0) AS current_value,
            ta.allocation_pct AS target_pct
        FROM portfolios p
        JOIN theme_allocation ta
            ON ta.theme_id = p.theme_id
        JOIN asset_classes ac
            ON ac.asset_id = ta.asset_id
        LEFT JOIN current_values cv
            ON cv.asset_id = ac.asset_id
        WHERE p.portfolio_id = %s
        ORDER BY ac.asset_class
        """,
        (portfolio_id, portfolio_id),
    )
    return db.fetchall()


def get_portfolio_value_series(db, portfolio_id: int) -> list:
    """
    Reconstruct historical portfolio value.

    Assumptions:
    1. Current holdings reflect the net effect of recorded transactions.
    2. Transactions on a date affect that day's closing valuation.
    3. For securities without transactions, holdings.as_of_date is
       the date from which the current quantity is held.
    4. A valuation date is returned only when a price is available
       for every security in the portfolio's security universe.
    """
    db.execute(
        """
        WITH portfolio_info AS (
            SELECT
                portfolio_id,
                inception_date
            FROM portfolios
            WHERE portfolio_id = %s
        ),

        portfolio_securities AS (
            SELECT security_id
            FROM holdings
            WHERE portfolio_id = %s

            UNION

            SELECT security_id
            FROM transactions
            WHERE portfolio_id = %s
        ),

        post_inception_transactions AS (
            SELECT
                t.security_id,
                t.txn_id,
                t.txn_date,
                CASE
                    WHEN t.action = 'BUY' THEN t.quantity
                    WHEN t.action = 'SELL' THEN -t.quantity
                    ELSE 0
                END AS quantity_change
            FROM transactions t
            CROSS JOIN portfolio_info pi
            WHERE t.portfolio_id = pi.portfolio_id
              AND t.txn_date >= pi.inception_date
        ),

        transaction_totals AS (
            SELECT
                security_id,
                SUM(quantity_change) AS net_quantity
            FROM post_inception_transactions
            GROUP BY security_id
        ),

        opening_positions AS (
            SELECT
                ps.security_id,

                CASE
                    WHEN COALESCE(tt.net_quantity, 0) <> 0
                      OR EXISTS (
                          SELECT 1
                          FROM post_inception_transactions pt
                          WHERE pt.security_id = ps.security_id
                      )
                    THEN COALESCE(h.quantity, 0)
                         - COALESCE(tt.net_quantity, 0)
                    ELSE COALESCE(h.quantity, 0)
                END AS opening_quantity,

                CASE
                    WHEN EXISTS (
                        SELECT 1
                        FROM post_inception_transactions pt
                        WHERE pt.security_id = ps.security_id
                    )
                    THEN pi.inception_date
                    ELSE COALESCE(h.as_of_date, pi.inception_date)
                END AS effective_date

            FROM portfolio_securities ps
            CROSS JOIN portfolio_info pi
            LEFT JOIN holdings h
                ON h.portfolio_id = pi.portfolio_id
               AND h.security_id = ps.security_id
            LEFT JOIN transaction_totals tt
                ON tt.security_id = ps.security_id
        ),

        valuation_dates AS (
            SELECT DISTINCT ph.price_date
            FROM price_history ph
            JOIN portfolio_securities ps
                ON ps.security_id = ph.security_id
            CROSS JOIN portfolio_info pi
            WHERE ph.price_date >= pi.inception_date
        ),

        daily_positions AS (
            SELECT
                vd.price_date,
                ps.security_id,

                CASE
                    WHEN vd.price_date < op.effective_date
                    THEN 0
                    ELSE op.opening_quantity
                END
                +
                COALESCE(
                    (
                        SELECT SUM(pt.quantity_change)
                        FROM post_inception_transactions pt
                        WHERE pt.security_id = ps.security_id
                          AND pt.txn_date <= vd.price_date
                    ),
                    0
                ) AS quantity_held

            FROM valuation_dates vd
            CROSS JOIN portfolio_securities ps
            JOIN opening_positions op
                ON op.security_id = ps.security_id
        ),

        daily_valuations AS (
            SELECT
                dp.price_date,
                dp.security_id,
                dp.quantity_held,
                latest_price.close_price
            FROM daily_positions dp
            LEFT JOIN LATERAL (
                SELECT ph.close_price
                FROM price_history ph
                WHERE ph.security_id = dp.security_id
                  AND ph.price_date <= dp.price_date
                ORDER BY ph.price_date DESC
                LIMIT 1
            ) latest_price ON TRUE
        )

        SELECT
            price_date,
            SUM(quantity_held * close_price) AS portfolio_value
        FROM daily_valuations
        GROUP BY price_date
        HAVING COUNT(close_price) = COUNT(*)
        ORDER BY price_date
        """,
        (
            portfolio_id,
            portfolio_id,
            portfolio_id,
        ),
    )
    return db.fetchall()


def get_benchmark_series(db, benchmark_symbol: str) -> list:
    """
    Return the selected benchmark's historical closing prices.
    """
    db.execute(
        """
        SELECT
            price_date,
            close_price
        FROM benchmark_history
        WHERE benchmark_symbol = %s
        ORDER BY price_date
        """,
        (benchmark_symbol,),
    )
    return db.fetchall()


def get_sector_breakdown(db, portfolio_id: int) -> list:
    """
    Return equity holdings grouped by their currently effective
    GICS sector.

    Uses at most one classification per issuer to prevent duplicate
    valuation totals when classification records overlap.
    """
    db.execute(
        """
        WITH current_classification AS (
            SELECT DISTINCT ON (gc.issuer_id)
                gc.issuer_id,
                gc.gics_sector_code
            FROM issuer_gics_classifications gc
            WHERE gc.effective_from <= CURRENT_DATE
              AND (
                  gc.effective_to IS NULL
                  OR gc.effective_to >= CURRENT_DATE
              )
            ORDER BY
                gc.issuer_id,
                gc.effective_from DESC,
                gc.classification_id DESC
        ),

        equity_values AS (
            SELECT
                COALESCE(
                    cc.gics_sector_code,
                    'Unclassified'
                ) AS sector_code,

                SUM(
                    h.quantity * COALESCE(s.last_price, 0)
                ) AS current_value

            FROM holdings h
            JOIN securities s
                ON s.security_id = h.security_id
            JOIN asset_classes ac
                ON ac.asset_id = s.asset_id
            LEFT JOIN current_classification cc
                ON cc.issuer_id = s.issuer_id

            WHERE h.portfolio_id = %s
              AND ac.asset_class = 'Equity'

            GROUP BY
                COALESCE(
                    cc.gics_sector_code,
                    'Unclassified'
                )
        )

        SELECT
            CASE sector_code
                WHEN '10' THEN 'Energy'
                WHEN '15' THEN 'Materials'
                WHEN '20' THEN 'Industrials'
                WHEN '25' THEN 'Consumer Discretionary'
                WHEN '30' THEN 'Consumer Staples'
                WHEN '35' THEN 'Health Care'
                WHEN '40' THEN 'Financials'
                WHEN '45' THEN 'Information Technology'
                WHEN '50' THEN 'Communication Services'
                WHEN '55' THEN 'Utilities'
                WHEN '60' THEN 'Real Estate'
                ELSE sector_code
            END AS sector,

            current_value

        FROM equity_values
        ORDER BY current_value DESC
        """,
        (portfolio_id,),
    )
    return db.fetchall()