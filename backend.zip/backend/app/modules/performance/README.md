INR portfolio value and benchmark comparison calculations.

Implementation will be added module-by-module after the plan is confirmed.
