from pydantic import BaseModel
from decimal import Decimal
from datetime import date

class AllocationRow(BaseModel):
    asset_class: str
    current_value: Decimal
    target_pct: Decimal
