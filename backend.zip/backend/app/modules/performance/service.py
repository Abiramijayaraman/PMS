from app.modules.performance import repository
from app.modules.portfolios.repository import get_portfolio
from app.core.exceptions import NotFoundError


def get_allocation(db, portfolio_id: int) -> list:
    portfolio = get_portfolio(db, portfolio_id)

    if portfolio is None:
        raise NotFoundError("Portfolio", portfolio_id)

    return repository.get_allocation_vs_target(
        db, portfolio_id
    )


def get_performance(db, portfolio_id: int) -> dict:
    portfolio = get_portfolio(db, portfolio_id)

    if portfolio is None:
        raise NotFoundError("Portfolio", portfolio_id)

    return {
        "portfolio_series": repository.get_portfolio_value_series(
            db, portfolio_id
        ),
        "benchmark_series": repository.get_benchmark_series(
            db, portfolio["benchmark_symbol"]
        ),
    }


def get_sector_breakdown(db, portfolio_id: int) -> list:
    portfolio = get_portfolio(db, portfolio_id)

    if portfolio is None:
        raise NotFoundError("Portfolio", portfolio_id)

    return repository.get_sector_breakdown(
        db, portfolio_id
    )