from fastapi import APIRouter, Depends
from app.core.database import get_db, get_current_user
from app.modules.performance import service

router = APIRouter()

@router.get("/{portfolio_id}/allocation")
def get_allocation(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.get_allocation(db, portfolio_id)

@router.get("/{portfolio_id}/performance")
def get_performance(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.get_performance(db, portfolio_id)

@router.get("/{portfolio_id}/sector-breakdown")
def get_sector_breakdown(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.get_sector_breakdown(db, portfolio_id)
