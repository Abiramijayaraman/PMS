from datetime import date, datetime
from pydantic import BaseModel


class IssuerOut(BaseModel):
    issuer_id: int
    issuer_name: str
    country: str | None
    created_at: datetime

class IssuerClassificationOut(BaseModel):
    classification_id: int
    issuer_id: int
    gics_sector_code: str
    gics_industry_group_code: str
    gics_industry_code: str
    gics_sub_industry_code: str
    source: str
    effective_from: date
    effective_to: date | None
    created_at: datetime

class IssuerCreate(BaseModel):
    issuer_name: str
    country: str = "India"

class ClassificationCreate(BaseModel):
    issuer_id: int
    security_id: int
    gics_sector_code: str
    gics_industry_group_code: str
    gics_industry_code: str
    gics_sub_industry_code: str
    source: str
    effective_from: date