def list_issuers(db) -> list:
    db.execute("SELECT issuer_id, issuer_name, country, created_at FROM issuers ORDER BY issuer_name")
    return db.fetchall()

def get_issuer_by_id(db, issuer_id: int):
    db.execute("SELECT issuer_id, issuer_name, country, created_at FROM issuers WHERE issuer_id = %s", (issuer_id,))
    return db.fetchone()

def list_issuer_classifications(db, issuer_id: int) -> list:
    db.execute(
        """
        SELECT classification_id, issuer_id, gics_sector_code, gics_industry_group_code,
               gics_industry_code, gics_sub_industry_code, source, effective_from, effective_to, created_at
        FROM issuer_gics_classifications
        WHERE issuer_id = %s
        ORDER BY effective_from DESC, classification_id DESC
        """,
        (issuer_id,),
    )
    return db.fetchall()

def insert_issuer(db, issuer_name: str, country: str = "India") -> dict:
    db.execute(
        "INSERT INTO issuers (issuer_name, country) VALUES (%s, %s) ON CONFLICT (issuer_name, country) DO NOTHING RETURNING *",
        (issuer_name, country),
    )
    row = db.fetchone()
    if row:
        return row
    db.execute("SELECT * FROM issuers WHERE issuer_name = %s AND country = %s", (issuer_name, country))
    return db.fetchone()

def insert_classification(db, issuer_id, sector_code, industry_group_code, industry_code, sub_industry_code, source, effective_from):
    db.execute(
        "UPDATE issuer_gics_classifications SET effective_to = %s WHERE issuer_id = %s AND effective_to IS NULL",
        (effective_from, issuer_id),
    )
    db.execute(
        """
        INSERT INTO issuer_gics_classifications
            (issuer_id, gics_sector_code, gics_industry_group_code, gics_industry_code, gics_sub_industry_code, source, effective_from)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        RETURNING *
        """,
        (issuer_id, sector_code, industry_group_code, industry_code, sub_industry_code, source, effective_from),
    )
    return db.fetchone()

def link_security_to_issuer(db, security_id: int, issuer_id: int):
    db.execute("UPDATE securities SET issuer_id = %s WHERE security_id = %s", (issuer_id, security_id))

def get_security_asset_class(db, security_id: int):
    db.execute(
        "SELECT ac.asset_class FROM securities s JOIN asset_classes ac ON ac.asset_id = s.asset_id WHERE s.security_id = %s",
        (security_id,),
    )
    return db.fetchone()