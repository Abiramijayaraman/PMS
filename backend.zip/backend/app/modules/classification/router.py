from fastapi import APIRouter, Depends, HTTPException, status

from app.core.database import get_db, get_current_user
from app.modules.classification import service
from app.modules.classification.schemas import (
    IssuerOut,
    IssuerClassificationOut,
    IssuerCreate,
    ClassificationCreate,
)

router = APIRouter()


@router.get(
    "/issuers",
    response_model=list[IssuerOut],
)
def list_issuers(
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.list_issuers(db)


@router.get(
    "/issuers/{issuer_id}",
    response_model=IssuerOut,
)
def get_issuer(
    issuer_id: int,
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    issuer = service.get_issuer(db, issuer_id)

    if not issuer:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Issuer not found",
        )

    return issuer


@router.post(
    "/issuers",
    response_model=IssuerOut,
    status_code=status.HTTP_201_CREATED,
)
def create_issuer(
    body: IssuerCreate,
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.create_issuer(
        db=db,
        issuer_name=body.issuer_name.strip(),
        country=body.country.strip(),
    )


@router.get(
    "/issuers/{issuer_id}/classifications",
    response_model=list[IssuerClassificationOut],
)
def list_issuer_classifications(
    issuer_id: int,
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    issuer = service.get_issuer(db, issuer_id)

    if not issuer:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Issuer not found",
        )

    return service.list_classifications(db, issuer_id)


@router.post(
    "/classifications",
    response_model=IssuerClassificationOut,
    status_code=status.HTTP_201_CREATED,
)
def create_classification(
    body: ClassificationCreate,
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.classify_issuer(
        db=db,
        issuer_id=body.issuer_id,
        security_id=body.security_id,
        sector_code=body.gics_sector_code,
        industry_group_code=body.gics_industry_group_code,
        industry_code=body.gics_industry_code,
        sub_industry_code=body.gics_sub_industry_code,
        source=body.source.strip(),
        effective_from=body.effective_from,
    )