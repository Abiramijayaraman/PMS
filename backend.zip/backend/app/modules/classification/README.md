# Classification
Store verified GICS classification for eligible company issuers, separate from PMS asset class/instrument type. Do not invent classifications or assign company GICS codes to funds/indexes by assumption. Track source and effective date. See `docs/gics-and-classification.md`.
