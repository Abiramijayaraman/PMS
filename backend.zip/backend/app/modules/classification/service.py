from app.core.exceptions import ValidationError
from app.modules.classification import repository


def list_issuers(db) -> list:
    return repository.list_issuers(db)

def get_issuer(db, issuer_id: int):
    return repository.get_issuer_by_id(db, issuer_id)

def list_classifications(db, issuer_id: int) -> list:
    return repository.list_issuer_classifications(db, issuer_id)

def create_issuer(db, issuer_name: str, country: str = "India") -> dict:
    return repository.insert_issuer(db, issuer_name, country)

def classify_issuer(db, issuer_id: int, security_id: int, sector_code, industry_group_code, industry_code, sub_industry_code, source: str, effective_from):
    """Only actual company equities can be classified - a fund wrapper has no GICS concept."""
    row = repository.get_security_asset_class(db, security_id)
    if not row or row["asset_class"] != "Equity":
        raise ValidationError("Only Equity securities can be assigned a GICS classification")

    repository.link_security_to_issuer(db, security_id, issuer_id)
    return repository.insert_classification(db, issuer_id, sector_code, industry_group_code, industry_code, sub_industry_code, source, effective_from)