def get_user_by_email(db, email: str):
    db.execute(
        "SELECT user_id, name, email, password_hash, role FROM users WHERE email = %s AND is_active = TRUE",
        (email,),
    )
    return db.fetchone()
