from app.core.exceptions import AuthError
from app.common.security_utils import verify_password, create_access_token, create_refresh_token, decode_token
from app.modules.auth import repository

def login(db, email: str, password: str) -> dict:
    user = repository.get_user_by_email(db, email)
    if not user or not verify_password(password, user["password_hash"]):
        raise AuthError("Invalid email or password")
    return {
        "access_token": create_access_token(user["user_id"]),
        "refresh_token": create_refresh_token(user["user_id"]),
    }

def refresh(refresh_token: str) -> str:
    payload = decode_token(refresh_token)
    if payload.get("type") != "refresh":
        raise AuthError("Not a refresh token")
    return create_access_token(int(payload["sub"]))
