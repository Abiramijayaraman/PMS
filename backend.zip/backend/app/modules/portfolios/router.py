from fastapi import APIRouter, Depends
from app.core.database import get_db, get_current_user
from app.modules.portfolios import service
from app.modules.portfolios.schemas import PortfolioCreate, PortfolioUpdate

router = APIRouter()

@router.post("")
def create_portfolio(body: PortfolioCreate, db=Depends(get_db), user=Depends(get_current_user)):
    return service.create_portfolio(db, user["user_id"], body.model_dump())

@router.get("")
def list_my_portfolios(db=Depends(get_db), user=Depends(get_current_user)):
    return service.list_my_portfolios(db, user["user_id"])

@router.get("/{portfolio_id}")
def get_portfolio(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.get_portfolio_or_404(db, portfolio_id)

@router.patch("/{portfolio_id}")
def update_portfolio(portfolio_id: int, body: PortfolioUpdate, db=Depends(get_db), user=Depends(get_current_user)):
    return service.update_portfolio(db, portfolio_id, body.model_dump())

@router.delete("/{portfolio_id}")
def close_portfolio(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    # Soft delete only - financial records are never hard-deleted
    return service.close_portfolio(db, portfolio_id)
