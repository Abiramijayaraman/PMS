"""
Raw SQL only - no ORM. Every query is parameterized with %s;
never build a query with an f-string.
"""

def insert_portfolio(db, user_id: int, data: dict) -> dict:
    db.execute(
        """
        INSERT INTO portfolios
            (user_id, portfolio_name, portfolio_type, currency, exchange,
             benchmark_symbol, theme_id, rebalancing_frequency, initial_investment, inception_date)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING *
        """,
        (
            user_id, data["portfolio_name"], data["portfolio_type"], data["currency"],
            data["exchange"], data["benchmark_symbol"], data["theme_id"],
            data["rebalancing_frequency"], data["initial_investment"], data["inception_date"],
        ),
    )
    return db.fetchone()

def list_portfolios_for_user(db, user_id: int) -> list:
    db.execute("SELECT * FROM portfolios WHERE user_id = %s ORDER BY updated_at DESC", (user_id,))
    return db.fetchall()

def get_portfolio(db, portfolio_id: int):
    db.execute("SELECT * FROM portfolios WHERE portfolio_id = %s", (portfolio_id,))
    return db.fetchone()

def update_portfolio(db, portfolio_id: int, fields: dict) -> dict:
    set_clause = ", ".join(f"{k} = %s" for k in fields)
    values = list(fields.values()) + [portfolio_id]
    db.execute(
        f"UPDATE portfolios SET {set_clause}, updated_at = NOW() WHERE portfolio_id = %s RETURNING *",
        values,
    )
    return db.fetchone()

def close_portfolio(db, portfolio_id: int) -> dict:
    db.execute(
        "UPDATE portfolios SET status = 'CLOSED', closed_at = NOW(), updated_at = NOW() WHERE portfolio_id = %s RETURNING *",
        (portfolio_id,),
    )
    return db.fetchone()