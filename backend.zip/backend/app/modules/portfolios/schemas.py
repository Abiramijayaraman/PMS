from pydantic import BaseModel, Field, field_validator
from decimal import Decimal
from datetime import datetime, date


class PortfolioCreate(BaseModel):
    portfolio_name: str
    portfolio_type: str = Field(pattern="^(WEIGHTAGE|AMOUNT)$")
    currency: str = "INR"
    exchange: str = "NSE"
    benchmark_symbol: str = "^NSEI"
    theme_id: int = Field(gt=0)
    rebalancing_frequency: str = Field(pattern="^(DAILY|MONTHLY|QUARTERLY|HALF_YEARLY|YEARLY)$")
    initial_investment: Decimal = Field(gt=0)
    inception_date: date | None = None  # None = defaults to the dataset's latest date, not today

    @field_validator("portfolio_name")
    @classmethod
    def validate_portfolio_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Portfolio name cannot be blank")
        return value


class PortfolioUpdate(BaseModel):
    portfolio_name: str | None = None
    benchmark_symbol: str | None = None
    rebalancing_frequency: str | None = None


class PortfolioOut(BaseModel):
    portfolio_id: int
    portfolio_name: str
    portfolio_type: str
    currency: str
    exchange: str
    benchmark_symbol: str
    theme_id: int
    rebalancing_frequency: str
    initial_investment: Decimal
    status: str
    inception_date: date
    created_at: datetime