from pydantic import BaseModel
from decimal import Decimal

class DriftRow(BaseModel):
    asset_id: int
    actual_pct: float
    target_pct: float
    diff_pct: float

class RebalanceOrder(BaseModel):
    holding_id: int
    security_id: int
    symbol: str
    current_quantity: float
    target_quantity: float
    delta_quantity: float
    action: str
    price: float
