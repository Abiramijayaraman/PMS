from fastapi import APIRouter, Depends
from app.core.database import get_db, get_current_user
from app.modules.rebalancing import service

router = APIRouter()

@router.get("/{portfolio_id}/drift")
def get_drift(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.get_drift(db, portfolio_id)

@router.get("/{portfolio_id}/rebalance/preview")
def preview_rebalance(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    """Read-only - shows the manager what would change before committing."""
    return service.preview_rebalance(db, portfolio_id)

@router.post("/{portfolio_id}/rebalance/execute")
def execute_rebalance(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    """Applies the rebalance: updates holdings, logs transactions."""
    return service.execute_rebalance(db, portfolio_id)
