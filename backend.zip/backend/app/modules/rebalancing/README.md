5% drift, preview/execute, audit trail.

Implementation will be added module-by-module after the plan is confirmed.
