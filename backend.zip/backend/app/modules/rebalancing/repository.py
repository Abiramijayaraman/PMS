def get_holdings_with_class(db, portfolio_id: int) -> list:
    db.execute(
        """
        SELECT h.holding_id, h.security_id, h.quantity, s.asset_id, s.symbol, s.last_price
        FROM holdings h
        JOIN securities s ON s.security_id = h.security_id
        WHERE h.portfolio_id = %s
        """,
        (portfolio_id,),
    )
    return db.fetchall()

def get_theme_targets(db, theme_id: int) -> list:
    db.execute(
        "SELECT asset_id, allocation_pct FROM theme_allocation WHERE theme_id = %s",
        (theme_id,),
    )
    return db.fetchall()

def adjust_holding_quantity(db, holding_id: int, new_quantity):
    db.execute(
        "UPDATE holdings SET quantity = %s, updated_at = NOW() WHERE holding_id = %s RETURNING *",
        (new_quantity, holding_id),
    )
    return db.fetchone()
