"""
Rebalancing logic: compares actual value per asset class (from current
holdings x last_price) against the theme's target %, and - when the
drift exceeds a threshold - scales every holding within that asset
class by the same factor to bring it back to target.

This is class-level rebalancing, not per-security: it preserves the
relative weights of securities inside each asset class rather than
requiring a target weight on every individual holding.
"""
from app.modules.holdings import repository as holdings_repository
from app.core.exceptions import NotFoundError
from app.modules.rebalancing import repository
from app.modules.holdings.repository import log_transaction
from app.modules.portfolios.repository import get_portfolio

DRIFT_THRESHOLD_PCT = 5.0  # matches the spec: "differed by more than 5% in total"


def _compute_class_breakdown(db, portfolio_id: int) -> tuple[dict, dict, float]:
    portfolio = get_portfolio(db, portfolio_id)
    if not portfolio:
        raise NotFoundError("Portfolio", portfolio_id)

    holdings = repository.get_holdings_with_class(db, portfolio_id)
    total_value = sum(float(h["quantity"]) * float(h["last_price"] or 0) for h in holdings)

    class_value = {}
    for h in holdings:
        value = float(h["quantity"]) * float(h["last_price"] or 0)
        class_value[h["asset_id"]] = class_value.get(h["asset_id"], 0) + value

    targets = {t["asset_id"]: float(t["allocation_pct"]) for t in repository.get_theme_targets(db, portfolio["theme_id"])}
    return class_value, targets, total_value


def get_drift(db, portfolio_id: int) -> dict:
    class_value, targets, total_value = _compute_class_breakdown(db, portfolio_id)
    all_asset_ids = set(class_value) | set(targets)

    breakdown = []
    total_abs_drift = 0.0
    for asset_id in all_asset_ids:
        actual_pct = (class_value.get(asset_id, 0) / total_value * 100) if total_value else 0
        target_pct = targets.get(asset_id, 0)
        diff = actual_pct - target_pct
        total_abs_drift += abs(diff)
        breakdown.append({
            "asset_id": asset_id,
            "actual_pct": round(actual_pct, 2),
            "target_pct": round(target_pct, 2),
            "diff_pct": round(diff, 2),
        })

    return {
        "total_value": round(total_value, 2),
        "total_drift_pct": round(total_abs_drift, 2),
        "breached": total_abs_drift > DRIFT_THRESHOLD_PCT,
        "threshold_pct": DRIFT_THRESHOLD_PCT,
        "breakdown": breakdown,
    }


def preview_rebalance(db, portfolio_id: int) -> list:
    """Read-only: computes what WOULD change, applies nothing."""
    class_value, targets, total_value = _compute_class_breakdown(db, portfolio_id)
    holdings = repository.get_holdings_with_class(db, portfolio_id)

    orders = []
    for asset_id, target_pct in targets.items():
        current_class_value = class_value.get(asset_id, 0)
        target_class_value = (target_pct / 100) * total_value
        if current_class_value <= 0:
            continue  # no existing holdings in this class to scale - needs a manual buy first
        scale_factor = target_class_value / current_class_value

        for h in holdings:
            if h["asset_id"] != asset_id:
                continue
            old_qty = float(h["quantity"])
            new_qty = round(old_qty * scale_factor, 4)
            delta_qty = round(new_qty - old_qty, 4)
            if abs(delta_qty) < 0.0001:
                continue
            orders.append({
                "holding_id": h["holding_id"],
                "security_id": h["security_id"],
                "symbol": h["symbol"],
                "current_quantity": old_qty,
                "target_quantity": new_qty,
                "delta_quantity": delta_qty,
                "action": "BUY" if delta_qty > 0 else "SELL",
                "price": float(h["last_price"]),
            })
    return orders


def execute_rebalance(db, portfolio_id: int) -> list:
    """
    Execute a rebalance only when the configured drift
    threshold has been breached.

    The database dependency manages commit/rollback.
    """

    # 1. Validate the portfolio and calculate its current drift.
    drift = get_drift(db, portfolio_id)

    # 2. Do not execute unnecessary trades.
    if not drift["breached"]:
        return []

    # 3. Recalculate orders using current database values.
    orders = preview_rebalance(db, portfolio_id)

    # 4. Apply the proposed changes and record transactions.
    for order in orders:
        if order["target_quantity"] <= 0:
            deleted_holding = holdings_repository.delete_holding(
                db,
                portfolio_id,
                order["holding_id"],
            )

            if not deleted_holding:
                raise NotFoundError(
                    "Holding",
                    order["holding_id"],
                )

        else:
            updated_holding = repository.adjust_holding_quantity(
                db,
                order["holding_id"],
                order["target_quantity"],
            )

            if not updated_holding:
                raise NotFoundError(
                    "Holding",
                    order["holding_id"],
                )

        log_transaction(
            db,
            portfolio_id,
            order["security_id"],
            order["action"],
            abs(order["delta_quantity"]),
            order["price"],
        )

    return orders