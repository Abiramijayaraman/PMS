from datetime import date

from fastapi import APIRouter, Depends, Query

from app.core.database import get_db, get_current_user
from app.modules.market_data import service


router = APIRouter()


@router.get("/securities/{symbol}/history")
def get_security_price_history(
    symbol: str,
    start_date: date | None = Query(default=None),
    end_date: date | None = Query(default=None),
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.get_security_price_history(
        db=db,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
    )


@router.get("/benchmarks/{benchmark_symbol}/history")
def get_benchmark_price_history(
    benchmark_symbol: str,
    start_date: date | None = Query(default=None),
    end_date: date | None = Query(default=None),
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.get_benchmark_price_history(
        db=db,
        benchmark_symbol=benchmark_symbol,
        start_date=start_date,
        end_date=end_date,
    )