from datetime import date

from app.modules.market_data import repository


def _validate_date_range(
    start_date: date | None,
    end_date: date | None,
):
    if (
        start_date is not None
        and end_date is not None
        and start_date > end_date
    ):
        raise ValueError(
            "start_date cannot be after end_date"
        )


def _validate_symbol(symbol: str, field_name: str):
    if not isinstance(symbol, str) or not symbol.strip():
        raise ValueError(f"{field_name} cannot be empty")


def get_security_price_history(
    db,
    symbol: str,
    start_date: date | None = None,
    end_date: date | None = None,
):
    _validate_symbol(symbol, "symbol")
    _validate_date_range(start_date, end_date)

    return repository.get_security_price_history(
        db=db,
        symbol=symbol.strip(),
        start_date=start_date,
        end_date=end_date,
    )


def get_benchmark_price_history(
    db,
    benchmark_symbol: str,
    start_date: date | None = None,
    end_date: date | None = None,
):
    _validate_symbol(benchmark_symbol, "benchmark_symbol")
    _validate_date_range(start_date, end_date)

    return repository.get_benchmark_price_history(
        db=db,
        benchmark_symbol=benchmark_symbol.strip(),
        start_date=start_date,
        end_date=end_date,
    )