from datetime import date
from decimal import Decimal

from pydantic import BaseModel, ConfigDict


class SecurityPriceHistoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    security_id: int
    symbol: str
    price_date: date
    close_price: Decimal
    source: str | None = None


class BenchmarkPriceHistoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    benchmark_symbol: str
    price_date: date
    close_price: Decimal
    source: str | None = None