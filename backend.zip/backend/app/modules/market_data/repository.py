from datetime import date


def get_security_price_history(
    db,
    symbol: str,
    start_date: date | None = None,
    end_date: date | None = None,
):
    query = """
        SELECT
            s.security_id,
            s.symbol,
            ph.price_date,
            ph.close_price,
            ph.source
        FROM price_history AS ph
        JOIN securities AS s
            ON s.security_id = ph.security_id
        WHERE s.symbol = %s
          AND (%s IS NULL OR ph.price_date >= %s)
          AND (%s IS NULL OR ph.price_date <= %s)
        ORDER BY ph.price_date ASC;
    """

    db.execute(
        query,
        (
            symbol,
            start_date,
            start_date,
            end_date,
            end_date,
        ),
    )

    return db.fetchall()


def get_benchmark_price_history(
    db,
    benchmark_symbol: str,
    start_date: date | None = None,
    end_date: date | None = None,
):
    query = """
        SELECT
            benchmark_symbol,
            price_date,
            close_price,
            source
        FROM benchmark_history
        WHERE benchmark_symbol = %s
          AND (%s IS NULL OR price_date >= %s)
          AND (%s IS NULL OR price_date <= %s)
        ORDER BY price_date ASC;
    """

    db.execute(
        query,
        (
            benchmark_symbol,
            start_date,
            start_date,
            end_date,
            end_date,
        ),
    )

    return db.fetchall()