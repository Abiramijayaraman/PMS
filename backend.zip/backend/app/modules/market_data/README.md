# Market Data

## Purpose

Provides read-only access to historical security prices and
benchmark prices stored in PostgreSQL.

## Responsibilities

- Retrieve historical prices for a security symbol.
- Retrieve historical prices for a benchmark symbol.
- Support optional inclusive start and end dates.
- Return results in ascending price-date order.
- Validate symbols and date ranges in the service layer.

## Data sources

- `price_history`
- `benchmark_history`
- `securities`

Historical data is populated by the existing import process.

## Current data cutoff

The current database reporting cutoff is 2026-09-24.

The underlying CSV files are not modified by this module.

## Out of scope

- Live market data APIs
- Streaming or scheduled price updates
- Simulated market movements
- Historical data imports
- Database writes

## Module structure

- `repository.py`: SQL data access
- `service.py`: validation and service operations
- `schemas.py`: Pydantic output models
- `router.py`: API routes, to be completed later