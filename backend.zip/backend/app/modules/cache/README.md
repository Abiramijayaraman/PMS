# Cache integration
Cross-cutting cache policy and key invalidation. This is not a business CRUD module. Coordinate invalidation from portfolio/holdings/transactions/rebalancing and market-data import after database commit. See `docs/cache-strategy.md`.
