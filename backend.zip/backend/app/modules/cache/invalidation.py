from app.core.cache.adapter import cache

def invalidate_portfolio(portfolio_id: int):
    cache.delete_prefix(f"portfolio:{portfolio_id}:")

def invalidate_reference_data():
    cache.delete("themes:all")
    cache.delete("asset_classes:all")