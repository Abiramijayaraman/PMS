from pydantic import BaseModel

class ThemeOut(BaseModel):
    theme_id: int
    theme_name: str
    risk_level: str
    investment_horizon: str
