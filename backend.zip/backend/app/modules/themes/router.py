from fastapi import APIRouter, Depends
from app.core.database import get_db, get_current_user
from app.modules.themes import service

router = APIRouter()

# Cached hard on the frontend (staleTime: Infinity) since this rarely changes
@router.get("")
def list_themes(db=Depends(get_db), user=Depends(get_current_user)):
    return service.list_themes(db)

@router.get("/{theme_id}/allocation")
def get_theme_allocation(theme_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.get_theme_allocation(db, theme_id)
