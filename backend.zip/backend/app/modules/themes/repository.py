def list_themes(db) -> list:
    db.execute("SELECT * FROM investment_themes WHERE is_active = TRUE ORDER BY theme_name")
    return db.fetchall()

def get_theme_allocation(db, theme_id: int) -> list:
    db.execute(
        """
        SELECT a.asset_class, ta.allocation_pct
        FROM theme_allocation ta
        JOIN asset_classes a ON a.asset_id = ta.asset_id
        WHERE ta.theme_id = %s
        """,
        (theme_id,),
    )
    return db.fetchall()
