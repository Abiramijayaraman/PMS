from app.modules.themes import repository

def list_themes(db) -> list:
    return repository.list_themes(db)

def get_theme_allocation(db, theme_id: int) -> list:
    return repository.get_theme_allocation(db, theme_id)
