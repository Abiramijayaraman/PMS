def list_holdings(db, portfolio_id: int) -> list:
    db.execute(
        """
        SELECT h.holding_id, h.quantity, h.avg_price, h.as_of_date, h.updated_at,
               s.security_id, s.symbol, s.security_name, s.last_price, s.asset_id
        FROM holdings h
        JOIN securities s ON s.security_id = h.security_id
        WHERE h.portfolio_id = %s
        ORDER BY h.added_at
        """,
        (portfolio_id,),
    )
    return db.fetchall()

def get_current_allocation(db, portfolio_id: int) -> list:
    db.execute(
        """
        SELECT ac.asset_id, ac.asset_class,
               SUM(h.quantity * s.last_price) AS current_value
        FROM holdings h
        JOIN securities s ON s.security_id = h.security_id
        JOIN asset_classes ac ON ac.asset_id = s.asset_id
        WHERE h.portfolio_id = %s
        GROUP BY ac.asset_id, ac.asset_class
        """,
        (portfolio_id,),
    )
    return db.fetchall()

def get_theme_limit(db, theme_id: int, asset_id: int):
    db.execute(
        "SELECT allocation_pct FROM theme_allocation WHERE theme_id = %s AND asset_id = %s",
        (theme_id, asset_id),
    )
    row = db.fetchone()
    return row["allocation_pct"] if row else None

def get_price_on_date(db, security_id: int, as_of_date):
    """Most recent trading-day price at or before as_of_date - handles NSE holidays."""
    db.execute(
        """
        SELECT close_price FROM price_history
        WHERE security_id = %s AND price_date <= %s
        ORDER BY price_date DESC LIMIT 1
        """,
        (security_id, as_of_date),
    )
    row = db.fetchone()
    return float(row["close_price"]) if row else None

def get_security_by_id(db, security_id: int):
    db.execute(
        "SELECT security_id, symbol, security_name, asset_id, sector, last_price FROM securities WHERE security_id = %s",
        (security_id,),
    )
    return db.fetchone()

def insert_holding(db, portfolio_id: int, security_id: int, quantity, avg_price, as_of_date) -> dict:
    db.execute(
        """
        INSERT INTO holdings (portfolio_id, security_id, quantity, avg_price, as_of_date)
        VALUES (%s, %s, %s, %s, %s)
        ON CONFLICT (portfolio_id, security_id) DO UPDATE SET
            avg_price = ((holdings.quantity * holdings.avg_price) + (EXCLUDED.quantity * EXCLUDED.avg_price))
                        / (holdings.quantity + EXCLUDED.quantity),
            quantity = holdings.quantity + EXCLUDED.quantity,
            as_of_date = EXCLUDED.as_of_date,
            updated_at = NOW()
        RETURNING *
        """,
        (portfolio_id, security_id, quantity, avg_price, as_of_date),
    )
    return db.fetchone()

def log_transaction(db, portfolio_id: int, security_id: int, action: str, quantity, price, txn_date=None):
    db.execute(
        """
        INSERT INTO transactions (portfolio_id, security_id, action, quantity, price, txn_date)
        VALUES (%s, %s, %s, %s, %s, COALESCE(%s, CURRENT_DATE))
        """,
        (portfolio_id, security_id, action, quantity, price, txn_date),
    )

def delete_holding(db, portfolio_id: int, holding_id: int):
    db.execute(
        "DELETE FROM holdings WHERE holding_id = %s AND portfolio_id = %s RETURNING *",
        (holding_id, portfolio_id),
    )
    return db.fetchone()

def get_invested_value_by_asset_class(db, portfolio_id: int) -> list:
    db.execute(
        """
        SELECT s.asset_id, SUM(h.quantity * h.avg_price) AS invested_value
        FROM holdings h
        JOIN securities s ON s.security_id = h.security_id
        WHERE h.portfolio_id = %s
        GROUP BY s.asset_id
        """,
        (portfolio_id,),
    )
    return db.fetchall()

def list_transactions(db, portfolio_id: int) -> list:
    db.execute(
        """
        SELECT t.txn_id, t.action, t.quantity, t.price, t.txn_date,
               s.symbol, s.security_name
        FROM transactions t
        JOIN securities s ON s.security_id = t.security_id
        WHERE t.portfolio_id = %s
        ORDER BY t.txn_date DESC, t.txn_id DESC
        """,
        (portfolio_id,),
    )
    return db.fetchall()