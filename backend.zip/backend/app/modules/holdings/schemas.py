from decimal import Decimal

from pydantic import BaseModel, Field


class HoldingCreate(BaseModel):
    security_id: int = Field(gt=0)
    quantity: Decimal = Field(gt=0)
    avg_price: Decimal = Field(ge=0)


class HoldingUpdate(BaseModel):
    quantity: Decimal = Field(gt=0)