from fastapi import APIRouter, Depends
from app.core.database import get_db, get_current_user
from app.modules.holdings import service
from app.modules.holdings.schemas import HoldingCreate

router = APIRouter()

@router.get("/{portfolio_id}/budget")
def get_budget(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    """Remaining room per asset class, before hitting a rejection on purchase."""
    return service.get_budget_by_asset_class(db, portfolio_id)

@router.post("/{portfolio_id}/holdings")
def add_holding(portfolio_id: int, body: HoldingCreate, db=Depends(get_db), user=Depends(get_current_user)):
    return service.add_holding(db, portfolio_id, body.security_id, body.quantity, body.avg_price)

@router.get("/{portfolio_id}/holdings")
def list_holdings(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.list_holdings(db, portfolio_id)

@router.delete("/{portfolio_id}/holdings/{holding_id}")
def remove_holding(portfolio_id: int, holding_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.remove_holding(db, portfolio_id, holding_id)

@router.get("/{portfolio_id}/transactions")
def list_transactions(portfolio_id: int, db=Depends(get_db), user=Depends(get_current_user)):
    return service.list_transactions(db, portfolio_id)
