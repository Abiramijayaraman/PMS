from app.core.exceptions import ValidationError, NotFoundError
from app.common.dates import get_data_as_of_date
from app.modules.holdings import repository
from app.modules.portfolios.repository import get_portfolio


def get_budget_by_asset_class(db, portfolio_id: int) -> list:
    portfolio = get_portfolio(db, portfolio_id)
    if not portfolio:
        raise NotFoundError("Portfolio", portfolio_id)

    invested = {row["asset_id"]: float(row["invested_value"]) for row in repository.get_invested_value_by_asset_class(db, portfolio_id)}
    from app.modules.rebalancing.repository import get_theme_targets
    targets = get_theme_targets(db, portfolio["theme_id"])

    budget = []
    for t in targets:
        max_allowed = (float(t["allocation_pct"]) / 100) * float(portfolio["initial_investment"])
        already_invested = invested.get(t["asset_id"], 0.0)
        budget.append({
            "asset_id": t["asset_id"],
            "allocation_pct": float(t["allocation_pct"]),
            "max_allowed_value": round(max_allowed, 2),
            "invested_value": round(already_invested, 2),
            "remaining_value": round(max_allowed - already_invested, 2),
        })
    return budget


def add_holding(db, portfolio_id: int, security_id: int, quantity, avg_price=None, as_of_date=None) -> dict:
    portfolio = get_portfolio(db, portfolio_id)
    if not portfolio:
        raise NotFoundError("Portfolio", portfolio_id)

    security = repository.get_security_by_id(db, security_id)
    if not security:
        raise NotFoundError("Security", security_id)

    effective_date = as_of_date or get_data_as_of_date(db)

    if as_of_date is not None and avg_price is None:
        avg_price = repository.get_price_on_date(db, security_id, as_of_date)
        if avg_price is None:
            raise ValidationError(f"No price history for this security on or before {as_of_date}")
    elif avg_price is None:
        avg_price = float(security["last_price"]) if security["last_price"] is not None else None
        if avg_price is None:
            raise ValidationError("This security has no current price set")

    limit_pct = repository.get_theme_limit(db, portfolio["theme_id"], security["asset_id"])
    effective_limit_pct = float(limit_pct) if limit_pct is not None else 0.0

    invested_by_class = {row["asset_id"]: float(row["invested_value"]) for row in repository.get_invested_value_by_asset_class(db, portfolio_id)}
    already_invested = invested_by_class.get(security["asset_id"], 0.0)
    new_purchase_value = float(quantity) * float(avg_price)
    max_allowed = (effective_limit_pct / 100) * float(portfolio["initial_investment"])

    if (already_invested + new_purchase_value) > max_allowed:
        remaining = max(max_allowed - already_invested, 0)
        raise ValidationError(
            f"This purchase (Rs.{new_purchase_value:,.2f}) exceeds the {effective_limit_pct}% theme limit "
            f"for this asset class. Remaining room: Rs.{remaining:,.2f}"
        )

    holding = repository.insert_holding(db, portfolio_id, security_id, quantity, avg_price, effective_date)
    repository.log_transaction(db, portfolio_id, security_id, "BUY", quantity, avg_price, effective_date)
    return holding


def list_holdings(db, portfolio_id: int) -> list:
    return repository.list_holdings(db, portfolio_id)


def remove_holding(db, portfolio_id: int, holding_id: int) -> dict:
    holding = repository.delete_holding(db, portfolio_id, holding_id)
    if not holding:
        raise NotFoundError("Holding", holding_id)
    repository.log_transaction(db, portfolio_id, holding["security_id"], "SELL", holding["quantity"], holding["avg_price"])
    return holding


def list_transactions(db, portfolio_id: int) -> list:
    return repository.list_transactions(db, portfolio_id)