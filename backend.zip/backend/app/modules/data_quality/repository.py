def get_database_summary(db) -> dict:
    """Return counts and date ranges for stored market data."""
    db.execute(
        """
        SELECT
            (SELECT COUNT(*) FROM price_history)
                AS price_history_count,
            (SELECT COUNT(*) FROM benchmark_history)
                AS benchmark_history_count,
            (SELECT COUNT(*) FROM securities)
                AS securities_count,
            (SELECT MIN(price_date) FROM price_history)
                AS earliest_price_date,
            (SELECT MAX(price_date) FROM price_history)
                AS latest_price_date,
            (SELECT MIN(price_date) FROM benchmark_history)
                AS earliest_benchmark_date,
            (SELECT MAX(price_date) FROM benchmark_history)
                AS latest_benchmark_date
        """
    )
    return db.fetchone()


def get_duplicate_key_counts(db) -> dict:
    """Count duplicate keys in historical price tables."""
    db.execute(
        """
        SELECT
            (
                SELECT COUNT(*)
                FROM (
                    SELECT security_id, price_date
                    FROM price_history
                    GROUP BY security_id, price_date
                    HAVING COUNT(*) > 1
                ) AS duplicate_prices
            ) AS duplicate_price_keys,

            (
                SELECT COUNT(*)
                FROM (
                    SELECT benchmark_symbol, price_date
                    FROM benchmark_history
                    GROUP BY benchmark_symbol, price_date
                    HAVING COUNT(*) > 1
                ) AS duplicate_benchmark_keys
            ) AS duplicate_benchmark_keys
        """
    )
    return db.fetchone()


def get_price_history_coverage(db) -> list[dict]:
    """
    Find potential gaps in stored security price history.

    A date is considered a potential gap when:
    - At least one security has a price on that date.
    - The date falls within another security's recorded history range.
    - That security has no price record for the date.

    This is not an exchange-calendar validation.
    """
    db.execute(
        """
        WITH security_ranges AS (
            SELECT
                ph.security_id,
                s.symbol,
                MIN(ph.price_date) AS first_price_date,
                MAX(ph.price_date) AS last_price_date,
                COUNT(*) AS available_price_count
            FROM price_history ph
            JOIN securities s
                ON s.security_id = ph.security_id
            GROUP BY ph.security_id, s.symbol
        ),
        observed_dates AS (
            SELECT DISTINCT price_date
            FROM price_history
        ),
        potential_gaps AS (
            SELECT
                sr.security_id,
                sr.symbol,
                od.price_date
            FROM security_ranges sr
            JOIN observed_dates od
                ON od.price_date BETWEEN
                    sr.first_price_date AND sr.last_price_date
            LEFT JOIN price_history ph
                ON ph.security_id = sr.security_id
               AND ph.price_date = od.price_date
            WHERE ph.security_id IS NULL
        ),
        gap_summary AS (
            SELECT
                security_id,
                COUNT(*) AS potential_gap_count,
                ARRAY_AGG(price_date ORDER BY price_date)
                    AS potential_gap_dates
            FROM potential_gaps
            GROUP BY security_id
        )
        SELECT
            sr.security_id,
            sr.symbol,
            sr.first_price_date,
            sr.last_price_date,
            sr.available_price_count,
            COALESCE(gs.potential_gap_count, 0)
                AS potential_gap_count,
            COALESCE(
                gs.potential_gap_dates,
                ARRAY[]::DATE[]
            ) AS potential_gap_dates
        FROM security_ranges sr
        LEFT JOIN gap_summary gs
            ON gs.security_id = sr.security_id
        ORDER BY sr.symbol
        """
    )
    return db.fetchall()
def get_recent_import_runs(db, limit: int = 20) -> list:
    db.execute("SELECT * FROM data_import_runs ORDER BY started_at DESC LIMIT %s", (limit,))
    return db.fetchall()