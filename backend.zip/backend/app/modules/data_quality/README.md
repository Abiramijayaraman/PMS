# Data Quality

The Data Quality module provides database-level checks for historical
market data. Source-file audits remain in the backend/scripts directory.

## Database checks

### Database summary

`get_database_summary(db)` returns:
- Price-history and benchmark-history row counts
- Security-master row count
- Earliest and latest dates in both history tables

### Duplicate-key counts

`get_duplicate_key_counts(db)` counts duplicate:
- `(security_id, price_date)` keys in `price_history`
- `(benchmark_symbol, price_date)` keys in `benchmark_history`

The database may enforce uniqueness constraints on these keys. The
function remains useful as a diagnostic check.

### Historical price coverage

`get_price_history_coverage(db)` reports potential missing price dates
for securities with stored price history.

A potential gap is a date that:
- Exists in the set of dates observed in `price_history`
- Falls within the security's own first-to-last recorded date range
- Has no price record for that security

This is a diagnostic, not definitive proof of missing market data.
The module does not currently use an exchange trading calendar, listing
history, or instrument-specific trading calendars.

## Source CSV audits

Existing scripts under `backend/scripts/` audit source files and
generate CSV reports. These scripts are separate from the database
queries and should be run according to their existing workflow.

The raw source CSV files must remain unchanged.

## Scope

- Historical data only
- No live market-data ingestion
- No streaming or scheduled jobs
- No automatic correction or deletion of records
- No new API routes as part of these checks