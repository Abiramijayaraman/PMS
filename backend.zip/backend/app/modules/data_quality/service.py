from app.modules.data_quality import repository


def get_database_summary(db) -> dict:
    """Return a summary of historical market data."""
    return repository.get_database_summary(db)


def get_duplicate_key_counts(db) -> dict:
    """Return duplicate-key counts for historical price tables."""
    return repository.get_duplicate_key_counts(db)


def get_price_history_coverage(db) -> list[dict]:
    """Return potential gaps in stored security price history."""
    return repository.get_price_history_coverage(db)

def get_recent_import_runs(db, limit: int = 20) -> list:
    return repository.get_recent_import_runs(db, limit)