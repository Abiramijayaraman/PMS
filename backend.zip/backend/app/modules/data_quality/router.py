from fastapi import APIRouter, Depends, Query

from app.core.database import get_db, get_current_user
from app.modules.data_quality import service


router = APIRouter()


@router.get("/database-summary")
def get_database_summary(
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.get_database_summary(db)


@router.get("/duplicate-counts")
def get_duplicate_counts(
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.get_duplicate_key_counts(db)


@router.get("/price-history-coverage")
def get_price_history_coverage(
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.get_price_history_coverage(db)


@router.get("/import-runs")
def get_recent_import_runs(
    limit: int = Query(default=20, ge=1, le=100),
    db=Depends(get_db),
    user=Depends(get_current_user),
):
    return service.get_recent_import_runs(db, limit)