from app.modules.securities import repository

def search(db, query: str) -> list:
    return repository.search_securities(db, query)

def get_by_id(db, security_id: int):
    return repository.get_security_by_id(db, security_id)