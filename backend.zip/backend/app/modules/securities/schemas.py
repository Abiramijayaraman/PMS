from pydantic import BaseModel
from decimal import Decimal

class SecurityOut(BaseModel):
    security_id: int
    symbol: str
    security_name: str
    asset_id: int
    sector: str | None
    last_price: Decimal | None
