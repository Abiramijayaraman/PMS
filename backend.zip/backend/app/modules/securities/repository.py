def search_securities(db, query: str, limit: int = 20) -> list:
    db.execute(
        """
        SELECT security_id, symbol, security_name, asset_id, sector, last_price
        FROM securities
        WHERE is_active = TRUE
          AND (symbol ILIKE %s OR security_name ILIKE %s)
        ORDER BY symbol
        LIMIT %s
        """,
        (f"%{query}%", f"%{query}%", limit),
    )
    return db.fetchall()

def get_security_by_id(db, security_id: int):
    db.execute("SELECT * FROM securities WHERE security_id = %s AND is_active = TRUE", (security_id,))
    return db.fetchone()