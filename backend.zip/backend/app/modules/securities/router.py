from fastapi import APIRouter, Depends, Query
from app.core.database import get_db, get_current_user
from app.modules.securities import service

router = APIRouter()

@router.get("/search")
def search_securities(q: str = Query(min_length=1), db=Depends(get_db), user=Depends(get_current_user)):
    return service.search(db, q)
