from decimal import Decimal

from app.common.validation.decimals import parse_decimal


# Valid values
assert parse_decimal("125.50") == Decimal("125.50")
assert parse_decimal("0") == Decimal("0")
assert parse_decimal(100) == Decimal("100")

# Invalid values
invalid_values = [
    "",
    "abc",
    "NaN",
    "Infinity",
    "-Infinity",
    True,
    12.5,
]

for value in invalid_values:
    try:
        parse_decimal(value)
    except ValueError:
        pass
    else:
        raise AssertionError(f"Expected an error for {value!r}")

print("All decimal validation tests passed!")