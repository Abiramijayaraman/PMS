"""
TODO: use pytest + a test Postgres DB (or transaction rollback per test).
Example shape:

def test_create_portfolio_sets_status_new(client, auth_headers):
    response = client.post("/portfolios", json={...}, headers=auth_headers)
    assert response.status_code == 200
    assert response.json()["status"] == "NEW"
"""
