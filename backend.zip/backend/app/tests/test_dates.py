from datetime import date

from app.common.validation.dates import parse_date


# Valid dates
assert parse_date("2026-09-26") == date(2026, 9, 26)
assert parse_date(" 2024-02-29 ") == date(2024, 2, 29)

# Invalid dates
invalid_dates = [
    "",
    "   ",
    "2026-02-30",
    "2026/09/26",
    "not-a-date",
]

for value in invalid_dates:
    try:
        parse_date(value)
    except ValueError:
        pass
    else:
        raise AssertionError(f"Expected an error for {value!r}")

print("All date validation tests passed!")