from decimal import Decimal

from app.common.validation.numbers import require_positive


# Valid values
assert require_positive("125.50") == Decimal("125.50")
assert require_positive(10) == Decimal("10")
assert require_positive("0.001", "Price") == Decimal("0.001")

# Invalid values
for value in ["0", "-10", "-0.01"]:
    try:
        require_positive(value, "Price")
    except ValueError:
        pass
    else:
        raise AssertionError(f"Expected an error for {value!r}")

print("All positive-value validation tests passed!")