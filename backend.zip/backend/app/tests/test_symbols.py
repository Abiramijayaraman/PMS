from app.common.validation.symbols import normalize_symbol


# Valid symbols
assert normalize_symbol("hdfcbank") == "HDFCBANK"
assert normalize_symbol("  niftybees  ") == "NIFTYBEES"
assert normalize_symbol("EBBETF0430") == "EBBETF0430"

# Invalid symbols
for symbol in ["", "   ", "HDFC BANK", "HDFC@BANK"]:
    try:
        normalize_symbol(symbol)
    except ValueError:
        pass
    else:
        raise AssertionError(f"Expected an error for {symbol!r}")

print("All symbol validation tests passed!")