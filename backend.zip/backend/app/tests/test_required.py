from app.common.validation.required import require_value


# Valid values
assert require_value("HDFCBANK", "Symbol") == "HDFCBANK"
assert require_value(0, "Cash balance") == 0
assert require_value(False, "Flag") is False

# Invalid values
for value in [None, "", "   "]:
    try:
        require_value(value, "Symbol")
    except ValueError:
        pass
    else:
        raise AssertionError(f"Expected an error for {value!r}")

print("All required-field validation tests passed!")