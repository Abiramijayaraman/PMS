def get_data_as_of_date(db):
    """
    The app's effective 'today' - the latest date the static dataset covers,
    NOT the OS wall-clock date. Every place that needs a 'today' default
    must call this instead of date.today() or CURRENT_DATE.
    """
    db.execute("SELECT MAX(price_date) AS latest_date FROM price_history")
    row = db.fetchone()
    return row["latest_date"]