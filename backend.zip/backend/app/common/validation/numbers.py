from decimal import Decimal

from app.common.validation.decimals import parse_decimal


def require_positive(
    value: str | int | Decimal,
    field_name: str = "Value",
) -> Decimal:
    """
    Parse a decimal value and require it to be greater than zero.
    """
    parsed_value = parse_decimal(value)

    if parsed_value <= 0:
        raise ValueError(f"{field_name} must be greater than zero")

    return parsed_value