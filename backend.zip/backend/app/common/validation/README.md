# Shared validation
Reusable request and data primitives: normalized symbols, dates, decimals, positive prices/quantities, required fields, and structured errors. Dataset-specific audit rules belong in `modules/data_quality`.
