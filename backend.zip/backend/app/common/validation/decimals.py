from decimal import Decimal, InvalidOperation


def parse_decimal(value: str | int | Decimal) -> Decimal:
    """
    Convert a value into a Decimal.

    Examples:
        "125.50" -> Decimal("125.50")
        100      -> Decimal("100")
    """
    if isinstance(value, bool) or isinstance(value, float):
        raise ValueError("Value must be a string, integer, or Decimal")

    if not isinstance(value, (str, int, Decimal)):
        raise ValueError("Value must be a string, integer, or Decimal")

    try:
        parsed_value = Decimal(value.strip() if isinstance(value, str) else value)
    except (InvalidOperation, ValueError):
        raise ValueError(f"Invalid decimal value: {value!r}") from None

    if not parsed_value.is_finite():
        raise ValueError("Decimal value must be finite")

    return parsed_value