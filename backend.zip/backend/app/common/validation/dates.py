from datetime import date


def parse_date(value: str) -> date:
    """
    Parse a date in YYYY-MM-DD format.

    Example:
        "2026-09-26" -> date(2026, 9, 26)
    """
    if not isinstance(value, str):
        raise ValueError("Date must be a string in YYYY-MM-DD format")

    value = value.strip()

    if not value:
        raise ValueError("Date cannot be empty")

    try:
        parsed_date = date.fromisoformat(value)
    except ValueError:
        raise ValueError(
            f"Invalid date: {value!r}. Expected YYYY-MM-DD."
        ) from None

    return parsed_date