import re


_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9._-]*$")


def normalize_symbol(symbol: str) -> str:
    """
    Normalize and validate a security symbol.

    Example:
        "  hdfcbank " -> "HDFCBANK"
    """
    if not isinstance(symbol, str):
        raise ValueError("Symbol must be a string")

    normalized = symbol.strip().upper()

    if not normalized:
        raise ValueError("Symbol cannot be empty")

    if not _SYMBOL_PATTERN.fullmatch(normalized):
        raise ValueError(f"Invalid symbol: {symbol!r}")

    return normalized