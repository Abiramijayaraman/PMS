def require_value(value, field_name: str):
    """
    Ensure a required value is present.

    Rejects None and blank strings.
    """
    if value is None:
        raise ValueError(f"{field_name} is required")

    if isinstance(value, str) and not value.strip():
        raise ValueError(f"{field_name} is required")

    return value