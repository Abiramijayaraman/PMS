from pydantic import BaseModel

class PageParams(BaseModel):
    limit: int = 20
    offset: int = 0

def paginated(items: list, total: int, params: PageParams) -> dict:
    return {"items": items, "total": total, "limit": params.limit, "offset": params.offset}
