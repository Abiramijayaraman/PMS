from fastapi import APIRouter

from app.modules.auth.router import router as auth_router
from app.modules.portfolios.router import router as portfolios_router
from app.modules.securities.router import router as securities_router
from app.modules.holdings.router import router as holdings_router
from app.modules.themes.router import router as themes_router
from app.modules.asset_classes.router import router as asset_classes_router
from app.modules.performance.router import router as performance_router
from app.modules.rebalancing.router import router as rebalancing_router

# Modules to complete and integrate
from app.modules.market_data.router import router as market_data_router
from app.modules.data_quality.router import router as data_quality_router
from app.modules.classification.router import router as classification_router


api_router = APIRouter()

api_router.include_router(
    auth_router,
    prefix="/auth",
    tags=["Authentication"],
)

api_router.include_router(
    portfolios_router,
    prefix="/portfolios",
    tags=["Portfolios"],
)

api_router.include_router(
    securities_router,
    prefix="/securities",
    tags=["Securities"],
)

api_router.include_router(
    holdings_router,
    prefix="/portfolios",
    tags=["Holdings"],
)

api_router.include_router(
    themes_router,
    prefix="/themes",
    tags=["Investment Themes"],
)

api_router.include_router(
    asset_classes_router,
    prefix="/asset-classes",
    tags=["Asset Classes"],
)

api_router.include_router(
    performance_router,
    prefix="/portfolios",
    tags=["Performance"],
)

api_router.include_router(
    rebalancing_router,
    prefix="/portfolios",
    tags=["Rebalancing"],
)

api_router.include_router(
    market_data_router,
    prefix="/market-data",
    tags=["Market Data"],
)

api_router.include_router(
    data_quality_router,
    prefix="/data-quality",
    tags=["Data Quality"],
)

api_router.include_router(
    classification_router,
    prefix="/classification",
    tags=["GICS Classification"],
)