from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.rebalancing import service as rebalancing_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Fetch HDFCBANK
            db.execute(
                """
                SELECT security_id, symbol, last_price, asset_id
                FROM securities
                WHERE symbol = %s
                """,
                ("HDFCBANK",),
            )

            security = db.fetchone()

            assert security is not None
            assert security["last_price"] is not None

            current_price = Decimal(
                str(security["last_price"])
            )

            print("Existing security:", security["symbol"])
            print("Current price:", current_price)

            # 2. Fetch NIFTYBEES and its target asset class
            db.execute(
                """
                SELECT
                    s.security_id,
                    s.symbol,
                    s.asset_id,
                    ac.asset_class,
                    ta.allocation_pct
                FROM securities s
                JOIN asset_classes ac
                    ON ac.asset_id = s.asset_id
                JOIN theme_allocation ta
                    ON ta.asset_id = s.asset_id
                WHERE s.symbol = %s
                  AND ta.theme_id = %s
                """,
                ("NIFTYBEES", 1),
            )

            missing_security = db.fetchone()

            assert missing_security is not None
            assert Decimal(
                str(missing_security["allocation_pct"])
            ) > 0

            print(
                "\nMissing security:",
                missing_security["symbol"],
            )
            print(
                "Target class:",
                missing_security["asset_class"],
            )
            print(
                "Target allocation:",
                missing_security["allocation_pct"],
                "%",
            )

            # 3. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_MISSING_CLASS_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 4. Add HDFCBANK only
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=security["security_id"],
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            print("\nPortfolio contains HDFCBANK only.")

            # 5. Preview the rebalance
            orders = rebalancing_service.preview_rebalance(
                db, portfolio_id
            )

            print("\nPreview orders:")
            for order in orders:
                print(order)

            # 6. Confirm no order is generated for NIFTYBEES
            missing_class_orders = [
                order for order in orders
                if order["security_id"]
                == missing_security["security_id"]
            ]

            assert not missing_class_orders, (
                "Unexpected order for a security not held"
            )

            print(
                "\nNo BUY order generated for the missing "
                "asset class."
            )

            print("\nMissing-class test PASSED.")

    finally:
        connection.rollback()
        print("Test transaction rolled back.")