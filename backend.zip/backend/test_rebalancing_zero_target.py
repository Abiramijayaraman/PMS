from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.rebalancing import service as rebalancing_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Fetch GOLDBEES
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE symbol = %s
                """,
                ("GOLDBEES",),
            )

            security = db.fetchone()

            assert security is not None, (
                "GOLDBEES was not found"
            )
            assert security["last_price"] is not None, (
                "GOLDBEES has no current price"
            )

            current_price = Decimal(
                str(security["last_price"])
            )

            print("Security:", security["symbol"])
            print("Current price:", current_price)

            # 2. Confirm Gold's target for Theme 1
            db.execute(
                """
                SELECT ta.allocation_pct
                FROM theme_allocation ta
                JOIN asset_classes ac
                    ON ac.asset_id = ta.asset_id
                WHERE ta.theme_id = %s
                  AND ac.asset_class = %s
                """,
                (1, "Gold"),
            )

            target = db.fetchone()

            assert target is not None, (
                "Gold target was not found for Theme 1"
            )

            assert Decimal(
                str(target["allocation_pct"])
            ) == 0, (
                f"Expected Gold target 0%, got {target}"
            )

            print(
                "Gold target:",
                target["allocation_pct"],
                "%",
            )

            # 3. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_ZERO_TARGET_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 4. Add one GOLDBEES unit
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=security["security_id"],
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            # 5. Preview the rebalance
            preview = rebalancing_service.preview_rebalance(
                db, portfolio_id
            )

            print("\nPreview orders:")
            for order in preview:
                print(order)

            gold_order = next(
                (
                    order for order in preview
                    if order["symbol"] == "GOLDBEES"
                ),
                None,
            )

            assert gold_order is not None, (
                "Expected a GOLDBEES order"
            )
            assert gold_order["action"] == "SELL"
            assert gold_order["target_quantity"] == 0.0

            print(
                "\nPreview proposes selling the full holding."
            )

            # 6. Execute the rebalance safely
            db.execute("SAVEPOINT rebalance_attempt")

            try:
                executed = rebalancing_service.execute_rebalance(
                    db, portfolio_id
                )

                print("\nExecution returned:")
                print(executed)

                db.execute(
                    "RELEASE SAVEPOINT rebalance_attempt"
                )

            except Exception:
                db.execute(
                    "ROLLBACK TO SAVEPOINT rebalance_attempt"
                )
                db.execute(
                    "RELEASE SAVEPOINT rebalance_attempt"
                )
                raise

            # 7. Verify the holding was deleted
            db.execute(
                """
                SELECT quantity
                FROM holdings
                WHERE portfolio_id = %s
                  AND security_id = %s
                """,
                (portfolio_id, security["security_id"]),
            )

            holding = db.fetchone()

            assert holding is None, (
                "Expected the fully sold holding to be deleted"
            )

            print("\nHolding deleted successfully.")

            # 8. Verify the SELL transaction was recorded
            db.execute(
                """
                SELECT action, quantity, price
                FROM transactions
                WHERE portfolio_id = %s
                  AND security_id = %s
                ORDER BY  txn_id DESC 
                LIMIT 1
                """,
                (portfolio_id, security["security_id"]),
            )

            transaction = db.fetchone()

            assert transaction is not None, (
                "Expected a SELL transaction to be recorded"
            )
            assert transaction["action"] == "SELL"
            assert Decimal(
                str(transaction["quantity"])
            ) == Decimal("1.0")
            assert Decimal(
                str(transaction["price"])
            ) == current_price

            print("\nSELL transaction recorded successfully.")
            print("Transaction:", transaction)

            print("\nZero-target test PASSED.")

    finally:
        connection.rollback()
        print("Test transaction rolled back.")