from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.performance import service as performance_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Get the actual current price of NIFTYBEES
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE security_id = %s
                """,
                (6,),
            )

            security = db.fetchone()

            assert security is not None, "NIFTYBEES was not found"
            assert security["last_price"] is not None, (
                "NIFTYBEES has no current price"
            )

            current_price = Decimal(str(security["last_price"]))

            print("Security:", security["symbol"])
            print("Current price:", current_price)

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_PERFORMANCE_ALLOCATION_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one NIFTYBEES unit
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=6,
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            # 4. Call the actual Performance service
            allocation = performance_service.get_allocation(
                db, portfolio_id
            )

            print("\nPortfolio ID:", portfolio_id)
            print("Allocation result:")

            for row in allocation:
                print(dict(row))

            # 5. Verify the Broad Market ETF allocation
            broad_etf = next(
                (
                    row for row in allocation
                    if row["asset_class"] == "Broad Market ETF"
                ),
                None,
            )

            assert broad_etf is not None, (
                "Broad Market ETF allocation was not returned"
            )

            actual_value = Decimal(
                str(broad_etf["current_value"])
            )

            actual_target = Decimal(
                str(broad_etf["target_pct"])
            )

            assert actual_value == current_price, (
                f"Expected current value {current_price}, "
                f"got {actual_value}"
            )

            assert actual_target == Decimal("40"), (
                f"Expected target allocation 40, "
                f"got {actual_target}"
            )

            print("\nPASS: Allocation values are correct.")

    finally:
        # Remove all temporary test changes
        connection.rollback()
        print("Test transaction rolled back.")