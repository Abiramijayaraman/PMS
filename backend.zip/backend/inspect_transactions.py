from psycopg2.extras import RealDictCursor
from app.core.database import get_connection

with get_connection() as connection:
    with connection.cursor(
        cursor_factory=RealDictCursor
    ) as db:
        db.execute(
            """
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_schema = 'public'
              AND table_name = 'transactions'
            ORDER BY ordinal_position
            """
        )

        columns = db.fetchall()

        print("Transactions table columns:")
        for column in columns:
            print(column)