from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.rebalancing import service as rebalancing_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Get NIFTYBEES
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE symbol = %s
                """,
                ("NIFTYBEES",),
            )

            security = db.fetchone()

            assert security is not None, (
                "NIFTYBEES was not found"
            )
            assert security["last_price"] is not None, (
                "NIFTYBEES has no current price"
            )

            current_price = Decimal(
                str(security["last_price"])
            )

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_REBALANCING_EXECUTE_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one NIFTYBEES unit
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=security["security_id"],
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            # 4. Execute the rebalance
            orders = rebalancing_service.execute_rebalance(
                db, portfolio_id
            )

            print("Portfolio ID:", portfolio_id)
            print("\nExecuted orders:")

            for order in orders:
                print(order)

            # 5. Verify the updated holding
            db.execute(
                """
                SELECT holding_id, security_id, quantity
                FROM holdings
                WHERE portfolio_id = %s
                  AND security_id = %s
                """,
                (portfolio_id, security["security_id"]),
            )

            holding = db.fetchone()

            assert holding is not None, (
                "Holding was not found after rebalance"
            )

            actual_quantity = Decimal(str(holding["quantity"]))

            print("\nUpdated holding:")
            print(dict(holding))

            assert actual_quantity == Decimal("0.4"), (
                f"Expected quantity 0.4, got {actual_quantity}"
            )

            # 6. Verify the transaction log
            transactions = holdings_repository.list_transactions(
                db, portfolio_id
            )

            print("\nTransactions:")
            for transaction in transactions:
                print(dict(transaction))

            sell_transaction = next(
                (
                    transaction for transaction in transactions
                    if transaction["action"] == "SELL"
                    and transaction["symbol"] == "NIFTYBEES"
                ),
                None,
            )

            assert sell_transaction is not None, (
                "SELL transaction was not recorded"
            )

            assert Decimal(
                str(sell_transaction["quantity"])
            ) == Decimal("0.6"), (
                "SELL transaction quantity was not 0.6"
            )

            print("\nPASS: Holding quantity updated to 0.4.")
            print("PASS: SELL transaction for 0.6 was recorded.")

    finally:
        # Undo all temporary test data
        connection.rollback()
        print("Test transaction rolled back.")