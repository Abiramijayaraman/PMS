import csv
import getpass
import json
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import date
from pathlib import Path


BASE_URL = "http://127.0.0.1:8000"
PORTFOLIO_ID = 1
THEME_ID = 1
ISSUER_ID = 1
START_DATE = "2022-10-03"
END_DATE = date.today().isoformat()
REPORT_FILE = "full_regression_report.csv"


# ---------------------------------------------------------
# HTTP CLIENT
# ---------------------------------------------------------

def api_request(method, path, token=None, body=None, timeout=30):
    headers = {"Accept": "application/json"}

    if token:
        headers["Authorization"] = f"Bearer {token}"

    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")

    request = urllib.request.Request(
        BASE_URL + path,
        data=data,
        headers=headers,
        method=method,
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return (
                response.status,
                response.read().decode("utf-8", errors="replace"),
            )

    except urllib.error.HTTPError as exc:
        return (
            exc.code,
            exc.read().decode("utf-8", errors="replace"),
        )

    except Exception as exc:
        return 0, str(exc)


def parse_json(response):
    try:
        return json.loads(response)
    except (json.JSONDecodeError, TypeError):
        return None


# ---------------------------------------------------------
# TEST REPORTING
# ---------------------------------------------------------

results = []


def record(name, status, passed, details=""):
    result = {
        "test": name,
        "status": status,
        "result": "PASS" if passed else "FAIL",
        "details": str(details)[:1000],
    }

    results.append(result)

    print(
        f"[{'PASS' if passed else 'FAIL'}] "
        f"{name:<42} HTTP {status}"
    )

    if not passed and details:
        print(f"       {str(details)[:400]}")


def check_status(name, status, response, expected):
    passed = status in expected
    record(
        name,
        status,
        passed,
        "" if passed else response,
    )
    return passed


def save_report():
    with open(REPORT_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=["test", "status", "result", "details"],
        )
        writer.writeheader()
        writer.writerows(results)


# ---------------------------------------------------------
# LOGIN
# ---------------------------------------------------------

def login():
    print("\n=== PMS Full Regression Test ===")

    email = input("Login email: ").strip()
    password = getpass.getpass("Login password: ")

    status, response = api_request(
        "POST",
        "/auth/login",
        body={
            "email": email,
            "password": password,
        },
    )

    if not 200 <= status < 300:
        print(f"\nLOGIN FAILED: HTTP {status}")
        print(response)
        return None

    data = parse_json(response)

    if not isinstance(data, dict) or not data.get("access_token"):
        print("Login succeeded, but access_token was not found.")
        print(response)
        return None

    record("Login", status, True)
    return data["access_token"]


# ---------------------------------------------------------
# READ-ONLY ENDPOINT REGRESSION
# ---------------------------------------------------------

def test_get_endpoints(token):
    print("\n=== 1. GET Endpoint Tests ===\n")

    portfolio = f"/portfolios/{PORTFOLIO_ID}"
    benchmark = urllib.parse.quote("^NSEI", safe="")

    date_query = urllib.parse.urlencode({
        "start_date": START_DATE,
        "end_date": END_DATE,
    })

    tests = [
        ("Health", "/health", False),

        ("Portfolios list", "/portfolios", True),
        ("Portfolio details", portfolio, True),
        ("Portfolio holdings", portfolio + "/holdings", True),
        ("Portfolio budget", portfolio + "/budget", True),
        ("Portfolio transactions", portfolio + "/transactions", True),

        (
            "Security search",
            "/securities/search?q=RELIANCE",
            True,
        ),

        ("Themes", "/themes", True),
        (
            "Theme allocation",
            f"/themes/{THEME_ID}/allocation",
            True,
        ),

        ("Asset classes", "/asset-classes", True),
        (
            "Portfolio allocation",
            portfolio + "/allocation",
            True,
        ),
        (
            "Portfolio performance",
            portfolio + "/performance",
            True,
        ),
        (
            "Portfolio sector breakdown",
            portfolio + "/sector-breakdown",
            True,
        ),
        ("Portfolio drift", portfolio + "/drift", True),
        (
            "Rebalance preview",
            portfolio + "/rebalance/preview",
            True,
        ),

        (
            "Security price history",
            "/market-data/securities/RELIANCE/history?"
            + date_query,
            True,
        ),
        (
            "Benchmark history",
            f"/market-data/benchmarks/{benchmark}/history?"
            + date_query,
            True,
        ),

        (
            "Database summary",
            "/data-quality/database-summary",
            True,
        ),
        (
            "Duplicate counts",
            "/data-quality/duplicate-counts",
            True,
        ),
        (
            "Price history coverage",
            "/data-quality/price-history-coverage",
            True,
        ),
        (
            "Import runs",
            "/data-quality/import-runs?limit=10",
            True,
        ),

        ("Issuer list", "/classification/issuers", True),
        (
            "Issuer details",
            f"/classification/issuers/{ISSUER_ID}",
            True,
        ),
        (
            "Issuer classifications",
            f"/classification/issuers/{ISSUER_ID}/classifications",
            True,
        ),
    ]

    # Verify a protected endpoint rejects a missing token.
    status, response = api_request("GET", "/portfolios")
    check_status(
        "Missing token is rejected",
        status,
        response,
        {401, 403},
    )

    for name, path, protected in tests:
        status, response = api_request(
            "GET",
            path,
            token=token if protected else None,
        )
        check_status(name, status, response, set(range(200, 300)))


# ---------------------------------------------------------
# INVALID WRITE VALIDATION
# ---------------------------------------------------------

def test_invalid_writes(token):
    print("\n=== 2. Invalid Write Validation ===\n")

    tests = [
        (
            "Empty portfolio body returns 422",
            "/portfolios",
        ),
        (
            "Empty holding body returns 422",
            "/portfolios/1/holdings",
        ),
        (
            "Empty issuer body returns 422",
            "/classification/issuers",
        ),
        (
            "Empty classification body returns 422",
            "/classification/classifications",
        ),
    ]

    for name, path in tests:
        status, response = api_request(
            "POST",
            path,
            token=token,
            body={},
        )

        check_status(name, status, response, {422})


# ---------------------------------------------------------
# SUCCESSFUL PORTFOLIO LIFECYCLE
# ---------------------------------------------------------

def test_portfolio_lifecycle(token):
    print("\n=== 3. Portfolio Create / Update / Close ===\n")

    portfolio_id = None
    closed = False

    test_name = "REGRESSION_" + uuid.uuid4().hex[:12]
    updated_name = test_name + "_UPDATED"

    create_body = {
        "portfolio_name": test_name,
        "portfolio_type": "WEIGHTAGE",
        "theme_id": THEME_ID,
        "rebalancing_frequency": "MONTHLY",
        "initial_investment": 10000,
        "currency": "INR",
        "exchange": "NSE",
        "benchmark_symbol": "^NSEI",
    }

    try:
        # 1. Create
        status, response = api_request(
            "POST",
            "/portfolios",
            token=token,
            body=create_body,
        )

        created = parse_json(response)

        if not check_status(
            "Create temporary portfolio",
            status,
            response,
            set(range(200, 300)),
        ):
            return

        if not isinstance(created, dict):
            record(
                "Create response contains portfolio ID",
                status,
                False,
                "Response was not a JSON object.",
            )
            return

        portfolio_id = created.get("portfolio_id")

        if not portfolio_id:
            record(
                "Create response contains portfolio ID",
                status,
                False,
                response,
            )
            return

        record(
            "Create response contains portfolio ID",
            status,
            True,
            f"ID={portfolio_id}",
        )

        # 2. Fetch and verify persisted values
        status, response = api_request(
            "GET",
            f"/portfolios/{portfolio_id}",
            token=token,
        )

        fetched = parse_json(response)

        valid = (
            200 <= status < 300
            and isinstance(fetched, dict)
            and fetched.get("portfolio_name") == test_name
            and float(fetched.get("initial_investment", 0)) == 10000
        )

        record(
            "Verify created portfolio data",
            status,
            valid,
            "" if valid else response,
        )

        if not valid:
            return

        # 3. Update name
        status, response = api_request(
            "PATCH",
            f"/portfolios/{portfolio_id}",
            token=token,
            body={"portfolio_name": updated_name},
        )

        check_status(
            "Update temporary portfolio",
            status,
            response,
            set(range(200, 300)),
        )

        # 4. Read again to verify update persisted
        status, response = api_request(
            "GET",
            f"/portfolios/{portfolio_id}",
            token=token,
        )

        fetched = parse_json(response)

        valid = (
            200 <= status < 300
            and isinstance(fetched, dict)
            and fetched.get("portfolio_name") == updated_name
        )

        record(
            "Verify portfolio update persisted",
            status,
            valid,
            "" if valid else response,
        )

        # 5. Soft close
        status, response = api_request(
            "DELETE",
            f"/portfolios/{portfolio_id}",
            token=token,
        )

        close_ok = check_status(
            "Soft-close temporary portfolio",
            status,
            response,
            set(range(200, 300)),
        )

        if not close_ok:
            return

        closed = True

        # 6. Verify CLOSED status
        status, response = api_request(
            "GET",
            f"/portfolios/{portfolio_id}",
            token=token,
        )

        fetched = parse_json(response)

        valid = (
            200 <= status < 300
            and isinstance(fetched, dict)
            and fetched.get("status") == "CLOSED"
        )

        record(
            "Verify portfolio status is CLOSED",
            status,
            valid,
            "" if valid else response,
        )

    finally:
        # Best-effort cleanup if the test failed before closure.
        # Only ever targets the portfolio created by this run.
        if portfolio_id and not closed:
            print(
                "\nCleanup: attempting to close temporary "
                f"portfolio {portfolio_id}..."
            )

            status, response = api_request(
                "DELETE",
                f"/portfolios/{portfolio_id}",
                token=token,
            )

            if 200 <= status < 300:
                print("Cleanup close request succeeded.")
            else:
                print(
                    "WARNING: automatic cleanup failed. "
                    f"Portfolio ID: {portfolio_id}"
                )
                print(f"HTTP {status}: {response}")


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------

def main():
    token = login()

    if not token:
        return

    try:
        test_get_endpoints(token)
        test_invalid_writes(token)
        test_portfolio_lifecycle(token)

    except KeyboardInterrupt:
        print("\nTest run interrupted by user.")

    except Exception as exc:
        record(
            "Unexpected test-run error",
            0,
            False,
            repr(exc),
        )

    finally:
        save_report()

        passed = sum(
            item["result"] == "PASS"
            for item in results
        )
        failed = sum(
            item["result"] == "FAIL"
            for item in results
        )

        print("\n=== FINAL REGRESSION SUMMARY ===")
        print(f"Total tests : {len(results)}")
        print(f"Passed      : {passed}")
        print(f"Failed      : {failed}")

        if results:
            print(f"Pass rate   : {passed / len(results) * 100:.1f}%")

        print(f"CSV report  : {Path(REPORT_FILE).resolve()}")

        if failed:
            print("\nReview failed tests in the CSV report.")
        else:
            print("\nAll tests in this suite passed.")


if __name__ == "__main__":
    main()