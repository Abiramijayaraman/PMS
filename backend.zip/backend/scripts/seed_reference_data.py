"""
Convenience wrapper: runs the 01-04 SQL files in order against
DATABASE_URL. Equivalent to running each file with psql yourself.

Usage:
    python scripts/seed_reference_data.py
"""
import sys
from pathlib import Path
import psycopg2

sys.path.append(str(Path(__file__).resolve().parents[1]))
from app.core.config import settings  # noqa: E402

SQL_DIR = Path(__file__).resolve().parents[1] / "sql"
FILES_IN_ORDER = [
    "01_create_tables.sql",
    "02_indexes.sql",
    "03_seed_reference_data.sql",
    "04_seed_demo_securities.sql",
]

if __name__ == "__main__":
    conn = psycopg2.connect(settings.database_url)
    conn.autocommit = True
    try:
        with conn.cursor() as cur:
            for filename in FILES_IN_ORDER:
                print(f"Running {filename} ...")
                cur.execute((SQL_DIR / filename).read_text())
        print("All SQL files applied successfully.")
    finally:
        conn.close()
