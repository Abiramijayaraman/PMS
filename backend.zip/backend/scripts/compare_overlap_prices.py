import csv
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path


# --------------------------------------------------
# 1. Paths
# --------------------------------------------------

BACKEND_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BACKEND_DIR / "data" / "DATA_PMS"
REPORT_DIR = BACKEND_DIR / "scripts" / "reports"

OUTPUT_FILE = REPORT_DIR / "csv_overlap_price_comparison.csv"


# --------------------------------------------------
# 2. Helpers
# --------------------------------------------------

def normalize_header(header):
    return (header or "").strip().upper()


def parse_source_date(value):
    value = (value or "").strip()

    if not value:
        return None

    from datetime import datetime

    for date_format in ("%d-%b-%Y", "%d-%B-%Y"):
        try:
            return datetime.strptime(
                value.title(), date_format
            ).date()
        except ValueError:
            continue

    return None


def parse_price(value):
    value = (value or "").strip()

    if not value:
        return None

    try:
        price = Decimal(value.replace(",", ""))
    except InvalidOperation:
        return None

    if not price.is_finite():
        return None

    return price


# --------------------------------------------------
# 3. Collect prices by instrument and date
# --------------------------------------------------

def main():
    if not DATA_DIR.exists():
        raise FileNotFoundError(
            f"Data directory not found: {DATA_DIR}"
        )

    csv_files = sorted(DATA_DIR.rglob("*.csv"))

    # instrument -> date -> records from source files
    observations = defaultdict(
        lambda: defaultdict(list)
    )

    for file_path in csv_files:
        instrument = file_path.parent.relative_to(
            DATA_DIR
        ).as_posix()

        relative_path = file_path.relative_to(
            DATA_DIR
        ).as_posix()

        with file_path.open(
            "r", newline="", encoding="utf-8-sig"
        ) as file:
            reader = csv.DictReader(file)

            if not reader.fieldnames:
                continue

            header_map = {
                normalize_header(header): header
                for header in reader.fieldnames
            }

            date_column = header_map.get("DATE")
            close_column = header_map.get("CLOSE")

            if not date_column or not close_column:
                print(f"Skipping missing columns: {relative_path}")
                continue

            for row_number, row in enumerate(reader, start=2):
                date_value = parse_source_date(
                    row.get(date_column)
                )
                close_value = parse_price(
                    row.get(close_column)
                )

                if date_value is None or close_value is None:
                    continue

                observations[instrument][date_value].append({
                    "file": relative_path,
                    "row_number": row_number,
                    "close": close_value,
                })

    # --------------------------------------------------
    # 4. Compare dates shared by multiple files
    # --------------------------------------------------

    report_rows = []

    for instrument, date_map in observations.items():
        for date_value, records in sorted(date_map.items()):
            distinct_files = sorted({
                record["file"] for record in records
            })

            if len(distinct_files) < 2:
                continue

            prices = {record["close"] for record in records}

            if len(prices) == 1:
                status = "MATCH"
            else:
                status = "PRICE_CONFLICT"

            report_rows.append({
                "instrument_group": instrument,
                "date": date_value.isoformat(),
                "status": status,
                "file_count": len(distinct_files),
                "prices": " | ".join(
                    f'{record["file"]}: {record["close"]}'
                    for record in records
                ),
            })

    # --------------------------------------------------
    # 5. Write report
    # --------------------------------------------------

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "instrument_group",
        "date",
        "status",
        "file_count",
        "prices",
    ]

    with OUTPUT_FILE.open(
        "w", newline="", encoding="utf-8-sig"
    ) as file:
        writer = csv.DictWriter(
            file, fieldnames=fieldnames
        )
        writer.writeheader()
        writer.writerows(report_rows)

    matches = sum(
        row["status"] == "MATCH"
        for row in report_rows
    )

    conflicts = sum(
        row["status"] == "PRICE_CONFLICT"
        for row in report_rows
    )

    print("Overlap price comparison completed.")
    print(f"CSV files scanned: {len(csv_files)}")
    print(f"Overlapping instrument/date pairs: {len(report_rows)}")
    print(f"Matching prices: {matches}")
    print(f"Price conflicts: {conflicts}")
    print(f"Report: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()