"""
Loads your 4-year CSVs into price_history / benchmark_history.

Expected CSV shape (one file per symbol), matching the yfinance script
from earlier in this project:
    price_date, price, security_id   <- security_id column here is actually
                                         the SYMBOL string (e.g. "RELIANCE"),
                                         we resolve it to the real bigint
                                         security_id below.

Usage:
    python scripts/backfill_price_history.py --data-dir ./data
"""
import argparse
import sys
from pathlib import Path

import pandas as pd
import psycopg2
from psycopg2.extras import execute_values

sys.path.append(str(Path(__file__).resolve().parents[1]))
from app.core.config import settings  # noqa: E402


def get_security_id_map(conn) -> dict:
    with conn.cursor() as cur:
        cur.execute("SELECT symbol, security_id FROM securities")
        return {row[0]: row[1] for row in cur.fetchall()}


def load_equity_and_etf_csvs(conn, data_dir: Path):
    symbol_map = get_security_id_map(conn)
    csv_files = sorted(data_dir.glob("*.csv"))
    csv_files = [f for f in csv_files if "NIFTY50_benchmark" not in f.name]

    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO data_import_runs (dataset_name, source_name) VALUES (%s, %s) RETURNING import_id",
            ("price_history_backfill", "yfinance/local_csv"),
        )
        import_id = cur.fetchone()[0]
    conn.commit()

    total_rows, inserted, rejected = 0, 0, 0

    for csv_file in csv_files:
        symbol = csv_file.stem.replace(".NS", "")
        security_id = symbol_map.get(symbol)
        if security_id is None:
            print(f"  SKIP {symbol}: not found in securities table - seed it first via 04_seed_demo_securities.sql")
            rejected += 1
            continue

        df = pd.read_csv(csv_file)
        total_rows += len(df)

        rows = [
            (security_id, row["price_date"], float(row["price"]), "yfinance")
            for _, row in df.iterrows()
        ]

        with conn.cursor() as cur:
            execute_values(
                cur,
                """
                INSERT INTO price_history (security_id, price_date, close_price, source)
                VALUES %s
                ON CONFLICT (security_id, price_date)
                DO UPDATE SET close_price = EXCLUDED.close_price
                """,
                rows,
            )
        conn.commit()
        inserted += len(rows)
        print(f"  {symbol}: {len(rows)} rows loaded")

    with conn.cursor() as cur:
        cur.execute(
            "UPDATE data_import_runs SET completed_at = NOW(), status = 'COMPLETED', rows_read = %s, rows_inserted = %s, rows_rejected = %s WHERE import_id = %s",
            (total_rows, inserted, rejected, import_id),
        )
    conn.commit()
    print(f"\nDone: {inserted} rows inserted, {rejected} symbols skipped (import_id={import_id})")


def load_benchmark_csv(conn, data_dir: Path):
    benchmark_file = data_dir / "NIFTY50_benchmark.csv"
    if not benchmark_file.exists():
        print("  No NIFTY50_benchmark.csv found - skipping benchmark load")
        return

    df = pd.read_csv(benchmark_file)
    rows = [
        (row["benchmark_name"], row["price_date"], float(row["value"]), "yfinance")
        for _, row in df.iterrows()
    ]
    with conn.cursor() as cur:
        execute_values(
            cur,
            """
            INSERT INTO benchmark_history (benchmark_symbol, price_date, close_price, source)
            VALUES %s
            ON CONFLICT (benchmark_symbol, price_date)
            DO UPDATE SET close_price = EXCLUDED.close_price
            """,
            rows,
        )
    conn.commit()
    print(f"  NIFTY50 benchmark: {len(rows)} rows loaded")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="./data")
    args = parser.parse_args()

    conn = psycopg2.connect(settings.database_url)
    try:
        print("Loading equity + ETF/REIT price history...")
        load_equity_and_etf_csvs(conn, Path(args.data_dir))
        print("\nLoading benchmark history...")
        load_benchmark_csv(conn, Path(args.data_dir))
    finally:
        conn.close()
