import csv
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path


# --------------------------------------------------
# 1. Paths
# --------------------------------------------------

BACKEND_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BACKEND_DIR / "data" / "DATA_PMS"
REPORT_DIR = BACKEND_DIR / "scripts" / "reports"

SUMMARY_FILE = REPORT_DIR / "csv_audit_summary.csv"
ISSUES_FILE = REPORT_DIR / "csv_audit_issues.csv"
OVERLAPS_FILE = REPORT_DIR / "csv_date_overlaps.csv"


# --------------------------------------------------
# 2. Helpers
# --------------------------------------------------

def normalize_header(header):
    """Normalize a CSV column name."""
    return (header or "").strip().upper()


def parse_source_date(value):
    """Parse the date formats found in the source CSVs."""
    value = (value or "").strip()

    if not value:
        return None

    for date_format in ("%d-%b-%Y", "%d-%B-%Y"):
        try:
            return datetime.strptime(
                value.title(), date_format
            ).date()
        except ValueError:
            continue

    return None


def parse_price(value):
    """Parse a price, allowing thousands separators."""
    value = (value or "").strip()

    if not value:
        return None

    try:
        price = Decimal(value.replace(",", ""))
    except InvalidOperation:
        return None

    if not price.is_finite() or price <= 0:
        return None

    return price


def write_csv(path, fieldnames, rows):
    """Write a report as a CSV file."""
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


# --------------------------------------------------
# 3. Audit one CSV file
# --------------------------------------------------

def audit_file(file_path):
    relative_path = file_path.relative_to(DATA_DIR).as_posix()

    # Group files by their containing instrument folder.
    instrument = file_path.parent.relative_to(DATA_DIR).as_posix()

    summary = {
        "file": relative_path,
        "instrument_group": instrument,
        "status": "OK",
        "row_count": 0,
        "date_column": "",
        "close_column": "",
        "valid_dates": 0,
        "valid_close_prices": 0,
        "missing_dates": 0,
        "invalid_dates": 0,
        "missing_close_prices": 0,
        "invalid_close_prices": 0,
        "duplicate_dates": 0,
        "min_date": "",
        "max_date": "",
        "error": "",
    }

    issues = []
    dates_by_file = defaultdict(list)
    seen_dates = set()
    valid_dates = []

    try:
        with file_path.open(
            "r", newline="", encoding="utf-8-sig"
        ) as file:
            reader = csv.DictReader(file)

            if not reader.fieldnames:
                summary["status"] = "ERROR"
                summary["error"] = "Missing CSV header"
                return summary, issues, dates_by_file

            # Strip whitespace and normalize case.
            original_headers = reader.fieldnames
            normalized_headers = [
                normalize_header(header)
                for header in original_headers
            ]

            # Map normalized names back to the original names.
            header_map = dict(zip(normalized_headers, original_headers))

            date_column = "DATE"
            close_column = "CLOSE"

            summary["date_column"] = (
                date_column if date_column in header_map else ""
            )
            summary["close_column"] = (
                close_column if close_column in header_map else ""
            )

            missing_columns = [
                column
                for column in (date_column, close_column)
                if column not in header_map
            ]

            if missing_columns:
                summary["status"] = "ERROR"
                summary["error"] = (
                    "Missing required columns: "
                    + ", ".join(missing_columns)
                )
                return summary, issues, dates_by_file

            actual_date_column = header_map[date_column]
            actual_close_column = header_map[close_column]

            for row_number, row in enumerate(reader, start=2):
                summary["row_count"] += 1

                raw_date = row.get(actual_date_column)
                raw_close = row.get(actual_close_column)

                parsed_date = parse_source_date(raw_date)
                parsed_close = parse_price(raw_close)

                # Validate date.
                if not (raw_date or "").strip():
                    summary["missing_dates"] += 1
                    issues.append({
                        "file": relative_path,
                        "row_number": row_number,
                        "issue": "MISSING_DATE",
                        "value": "",
                    })
                elif parsed_date is None:
                    summary["invalid_dates"] += 1
                    issues.append({
                        "file": relative_path,
                        "row_number": row_number,
                        "issue": "INVALID_DATE",
                        "value": raw_date,
                    })
                else:
                    summary["valid_dates"] += 1
                    valid_dates.append(parsed_date)
                    dates_by_file[parsed_date].append(relative_path)

                    if parsed_date in seen_dates:
                        summary["duplicate_dates"] += 1
                        issues.append({
                            "file": relative_path,
                            "row_number": row_number,
                            "issue": "DUPLICATE_DATE_IN_FILE",
                            "value": str(parsed_date),
                        })
                    else:
                        seen_dates.add(parsed_date)

                # Validate closing price.
                if not (raw_close or "").strip():
                    summary["missing_close_prices"] += 1
                    issues.append({
                        "file": relative_path,
                        "row_number": row_number,
                        "issue": "MISSING_CLOSE_PRICE",
                        "value": "",
                    })
                elif parsed_close is None:
                    summary["invalid_close_prices"] += 1
                    issues.append({
                        "file": relative_path,
                        "row_number": row_number,
                        "issue": "INVALID_CLOSE_PRICE",
                        "value": raw_close,
                    })
                else:
                    summary["valid_close_prices"] += 1

        if valid_dates:
            summary["min_date"] = min(valid_dates).isoformat()
            summary["max_date"] = max(valid_dates).isoformat()

        if summary["row_count"] == 0:
            summary["status"] = "WARNING"
            summary["error"] = "CSV contains no data rows"
        elif (
            summary["missing_dates"]
            or summary["invalid_dates"]
            or summary["missing_close_prices"]
            or summary["invalid_close_prices"]
            or summary["duplicate_dates"]
        ):
            summary["status"] = "REVIEW"

    except (OSError, csv.Error, UnicodeError) as exc:
        summary["status"] = "ERROR"
        summary["error"] = str(exc)

    return summary, issues, dates_by_file


# --------------------------------------------------
# 4. Audit all CSV files
# --------------------------------------------------

def main():
    if not DATA_DIR.exists():
        raise FileNotFoundError(
            f"Data directory not found: {DATA_DIR}"
        )

    csv_files = sorted(DATA_DIR.rglob("*.csv"))

    if not csv_files:
        raise FileNotFoundError(
            f"No CSV files found under: {DATA_DIR}"
        )

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    summaries = []
    all_issues = []

    # Group dates by instrument folder, then by date.
    dates_by_instrument = defaultdict(
        lambda: defaultdict(list)
    )

    for file_path in csv_files:
        summary, issues, dates_by_file = audit_file(file_path)

        summaries.append(summary)
        all_issues.extend(issues)

        instrument = summary["instrument_group"]

        for date_value, files in dates_by_file.items():
            dates_by_instrument[instrument][date_value].extend(files)

    # Find dates present in more than one file
    # belonging to the same instrument folder.
    overlaps = []

    for instrument, date_map in dates_by_instrument.items():
        for date_value, files in sorted(date_map.items()):
            unique_files = sorted(set(files))

            if len(unique_files) > 1:
                overlaps.append({
                    "instrument_group": instrument,
                    "date": date_value.isoformat(),
                    "file_count": len(unique_files),
                    "files": " | ".join(unique_files),
                })

    write_csv(
        SUMMARY_FILE,
        list(summaries[0].keys()),
        summaries,
    )

    write_csv(
        ISSUES_FILE,
        ["file", "row_number", "issue", "value"],
        all_issues,
    )

    write_csv(
        OVERLAPS_FILE,
        ["instrument_group", "date", "file_count", "files"],
        overlaps,
    )

    print("CSV audit completed.")
    print(f"Files scanned: {len(csv_files)}")
    print(f"Files with errors: {sum(s['status'] == 'ERROR' for s in summaries)}")
    print(f"Files needing review: {sum(s['status'] == 'REVIEW' for s in summaries)}")
    print(f"Issues recorded: {len(all_issues)}")
    print(f"Cross-file overlapping dates: {len(overlaps)}")
    print()
    print(f"Summary report: {SUMMARY_FILE}")
    print(f"Issues report:  {ISSUES_FILE}")
    print(f"Overlap report: {OVERLAPS_FILE}")


if __name__ == "__main__":
    main()