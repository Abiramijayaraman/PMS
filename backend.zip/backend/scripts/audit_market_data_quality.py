import csv
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path


BACKEND_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BACKEND_DIR / "data" / "DATA_PMS"
REPORT_DIR = BACKEND_DIR / "scripts" / "reports"

OUTPUT_FILE = REPORT_DIR / "csv_data_quality_issues.csv"
SUMMARY_FILE = REPORT_DIR / "csv_data_quality_summary.csv"


def normalize_header(value):
    return (value or "").strip().upper()


def parse_date(value):
    value = (value or "").strip()

    for fmt in ("%d-%b-%Y", "%d-%B-%Y"):
        try:
            return datetime.strptime(value.title(), fmt).date()
        except ValueError:
            pass

    return None


def parse_number(value):
    value = (value or "").strip()

    if not value:
        return None

    try:
        number = Decimal(value.replace(",", ""))
    except InvalidOperation:
        return None

    if not number.is_finite():
        return None

    return number


def add_issue(issues, file_name, row_number, issue, details):
    issues.append({
        "file": file_name,
        "row_number": row_number,
        "issue": issue,
        "details": details,
    })


def audit_file(path):
    relative_path = path.relative_to(DATA_DIR).as_posix()

    issues = []
    dates = []
    row_count = 0
    numeric_missing = 0
    numeric_invalid = 0

    try:
        with path.open(
            "r", newline="", encoding="utf-8-sig"
        ) as file:
            reader = csv.DictReader(file)

            if not reader.fieldnames:
                add_issue(
                    issues, relative_path, "",
                    "MISSING_HEADER", "CSV has no header"
                )
                return make_summary(
                    relative_path, 0, dates, issues,
                    numeric_missing, numeric_invalid
                ), issues

            headers = {
                normalize_header(header): header
                for header in reader.fieldnames
            }

            required = ["DATE", "OPEN", "HIGH", "LOW", "CLOSE"]
            missing = [name for name in required if name not in headers]

            if missing:
                add_issue(
                    issues, relative_path, "",
                    "MISSING_REQUIRED_COLUMNS",
                    ", ".join(missing)
                )

            date_column = headers.get("DATE")

            # Numeric fields: all columns except DATE and SERIES.
            numeric_columns = [
                (normalized, original)
                for normalized, original in headers.items()
                if normalized not in {"DATE", "SERIES"}
            ]

            previous_date = None
            date_directions = []

            for row_number, row in enumerate(reader, start=2):
                row_count += 1

                # Date validation and ordering.
                raw_date = row.get(date_column) if date_column else ""
                current_date = parse_date(raw_date)

                if not (raw_date or "").strip():
                    add_issue(
                        issues, relative_path, row_number,
                        "MISSING_DATE", ""
                    )
                elif current_date is None:
                    add_issue(
                        issues, relative_path, row_number,
                        "INVALID_DATE", str(raw_date)
                    )
                else:
                    dates.append(current_date)

                    if previous_date is not None:
                        if current_date < previous_date:
                            date_directions.append("DESCENDING")
                        elif current_date > previous_date:
                            date_directions.append("ASCENDING")

                    previous_date = current_date

                # Parse numeric columns.
                values = {}

                for normalized, original in numeric_columns:
                    raw_value = row.get(original)
                    number = parse_number(raw_value)

                    if not (raw_value or "").strip():
                        numeric_missing += 1
                        add_issue(
                            issues, relative_path, row_number,
                            "MISSING_NUMERIC_VALUE",
                            normalized
                        )
                    elif number is None:
                        numeric_invalid += 1
                        add_issue(
                            issues, relative_path, row_number,
                            "INVALID_NUMERIC_VALUE",
                            f"{normalized}={raw_value}"
                        )
                    else:
                        values[normalized] = number

                # OHLC checks where the relevant columns exist
                # and all values parsed successfully.
                ohlc_names = ["OPEN", "HIGH", "LOW", "CLOSE"]

                if all(name in values for name in ohlc_names):
                    open_price = values["OPEN"]
                    high_price = values["HIGH"]
                    low_price = values["LOW"]
                    close_price = values["CLOSE"]

                    if high_price < low_price:
                        add_issue(
                            issues, relative_path, row_number,
                            "HIGH_BELOW_LOW",
                            f"HIGH={high_price}; LOW={low_price}"
                        )

                    if not (
                        low_price <= open_price <= high_price
                    ):
                        add_issue(
                            issues, relative_path, row_number,
                            "OPEN_OUTSIDE_DAILY_RANGE",
                            f"LOW={low_price}; OPEN={open_price}; "
                            f"HIGH={high_price}"
                        )

                    if not (
                        low_price <= close_price <= high_price
                    ):
                        add_issue(
                            issues, relative_path, row_number,
                            "CLOSE_OUTSIDE_DAILY_RANGE",
                            f"LOW={low_price}; CLOSE={close_price}; "
                            f"HIGH={high_price}"
                        )

                    if any(
                        values[name] <= 0
                        for name in ohlc_names
                    ):
                        add_issue(
                            issues, relative_path, row_number,
                            "NON_POSITIVE_OHLC_PRICE",
                            "One or more OHLC prices are <= 0"
                        )

    except (OSError, csv.Error, UnicodeError) as exc:
        add_issue(
            issues, relative_path, "",
            "FILE_READ_ERROR", str(exc)
        )

    # Detect duplicate dates within this file.
    date_counts = Counter(dates)

    for date_value, count in date_counts.items():
        if count > 1:
            add_issue(
                issues, relative_path, "",
                "DUPLICATE_DATE",
                f"{date_value}: appears {count} times"
            )

    # Identify inconsistent row ordering.
    directions = set(date_directions)

    if len(directions) > 1:
        add_issue(
            issues, relative_path, "",
            "INCONSISTENT_DATE_ORDER",
            "Dates switch between ascending and descending"
        )

    # Flag large calendar gaps for review, not as definite errors.
    unique_dates = sorted(set(dates))

    for earlier, later in zip(unique_dates, unique_dates[1:]):
        gap_days = (later - earlier).days

        if gap_days > 4:
            add_issue(
                issues, relative_path, "",
                "LARGE_DATE_GAP_REVIEW",
                f"{earlier} to {later}: {gap_days} calendar days"
            )

    summary = make_summary(
        relative_path, row_count, dates, issues,
        numeric_missing, numeric_invalid
    )

    return summary, issues


def make_summary(
    file_name, row_count, dates, issues,
    numeric_missing, numeric_invalid
):
    return {
        "file": file_name,
        "row_count": row_count,
        "min_date": min(dates).isoformat() if dates else "",
        "max_date": max(dates).isoformat() if dates else "",
        "issue_count": len(issues),
        "numeric_missing_values": numeric_missing,
        "numeric_invalid_values": numeric_invalid,
    }


def write_report(path, fieldnames, rows):
    with path.open(
        "w", newline="", encoding="utf-8-sig"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    if not DATA_DIR.exists():
        raise FileNotFoundError(
            f"Data directory not found: {DATA_DIR}"
        )

    files = sorted(DATA_DIR.rglob("*.csv"))

    if not files:
        raise FileNotFoundError("No CSV files found")

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    summaries = []
    all_issues = []

    for path in files:
        summary, issues = audit_file(path)
        summaries.append(summary)
        all_issues.extend(issues)

    write_report(
        SUMMARY_FILE,
        [
            "file", "row_count", "min_date", "max_date",
            "issue_count", "numeric_missing_values",
            "numeric_invalid_values",
        ],
        summaries,
    )

    write_report(
        OUTPUT_FILE,
        ["file", "row_number", "issue", "details"],
        all_issues,
    )

    issue_counts = Counter(
        issue["issue"] for issue in all_issues
    )

    print("Detailed data-quality audit completed.")
    print(f"Files scanned: {len(files)}")
    print(f"Total findings: {len(all_issues)}")
    print(f"Files with findings: {sum(s['issue_count'] > 0 for s in summaries)}")

    print("\nFindings by type:")
    if issue_counts:
        for issue_type, count in sorted(issue_counts.items()):
            print(f"  {issue_type}: {count}")
    else:
        print("  No findings")

    print(f"\nSummary report: {SUMMARY_FILE}")
    print(f"Issues report:  {OUTPUT_FILE}")


if __name__ == "__main__":
    main()