Generated audit/reconciliation reports (do not commit secrets).

Implementation will be added module-by-module after the plan is confirmed.
