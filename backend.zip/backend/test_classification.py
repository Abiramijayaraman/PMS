from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.classification import service
from app.modules.classification.schemas import (
    IssuerOut,
    IssuerClassificationOut,
)


def main():
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as db:

            # Test 1: List issuers through the service
            issuers = service.list_issuers(db)

            for issuer in issuers:
                IssuerOut(**issuer)

            print(
                f"PASS: list_issuers — {len(issuers)} issuers; "
                "schema validation successful"
            )

            # Test 2: Retrieve an issuer
            if issuers:
                issuer_id = issuers[0]["issuer_id"]

                issuer = service.get_issuer(db, issuer_id)

                assert issuer is not None
                IssuerOut(**issuer)

                print(
                    f"PASS: get_issuer — issuer ID {issuer_id}"
                )

                # Test 3: Retrieve classification history
                classifications = service.list_classifications(
                    db, issuer_id
                )

                for classification in classifications:
                    IssuerClassificationOut(**classification)

                print(
                    "PASS: list_classifications — "
                    f"{len(classifications)} records; "
                    "schema validation successful"
                )
            else:
                print(
                    "INFO: No issuers exist yet; "
                    "positive issuer lookup and classification "
                    "schema checks were skipped"
                )

            # Test 4: Non-existent issuer
            missing = service.get_issuer(db, -1)
            assert missing is None

            print(
                "PASS: Non-existent issuer returns None"
            )


if __name__ == "__main__":
    main()