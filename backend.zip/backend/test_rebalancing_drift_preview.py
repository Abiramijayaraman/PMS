from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.rebalancing import service as rebalancing_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Get NIFTYBEES
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE symbol = %s
                """,
                ("NIFTYBEES",),
            )

            security = db.fetchone()

            assert security is not None, (
                "NIFTYBEES was not found"
            )
            assert security["last_price"] is not None, (
                "NIFTYBEES has no current price"
            )

            current_price = Decimal(
                str(security["last_price"])
            )

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_REBALANCING_PREVIEW_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one NIFTYBEES unit
            holding = holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=security["security_id"],
                quantity=Decimal("1"),
                avg_price=current_price,
            )

            holding_id = holding["holding_id"]

            # 4. Capture the holding before preview
            db.execute(
                """
                SELECT quantity
                FROM holdings
                WHERE holding_id = %s
                """,
                (holding_id,),
            )
            quantity_before = db.fetchone()["quantity"]

            # 5. Generate the rebalance preview
            orders = rebalancing_service.preview_rebalance(
                db, portfolio_id
            )

            print("Portfolio ID:", portfolio_id)
            print("\nProposed orders:")

            for order in orders:
                print(order)

            # 6. Verify the NIFTYBEES order
            order = next(
                (
                    item for item in orders
                    if item["security_id"] == security["security_id"]
                ),
                None,
            )

            assert order is not None, (
                "Expected a NIFTYBEES rebalance order"
            )

            assert order["action"] == "SELL"
            assert order["current_quantity"] == 1.0
            assert order["target_quantity"] == 0.4
            assert order["delta_quantity"] == -0.6

            # 7. Confirm preview did not change the holding
            db.execute(
                """
                SELECT quantity
                FROM holdings
                WHERE holding_id = %s
                """,
                (holding_id,),
            )
            quantity_after = db.fetchone()["quantity"]

            assert quantity_after == quantity_before, (
                "Preview unexpectedly changed the holding"
            )

            print("\nQuantity before preview:", quantity_before)
            print("Quantity after preview:", quantity_after)
            print("\nPASS: Preview generated the expected SELL order.")
            print("PASS: Preview did not modify the holding.")

    finally:
        connection.rollback()
        print("Test transaction rolled back.")