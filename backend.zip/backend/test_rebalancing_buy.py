from decimal import Decimal
from psycopg2.extras import RealDictCursor

from app.core.database import get_connection
from app.modules.portfolios import repository as portfolio_repository
from app.modules.holdings import repository as holdings_repository
from app.modules.rebalancing import service as rebalancing_service


with get_connection() as connection:
    try:
        with connection.cursor(
            cursor_factory=RealDictCursor
        ) as db:

            # 1. Fetch HDFCBANK and NIFTYBEES
            db.execute(
                """
                SELECT security_id, symbol, last_price
                FROM securities
                WHERE symbol IN (%s, %s)
                ORDER BY symbol
                """,
                ("HDFCBANK", "NIFTYBEES"),
            )

            securities = {
                row["symbol"]: row
                for row in db.fetchall()
            }

            assert "HDFCBANK" in securities
            assert "NIFTYBEES" in securities

            for security in securities.values():
                assert security["last_price"] is not None, (
                    f"{security['symbol']} has no current price"
                )

            hdfc = securities["HDFCBANK"]
            nifty = securities["NIFTYBEES"]

            hdfc_price = Decimal(str(hdfc["last_price"]))
            nifty_price = Decimal(str(nifty["last_price"]))

            print("HDFCBANK price:", hdfc_price)
            print("NIFTYBEES price:", nifty_price)

            # 2. Create a temporary portfolio
            portfolio = portfolio_repository.insert_portfolio(
                db,
                user_id=1,
                data={
                    "portfolio_name": "TEMP_REBALANCING_BUY_TEST",
                    "portfolio_type": "AMOUNT",
                    "currency": "INR",
                    "exchange": "NSE",
                    "benchmark_symbol": "^NSEI",
                    "theme_id": 1,
                    "rebalancing_frequency": "MONTHLY",
                    "initial_investment": Decimal("100000"),
                },
            )

            portfolio_id = portfolio["portfolio_id"]

            # 3. Add one unit of each security
            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=hdfc["security_id"],
                quantity=Decimal("1"),
                avg_price=hdfc_price,
            )

            holdings_repository.insert_holding(
                db,
                portfolio_id=portfolio_id,
                security_id=nifty["security_id"],
                quantity=Decimal("1"),
                avg_price=nifty_price,
            )

            # 4. Execute the rebalance
            orders = rebalancing_service.execute_rebalance(
                db, portfolio_id
            )

            print("\nExecuted orders:")
            for order in orders:
                print(order)

            # 5. Find the NIFTYBEES BUY order
            buy_order = next(
                (
                    order for order in orders
                    if order["symbol"] == "NIFTYBEES"
                    and order["action"] == "BUY"
                ),
                None,
            )

            assert buy_order is not None, (
                "Expected a BUY order for NIFTYBEES"
            )

            assert buy_order["delta_quantity"] > 0
            assert buy_order["target_quantity"] > 1.0

            # 6. Verify the persisted holding quantity
            db.execute(
                """
                SELECT quantity
                FROM holdings
                WHERE portfolio_id = %s
                  AND security_id = %s
                """,
                (portfolio_id, nifty["security_id"]),
            )

            holding = db.fetchone()
            assert holding is not None

            actual_quantity = Decimal(str(holding["quantity"]))
            expected_quantity = Decimal(
                str(buy_order["target_quantity"])
            )

            assert actual_quantity == expected_quantity, (
                f"Expected {expected_quantity}, got {actual_quantity}"
            )

            # 7. Verify the BUY transaction
            transactions = holdings_repository.list_transactions(
                db, portfolio_id
            )

            buy_transaction = next(
                (
                    txn for txn in transactions
                    if txn["symbol"] == "NIFTYBEES"
                    and txn["action"] == "BUY"
                ),
                None,
            )

            assert buy_transaction is not None, (
                "BUY transaction was not recorded"
            )

            assert Decimal(
                str(buy_transaction["quantity"])
            ) == Decimal(str(buy_order["delta_quantity"]))

            print("\nNIFTYBEES quantity after rebalance:", actual_quantity)
            print("BUY transaction:")
            print(dict(buy_transaction))

            print("\nPASS: BUY order executed.")
            print("PASS: Holding quantity updated.")
            print("PASS: BUY transaction recorded.")

    finally:
        connection.rollback()
        print("Test transaction rolled back.")