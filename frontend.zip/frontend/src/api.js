import axios from 'axios';
export const API_BASE = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '');
export const http = axios.create({baseURL: API_BASE, timeout: 30000, withCredentials:true, headers:{'Content-Type':'application/json'}});
http.interceptors.request.use(config => { const token = localStorage.getItem('pms_access_token'); if(token) config.headers.Authorization = `Bearer ${token}`; return config; });
http.interceptors.response.use(r=>r, async error=>{ if(error.response?.status===401 && !error.config?._retried && localStorage.getItem('pms_access_token')) { try { const cfg=error.config; cfg._retried=true; const refreshed=await axios.post(`${API_BASE}/auth/refresh`,{}, {withCredentials:true}); const token=refreshed.data?.access_token; if(token){localStorage.setItem('pms_access_token',token);cfg.headers.Authorization=`Bearer ${token}`;return http(cfg);} } catch {} localStorage.removeItem('pms_access_token'); window.dispatchEvent(new Event('pms:logout')); } return Promise.reject(error); });
export const api = {
 login: async credentials => (await http.post('/auth/login',credentials)).data,
 logout: async()=>{try{await http.post('/auth/logout')}finally{localStorage.removeItem('pms_access_token');}},
 portfolios: async()=>unwrap((await http.get('/portfolios')).data),
 portfolio: async id=>(await http.get(`/portfolios/${id}`)).data,
 createPortfolio: async body=>(await http.post('/portfolios',body)).data,
 updatePortfolio: async(id,body)=>(await http.patch(`/portfolios/${id}`,body)).data,
 closePortfolio: async id=>(await http.delete(`/portfolios/${id}`)).data,
 holdings: async id=>unwrap((await http.get(`/portfolios/${id}/holdings`)).data),
 addHolding: async(id,body)=>(await http.post(`/portfolios/${id}/holdings`,body)).data,
 removeHolding: async(id,hid)=>(await http.delete(`/portfolios/${id}/holdings/${hid}`)).data,
 budget: async id=>(await http.get(`/portfolios/${id}/budget`)).data,
 transactions: async id=>unwrap((await http.get(`/portfolios/${id}/transactions`)).data),
 allocation: async id=>unwrap((await http.get(`/portfolios/${id}/allocation`)).data),
 performance: async id=>(await http.get(`/portfolios/${id}/performance`)).data,
 sectors: async id=>unwrap((await http.get(`/portfolios/${id}/sector-breakdown`)).data),
 drift: async id=>unwrap((await http.get(`/portfolios/${id}/drift`)).data),
 preview: async id=>(await http.get(`/portfolios/${id}/rebalance/preview`)).data,
 execute: async id=>(await http.post(`/portfolios/${id}/rebalance/execute`)).data,
 search: async q=>unwrap((await http.get('/securities/search',{params:{q}})).data),
 themes: async()=>unwrap((await http.get('/themes')).data),
 themeAllocation: async id=>unwrap((await http.get(`/themes/${id}/allocation`)).data),
 assetClasses: async()=>unwrap((await http.get('/asset-classes')).data),
 securityHistory: async(symbol,params={})=>unwrap((await http.get(`/market-data/securities/${encodeURIComponent(symbol)}/history`,{params})).data),
 benchmarkHistory: async(symbol,params={})=>unwrap((await http.get(`/market-data/benchmarks/${encodeURIComponent(symbol)}/history`,{params})).data),
 dbSummary: async()=>(await http.get('/data-quality/database-summary')).data,
 duplicates: async()=>unwrap((await http.get('/data-quality/duplicate-counts')).data),
 coverage: async()=>unwrap((await http.get('/data-quality/price-history-coverage')).data),
 imports: async()=>unwrap((await http.get('/data-quality/import-runs',{params:{limit:50}})).data),
 health: async()=>(await http.get('/health')).data,
};
export function unwrap(value){ if(Array.isArray(value)) return value; if(!value || typeof value!=='object') return []; for(const key of ['items','data','results','rows','records','portfolios','holdings','transactions','securities','themes','asset_classes','history','prices','allocation','drift','runs','issuers']) if(Array.isArray(value[key])) return value[key]; return []; }
export function messageOf(error){const d=error?.response?.data?.detail; if(Array.isArray(d)) return d.map(x=>x.msg).join('; '); return typeof d==='string'?d:(error?.message||'Something went wrong');}
