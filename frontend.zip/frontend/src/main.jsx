import React from 'react';import{createRoot}from'react-dom/client';import{QueryClient,QueryClientProvider}from'@tanstack/react-query';import App from'./App.jsx';import'./styles.css';
const queryClient=new QueryClient({defaultOptions:{queries:{staleTime:30_000,gcTime:5*60_000,retry:(n,e)=>e?.response?.status!==401&&n<1,refetchOnWindowFocus:false},mutations:{}}});
createRoot(document.getElementById('root')).render(<React.StrictMode><QueryClientProvider client={queryClient}><App/></QueryClientProvider></React.StrictMode>);
