# Northstar PMS Frontend

React + Vite frontend for the existing PMS FastAPI backend.

## Included
- Login using `POST /auth/login`; bearer token handling and refresh-cookie support.
- Portfolio dashboard, portfolio selector and create-portfolio form.
- Holdings table with search, pagination, add security and remove holding.
- Performance and allocation charts (Recharts), drift/risk alerts at the agreed 5% threshold.
- Rebalance preview and explicit confirmation before execute.
- Transactions table and CSV export; basic data-quality summary.
- TanStack Query request cache (30-second stale time), deduplication, retry policy and mutation invalidation.
- Responsive layout, loading/empty/error states.

## Run
1. Extract this folder alongside your `backend` folder.
2. Install Node.js 20+ (your existing Node 22 is suitable).
3. Copy `.env.example` to `.env` and confirm `VITE_API_BASE_URL=http://127.0.0.1:8000`.
4. From this folder:
   ```bash
   npm install
   npm run dev
   ```
5. Open `http://localhost:5173`.
6. Start FastAPI separately from the backend folder:
   ```bash
   python -m uvicorn app.main:app --reload
   ```

## Important integration notes
- This UI is built against the endpoint paths in the supplied backend `openapi.json`.
- Several endpoints have untyped `{}` response schemas in OpenAPI. The UI therefore tolerates common list wrappers and field aliases. Compare displayed fields with actual API responses in Swagger; adjust `pick()` aliases in `src/App.jsx` if your exact response keys differ.
- API list endpoints do not expose server-side pagination in the supplied OpenAPI. Tables paginate the returned result set in the browser. For very large histories, add server-side `limit`/`offset` or cursor pagination to FastAPI and wire it into the query keys before production scale.
- Historical benchmark values are labeled as price-index comparisons; they are not assumed to be total-return data. Chart series render only if the API returns historical points.
- Cache is client-side TanStack Query caching. It does not introduce Redis or change backend caching. Mutations invalidate affected portfolio queries.
- Rebalance execution writes to the database. It requires explicit browser confirmation. Test first using a disposable portfolio.
- Security-specific valuation metrics (e.g. equity close price vs ETF NAV) should be supplied by backend response fields; this frontend displays the API's available price/value fields and does not fabricate NAV.

## Folder structure
```
src/
  api.js       Axios client, auth, endpoint wrappers, response helpers
  App.jsx      Pages, dashboard, tables, charts, modals, mutations
  main.jsx     React Query provider and app entry
  styles.css   Responsive dashboard design
```
