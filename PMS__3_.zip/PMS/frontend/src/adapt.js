// Adapters between the FastAPI response shapes and what the UI renders,
// plus the small analytics used by the historical "replay" dashboard.
// Everything here is pure (no network) so it is cheap to recompute while
// the replay slider moves.

export const DRIFT_THRESHOLD = 5;      // percentage points per asset class
export const MOVE_THRESHOLD = 2;       // % single-day move that raises an alert
export const DD_WARN = -8;             // % drawdown warning
export const DD_CRIT = -15;            // % drawdown critical
export const REL_THRESHOLD = 3;        // pts vs benchmark over trailing window
export const REL_WINDOW = 63;          // ~3 months of trading days

const n = v => Number(v);
const r2 = v => Math.round(v * 100) / 100;

// ---------- performance series ----------
// performance endpoint -> [{date, portfolio, benchmark (rebased to the
// portfolio's first value), benchClose}]
export function buildSeries(perf) {
  const ps = perf?.portfolio_series || [];
  const bs = perf?.benchmark_series || [];
  if (!ps.length) return [];
  let j = 0, lastClose = null, base = null;
  const out = [];
  for (const p of ps) {
    while (j < bs.length && bs[j].price_date <= p.price_date) { lastClose = n(bs[j].close_price); j++; }
    if (lastClose == null) continue;
    if (!base) base = { pv: n(p.portfolio_value), bc: lastClose };
    out.push({
      date: p.price_date,
      portfolio: n(p.portfolio_value),
      benchClose: lastClose,
      benchmark: base.pv * lastClose / base.bc,
    });
  }
  return out;
}

export function metricsAt(series, i) {
  if (!series.length) return null;
  const cur = series[i], first = series[0], prev = series[i - 1] || cur;
  let peak = first.portfolio, maxDD = 0, best = -Infinity, worst = Infinity;
  const rets = [];
  for (let k = 1; k <= i; k++) {
    const r = (series[k].portfolio / series[k - 1].portfolio - 1) * 100;
    rets.push(r);
    if (r > best) best = r;
    if (r < worst) worst = r;
    if (series[k].portfolio > peak) peak = series[k].portfolio;
    const dd = (series[k].portfolio / peak - 1) * 100;
    if (dd < maxDD) maxDD = dd;
  }
  peak = Math.max(...series.slice(0, i + 1).map(s => s.portfolio));
  const mean = rets.length ? rets.reduce((a, b) => a + b, 0) / rets.length : 0;
  const sd = rets.length > 1 ? Math.sqrt(rets.reduce((a, b) => a + (b - mean) ** 2, 0) / (rets.length - 1)) : 0;
  const ret = (cur.portfolio / first.portfolio - 1) * 100;
  const bret = (cur.benchmark / first.benchmark - 1) * 100;
  const years = Math.max((new Date(cur.date) - new Date(first.date)) / 31557600000, 1 / 365);
  return {
    date: cur.date,
    value: cur.portfolio,
    benchValue: cur.benchmark,
    base: first.portfolio,
    gain: cur.portfolio - first.portfolio,
    returnPct: ret,
    benchReturnPct: bret,
    alpha: ret - bret,
    dayChangePct: (cur.portfolio / prev.portfolio - 1) * 100,
    dayChange: cur.portfolio - prev.portfolio,
    drawdownPct: (cur.portfolio / peak - 1) * 100,
    maxDrawdownPct: maxDD,
    volatilityPct: sd * Math.sqrt(252),
    bestDay: rets.length ? best : 0,
    worstDay: rets.length ? worst : 0,
    cagrPct: i > 0 ? ((cur.portfolio / first.portfolio) ** (1 / years) - 1) * 100 : 0,
  };
}

// chart rows rebased to % return (portfolio vs benchmark both start at 0)
export function returnRows(series, upto) {
  if (!series.length) return [];
  const f = series[0];
  return series.slice(0, upto + 1).map(s => ({
    date: s.date,
    portfolio: r2((s.portfolio / f.portfolio - 1) * 100),
    benchmark: r2((s.benchmark / f.benchmark - 1) * 100),
  }));
}

// thin the series for smooth rendering (keeps first + last point)
export function thin(rows, max = 320) {
  if (rows.length <= max) return rows;
  const step = Math.ceil(rows.length / max);
  const out = rows.filter((_, i) => i % step === 0);
  if (out[out.length - 1] !== rows[rows.length - 1]) out.push(rows[rows.length - 1]);
  return out;
}

// ---------- alerts ----------
const FREQ_MONTHS = { MONTHLY: 1, QUARTERLY: 3, HALF_YEARLY: 6, YEARLY: 12 };

function addMonths(dateStr, m) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCMonth(d.getUTCMonth() + m);
  return d.toISOString().slice(0, 10);
}

// Full historical alert timeline (scanned once per portfolio).
export function buildEvents(series, frequency) {
  const ev = [];
  if (series.length < 2) return ev;
  let peak = series[0].portfolio, ddState = 0, under = false, over = false;
  const months = FREQ_MONTHS[frequency];
  let nextRebal = months ? addMonths(series[0].date, months) : null;
  for (let i = 1; i < series.length; i++) {
    const s = series[i], p = series[i - 1];
    const day = (s.portfolio / p.portfolio - 1) * 100;
    if (Math.abs(day) >= MOVE_THRESHOLD) {
      ev.push({ date: s.date, type: day < 0 ? 'warning' : 'info', title: day < 0 ? 'Sharp one-day drop' : 'Strong one-day gain', detail: `Portfolio moved ${day.toFixed(2)}% in a single session.` });
    }
    if (s.portfolio > peak) peak = s.portfolio;
    const dd = (s.portfolio / peak - 1) * 100;
    const state = dd <= DD_CRIT ? 2 : dd <= DD_WARN ? 1 : 0;
    if (state > ddState) ev.push({ date: s.date, type: state === 2 ? 'critical' : 'warning', title: state === 2 ? 'Deep drawdown' : 'Drawdown warning', detail: `Portfolio is ${dd.toFixed(1)}% below its previous peak.` });
    if (dd > -4) ddState = 0; else ddState = Math.max(ddState, state);
    if (i >= REL_WINDOW) {
      const b = series[i - REL_WINDOW];
      const rel = (s.portfolio / b.portfolio - 1) * 100 - (s.benchmark / b.benchmark - 1) * 100;
      if (rel <= -REL_THRESHOLD && !under) { ev.push({ date: s.date, type: 'warning', title: 'Trailing the benchmark', detail: `Portfolio is ${Math.abs(rel).toFixed(1)} pts behind the benchmark over ~3 months.` }); under = true; over = false; }
      else if (rel >= REL_THRESHOLD && !over) { ev.push({ date: s.date, type: 'positive', title: 'Beating the benchmark', detail: `Portfolio is ${rel.toFixed(1)} pts ahead of the benchmark over ~3 months.` }); over = true; under = false; }
      else if (rel > -1 && rel < 1) { under = false; over = false; }
    }
    if (nextRebal && s.date >= nextRebal) {
      ev.push({ date: s.date, type: 'action', title: 'Rebalance review due', detail: `Scheduled ${String(frequency).toLowerCase().replace('_', '-')} rebalancing review.` });
      nextRebal = addMonths(nextRebal, months);
    }
  }
  return ev;
}

// Alerts that are "on" right now (as of series index i).
export function activeAlerts(series, i, { driftRows = [], events = [] } = {}) {
  const out = [];
  if (!series.length) return out;
  const m = metricsAt(series, i);
  if (m.drawdownPct <= DD_CRIT) out.push({ type: 'critical', title: 'Deep drawdown', detail: `${m.drawdownPct.toFixed(1)}% below peak value.` });
  else if (m.drawdownPct <= DD_WARN) out.push({ type: 'warning', title: 'Drawdown warning', detail: `${m.drawdownPct.toFixed(1)}% below peak value.` });
  if (Math.abs(m.dayChangePct) >= MOVE_THRESHOLD) out.push({ type: m.dayChangePct < 0 ? 'warning' : 'info', title: m.dayChangePct < 0 ? 'Sharp one-day drop' : 'Strong one-day gain', detail: `${m.dayChangePct.toFixed(2)}% today.` });
  if (i >= REL_WINDOW) {
    const b = series[i - REL_WINDOW], s = series[i];
    const rel = (s.portfolio / b.portfolio - 1) * 100 - (s.benchmark / b.benchmark - 1) * 100;
    if (rel <= -REL_THRESHOLD) out.push({ type: 'warning', title: 'Trailing the benchmark', detail: `${Math.abs(rel).toFixed(1)} pts behind over ~3 months.` });
    else if (rel >= REL_THRESHOLD) out.push({ type: 'positive', title: 'Beating the benchmark', detail: `${rel.toFixed(1)} pts ahead over ~3 months.` });
  }
  const cutoff = new Date(new Date(series[i].date).getTime() - 21 * 86400000).toISOString().slice(0, 10);
  const due = [...events].reverse().find(e => e.title === 'Rebalance review due' && e.date <= series[i].date && e.date >= cutoff);
  if (due) out.push({ type: 'action', title: 'Rebalance review due', detail: due.detail });
  driftRows.forEach(d => out.push({ type: 'warning', title: `${d.asset_class} drift`, detail: `${d.drift_pct >= 0 ? 'Over' : 'Under'}weight by ${Math.abs(d.drift_pct).toFixed(1)} pts vs target.` }));
  return out;
}

// ---------- response normalisers ----------
export function normHoldings(rows, acMap) {
  const list = rows.map(h => {
    const price = n(h.last_price ?? h.avg_price), qty = n(h.quantity);
    return { ...h, asset_class: acMap[h.asset_id] || '—', current_price: price, market_value: qty * price, cost_value: qty * n(h.avg_price) };
  });
  const total = list.reduce((s, h) => s + h.market_value, 0) || 1;
  return list.map(h => ({ ...h, weight_pct: h.market_value / total * 100, pnl: h.market_value - h.cost_value, pnl_pct: h.cost_value ? (h.market_value / h.cost_value - 1) * 100 : 0 }));
}

export function normAllocation(rows) {
  const total = rows.reduce((s, r) => s + n(r.current_value), 0) || 1;
  return rows.map(r => ({ ...r, market_value: n(r.current_value), current_weight_pct: n(r.current_value) / total * 100, target_weight_pct: n(r.target_pct) }));
}

export function normDrift(info, acMap) {
  const rows = info?.breakdown || [];
  return rows.map(d => ({
    asset_class: acMap[d.asset_id] || `Class ${d.asset_id}`,
    target_weight_pct: n(d.target_pct),
    current_weight_pct: n(d.actual_pct),
    drift_pct: n(d.diff_pct),
  })).filter(d => d.target_weight_pct > 0 || d.current_weight_pct > 0);
}

export function normSectors(rows) {
  const total = rows.reduce((s, r) => s + n(r.current_value), 0) || 1;
  return rows.map(r => ({ sector_name: r.sector, weight_pct: n(r.current_value) / total * 100, current_value: n(r.current_value) }));
}

export function normPreview(rows) {
  return (Array.isArray(rows) ? rows : []).map(r => ({
    ...r,
    security_name: r.symbol,
    quantity: Math.abs(n(r.delta_quantity)),
    estimated_value: Math.abs(n(r.delta_quantity)) * n(r.price),
  }));
}

export function normTxns(rows) {
  return rows.map(t => ({
    ...t,
    transaction_date: t.txn_date,
    transaction_type: t.action,
    amount: n(t.quantity) * n(t.price),
  }));
}

export const fmtDate = d => d ? new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
