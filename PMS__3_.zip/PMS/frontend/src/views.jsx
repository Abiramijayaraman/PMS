import React, { useMemo, useState } from 'react';
import { AreaChart, Area, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine } from 'recharts';
import { Play, Pause, SkipBack, SkipForward, Bell, Wallet, TrendingUp, TrendingDown, Scale, ShieldCheck, CircleAlert, ChartNoAxesCombined, ChevronRight, Gauge, Activity, CalendarClock, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { returnRows, metricsAt, fmtDate } from './adapt.js';

const inr = v => Number.isFinite(Number(v)) ? new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(v)) : '—';
const num = v => Number.isFinite(Number(v)) ? new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(Number(v)) : '—';
const pc = v => Number.isFinite(Number(v)) ? `${Number(v) >= 0 ? '+' : ''}${Number(v).toFixed(2)}%` : '—';
const COLORS = ['#5478f5', '#21b68a', '#9b7bf6', '#f2b84b', '#f17b78', '#50b8d8'];

function Stat({ title, value, sub, icon: Icon, tone, positive, loading }) {
  return <div className="metric-card"><div className="metric-top"><span>{title}</span><span className={`metric-icon ${tone}`}><Icon size={18} /></span></div>
    <div className="metric-value">{loading ? <span className="skeleton" /> : value}</div>
    <div className="metric-sub">{positive === undefined ? null : positive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}<span>{sub}</span></div></div>;
}
function Empty({ text }) { return <div className="chart-empty"><span><ChartNoAxesCombined size={22} /></span><p>{text}</p></div>; }

// choose ~300 points for drawing but always keep the replay cursor + last point
function sample(series, cur, max = 300) {
  const step = Math.max(1, Math.ceil(series.length / max));
  return series.map((s, i) => ({ s, i })).filter(({ i }) => i % step === 0 || i === cur || i === series.length - 1);
}

export function ReplayBar({ series, cur, setIdx, playing, setPlaying, speed, setSpeed, inception }) {
  if (!series.length) return null;
  const last = series.length - 1;
  const play = () => { if (playing) { setPlaying(false); return; } if (cur >= last) setIdx(0); setPlaying(true); };
  return <section className="panel replay-bar">
    <div className="replay-info">
      <span className={`live-dot ${playing ? '' : 'paused'}`} />
      <div><small>{playing ? 'REPLAYING HISTORY' : cur >= last ? 'LATEST MARKET DATE' : 'HISTORICAL VIEW'}</small><b>{fmtDate(series[cur].date)}</b></div>
    </div>
    <div className="replay-controls">
      <button className="icon-btn" title="Back to start" onClick={() => { setPlaying(false); setIdx(0); }}><SkipBack size={16} /></button>
      <button className="btn btn-primary replay-play" onClick={play}>{playing ? <><Pause size={15} /> Pause</> : <><Play size={15} /> {cur >= last ? 'Replay' : 'Play'}</>}</button>
      <button className="icon-btn" title="Jump to latest" onClick={() => { setPlaying(false); setIdx(last); }}><SkipForward size={16} /></button>
      <select className="replay-speed" value={speed} onChange={e => setSpeed(Number(e.target.value))} title="Trading days per tick">
        <option value={1}>1× (1 day / tick)</option><option value={5}>5× (1 week)</option><option value={21}>21× (1 month)</option><option value={63}>63× (1 quarter)</option>
      </select>
    </div>
    <div className="replay-slider">
      <input type="range" min={0} max={last} value={cur} onChange={e => { setPlaying(false); setIdx(Number(e.target.value)); }} />
      <div className="replay-range"><span>{fmtDate(series[0].date)}{inception ? ' · inception' : ''}</span><span>{fmtDate(series[last].date)}</span></div>
    </div>
  </section>;
}

function AlertList({ items, empty }) {
  if (!items.length) return <div className="alert-empty"><ShieldCheck size={18} /> {empty}</div>;
  return <div className="alert-list">{items.map((a, i) => <div key={i} className={`alert-item alert-${a.type}`}>
    <span className="alert-ico">{a.type === 'positive' ? <TrendingUp size={16} /> : a.type === 'action' ? <CalendarClock size={16} /> : a.type === 'info' ? <Activity size={16} /> : <CircleAlert size={16} />}</span>
    <div><b>{a.title}</b><small>{a.detail}</small></div>{a.date && <em>{fmtDate(a.date)}</em>}</div>)}</div>;
}

export function Overview({ portfolio, series, cur, m, alerts, events, allocation, drift, holdings, isLoading, replay, onGo }) {
  const [mode, setMode] = useState('value');
  const last = series.length - 1;
  const rows = useMemo(() => {
    if (!series.length) return [];
    const f = series[0];
    return sample(series, cur).map(({ s, i }) => {
      const show = i <= cur;
      return mode === 'value'
        ? { date: s.date, portfolio: show ? Math.round(s.portfolio) : null, benchmark: show ? Math.round(s.benchmark) : null }
        : { date: s.date, portfolio: show ? +((s.portfolio / f.portfolio - 1) * 100).toFixed(2) : null, benchmark: show ? +((s.benchmark / f.benchmark - 1) * 100).toFixed(2) : null };
    });
  }, [series, cur, mode]);
  const alloc = allocation.filter(a => a.market_value > 0).map(a => ({ name: a.asset_class, value: a.market_value }));
  const timeline = events.filter(e => series.length && e.date <= series[cur].date).slice(-8).reverse();
  const top = [...holdings].sort((a, b) => b.market_value - a.market_value).slice(0, 6);
  const bench = portfolio.benchmark_symbol || '^NSEI';

  return <>
    <ReplayBar {...replay} series={series} cur={cur} inception />
    <div className="metric-grid">
      <Stat title="Portfolio value" value={m ? inr(m.value) : '—'} sub={m ? `${m.dayChange >= 0 ? '+' : ''}${inr(m.dayChange)} (${pc(m.dayChangePct)}) today` : '—'} icon={Wallet} tone="blue" positive={m ? m.dayChange >= 0 : undefined} loading={isLoading} />
      <Stat title="Return since inception" value={m ? pc(m.returnPct) : '—'} sub={m ? `${m.gain >= 0 ? '+' : ''}${inr(m.gain)} · CAGR ${pc(m.cagrPct)}` : '—'} icon={TrendingUp} tone={m && m.gain < 0 ? 'red' : 'green'} positive={m ? m.gain >= 0 : undefined} loading={isLoading} />
      <Stat title={`Benchmark (${bench})`} value={m ? pc(m.benchReturnPct) : '—'} sub={m ? `Alpha ${pc(m.alpha)} vs benchmark` : '—'} icon={Scale} tone="purple" positive={m ? m.alpha >= 0 : undefined} loading={isLoading} />
      <Stat title="Active alerts" value={alerts.length} sub={alerts.length ? 'Needs attention' : 'All clear'} icon={alerts.length ? Bell : ShieldCheck} tone={alerts.length ? 'amber' : 'green'} loading={isLoading} />
    </div>

    <div className="dashboard-grid">
      <section className="panel performance-panel">
        <div className="panel-head"><div><h3>Portfolio vs benchmark</h3><p>{mode === 'value' ? 'Value in INR, benchmark rebased to the same starting capital' : 'Cumulative return since inception'}</p></div>
          <div className="seg"><button className={mode === 'value' ? 'on' : ''} onClick={() => setMode('value')}>Value</button><button className={mode === 'return' ? 'on' : ''} onClick={() => setMode('return')}>Return %</button></div></div>
        <div className="chart-legend"><span><i className="legend-dot blue-dot" /> Portfolio</span><span><i className="legend-dot green-dot" /> {bench}</span><span className="chart-return">{m ? pc(m.returnPct) : ''}</span></div>
        <div className="chart-wrap">{rows.length ? <ResponsiveContainer width="100%" height="100%"><AreaChart data={rows} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs><linearGradient id="pf" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#5478f5" stopOpacity={.24} /><stop offset="100%" stopColor="#5478f5" stopOpacity={0} /></linearGradient></defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f5" />
          <XAxis dataKey="date" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#8b93a7' }} minTickGap={50} tickFormatter={d => d.slice(0, 7)} />
          <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#8b93a7' }} width={58} domain={['auto', 'auto']} tickFormatter={v => mode === 'value' ? (v >= 100000 ? `${(v / 100000).toFixed(1)}L` : num(v)) : `${v}%`} />
          <Tooltip formatter={(v, n) => [mode === 'value' ? inr(v) : `${v}%`, n === 'portfolio' ? 'Portfolio' : bench]} labelFormatter={fmtDate} />
          <ReferenceLine x={series[cur].date} stroke="#c3cbe0" strokeDasharray="4 4" />
          <Area type="monotone" dataKey="portfolio" stroke="#5478f5" strokeWidth={2.5} fill="url(#pf)" isAnimationActive={false} connectNulls={false} />
          <Line type="monotone" dataKey="benchmark" stroke="#24b68a" strokeWidth={2} dot={false} isAnimationActive={false} connectNulls={false} />
        </AreaChart></ResponsiveContainer> : <Empty text={isLoading ? 'Loading historical performance…' : 'No holdings yet — add securities to see performance.'} />}</div>
        <div className="panel-note"><CircleAlert size={14} /> Historical closing prices from your database (Sep 2022 – Sep 2026). Benchmark is a price index and excludes dividends.</div>
      </section>

      <section className="panel allocation-panel">
        <div className="panel-head"><div><h3>Asset allocation</h3><p>Latest market date</p></div><button className="text-btn" onClick={() => onGo('Allocation & Risk')}>Details <ChevronRight size={15} /></button></div>
        {alloc.length ? <><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={alloc} dataKey="value" nameKey="name" innerRadius={62} outerRadius={90} paddingAngle={3} stroke="none">{alloc.map((_, i) => <Cell key={i} fill={COLORS[i % 6]} />)}</Pie><Tooltip formatter={v => inr(v)} /></PieChart></ResponsiveContainer><div className="donut-center"><b>{alloc.length}</b><small>asset classes</small></div></div>
          <div className="allocation-legend">{alloc.slice(0, 5).map((a, i) => <div key={a.name}><span><i style={{ background: COLORS[i % 6] }} />{a.name}</span><b>{inr(a.value)}</b></div>)}</div></> : <Empty text="No allocation yet." />}
      </section>
    </div>

    <div className="dashboard-grid lower-grid">
      <section className="panel">
        <div className="panel-head"><div><h3>Alerts &amp; signals</h3><p>Evaluated as of {series.length ? fmtDate(series[cur].date) : '—'}</p></div><span className={`tag ${alerts.length ? 'tag-amber' : 'tag-green'}`}>{alerts.length} active</span></div>
        <AlertList items={alerts} empty="No active alerts on this date." />
        {cur < last && <div className="panel-note"><CircleAlert size={14} /> Allocation-drift alerts are evaluated on the latest market date only.</div>}
        <h4 className="sub-head">Alert timeline</h4>
        <AlertList items={timeline} empty="No events yet — press Play to replay history." />
      </section>
      <section className="panel">
        <div className="panel-head"><div><h3>Top holdings</h3><p>Latest prices · P&amp;L vs cost</p></div><button className="text-btn" onClick={() => onGo('Holdings')}>All holdings <ChevronRight size={15} /></button></div>
        {top.length ? <div className="drift-list">{top.map(h => <div className="drift-row" key={h.holding_id}><div className="drift-name"><span className="drift-icon">{h.symbol.slice(0, 2)}</span><div><b>{h.symbol}</b><small>{h.asset_class} · {h.weight_pct.toFixed(1)}%</small></div></div><div className="drift-bar"><span style={{ width: `${Math.min(h.weight_pct * 2, 100)}%` }} /></div><b className={h.pnl >= 0 ? 'text-up' : 'text-down'}>{pc(h.pnl_pct)}</b></div>)}</div> : <Empty text="No holdings yet." />}
        {drift.length > 0 && <><h4 className="sub-head">Allocation drift</h4><div className="drift-list">{drift.map(d => <div className="drift-row" key={d.asset_class}><div className="drift-name"><div><b>{d.asset_class}</b><small>Target {d.target_weight_pct.toFixed(0)}% · Now {d.current_weight_pct.toFixed(1)}%</small></div></div><div className="drift-bar"><span style={{ width: `${Math.min(Math.abs(d.drift_pct) * 8, 100)}%`, background: Math.abs(d.drift_pct) >= 5 ? '#e5a23b' : undefined }} /></div><b className={Math.abs(d.drift_pct) >= 5 ? 'text-amber' : ''}>{pc(d.drift_pct)}</b></div>)}</div></>}
      </section>
    </div>
  </>;
}

export function PerformanceView({ portfolio, series, cur, m, replay }) {
  const bench = portfolio.benchmark_symbol || '^NSEI';
  const rets = useMemo(() => { const all = returnRows(series, cur); const step = Math.max(1, Math.ceil(all.length / 300)); return all.filter((_, i) => i % step === 0 || i === all.length - 1); }, [series, cur]);
  const dd = useMemo(() => { if (!series.length) return []; let peak = 0; const out = []; series.slice(0, cur + 1).forEach(s => { peak = Math.max(peak, s.portfolio); out.push({ date: s.date, drawdown: +((s.portfolio / peak - 1) * 100).toFixed(2) }); }); const step = Math.max(1, Math.ceil(out.length / 300)); return out.filter((_, i) => i % step === 0 || i === out.length - 1); }, [series, cur]);
  return <>
    <ReplayBar {...replay} series={series} cur={cur} />
    {m ? <>
      <div className="metric-grid">
        <Stat title="Portfolio return" value={pc(m.returnPct)} sub={`CAGR ${pc(m.cagrPct)}`} icon={TrendingUp} tone={m.returnPct >= 0 ? 'green' : 'red'} positive={m.returnPct >= 0} />
        <Stat title={`Benchmark ${bench}`} value={pc(m.benchReturnPct)} sub="Same period, price index" icon={Scale} tone="purple" />
        <Stat title="Alpha" value={pc(m.alpha)} sub={m.alpha >= 0 ? 'Ahead of benchmark' : 'Behind benchmark'} icon={m.alpha >= 0 ? TrendingUp : TrendingDown} tone={m.alpha >= 0 ? 'green' : 'red'} positive={m.alpha >= 0} />
        <Stat title="Volatility (ann.)" value={`${m.volatilityPct.toFixed(2)}%`} sub="Std-dev of daily returns" icon={Gauge} tone="amber" />
      </div>
      <div className="metric-grid">
        <Stat title="Current value" value={inr(m.value)} sub={`Started at ${inr(m.base)}`} icon={Wallet} tone="blue" />
        <Stat title="Max drawdown" value={`${m.maxDrawdownPct.toFixed(2)}%`} sub={`Now ${m.drawdownPct.toFixed(2)}% from peak`} icon={TrendingDown} tone="red" />
        <Stat title="Best day" value={pc(m.bestDay)} sub="Single-session high" icon={ArrowUpRight} tone="green" />
        <Stat title="Worst day" value={pc(m.worstDay)} sub="Single-session low" icon={ArrowDownRight} tone="red" />
      </div></> : null}
    <section className="panel"><div className="panel-head"><div><h3>Cumulative return vs benchmark</h3><p>Both start at 0% on the portfolio inception date</p></div><span className="tag tag-muted">Historical</span></div>
      <div className="large-chart">{rets.length ? <ResponsiveContainer width="100%" height="100%"><LineChart data={rets}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="date" tickLine={false} minTickGap={50} tickFormatter={d => d.slice(0, 7)} /><YAxis tickLine={false} tickFormatter={v => `${v}%`} /><Tooltip formatter={v => `${v}%`} labelFormatter={fmtDate} /><Legend /><ReferenceLine y={0} stroke="#c3cbe0" />
        <Line dataKey="portfolio" name="Portfolio" stroke="#5478f5" strokeWidth={2.5} dot={false} isAnimationActive={false} /><Line dataKey="benchmark" name={bench} stroke="#21b68a" strokeWidth={2} dot={false} isAnimationActive={false} /></LineChart></ResponsiveContainer> : <Empty text="No performance history for this portfolio yet — add holdings first." />}</div></section>
    <section className="panel"><div className="panel-head"><div><h3>Drawdown from peak</h3><p>How far the portfolio sat below its previous high</p></div></div>
      <div className="chart-wrap" style={{ height: 200 }}>{dd.length ? <ResponsiveContainer width="100%" height="100%"><AreaChart data={dd}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f5" /><XAxis dataKey="date" tickLine={false} axisLine={false} minTickGap={50} tickFormatter={d => d.slice(0, 7)} tick={{ fontSize: 11, fill: '#8b93a7' }} /><YAxis tickLine={false} axisLine={false} tickFormatter={v => `${v}%`} tick={{ fontSize: 11, fill: '#8b93a7' }} /><Tooltip formatter={v => `${v}%`} labelFormatter={fmtDate} /><Area dataKey="drawdown" name="Drawdown" stroke="#f17b78" fill="#f17b7833" isAnimationActive={false} /></AreaChart></ResponsiveContainer> : <Empty text="No data." />}</div></section>
  </>;
}
