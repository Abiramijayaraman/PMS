# Changes made while wiring the project

## Backend
* Added missing dependency `email-validator`; pinned `bcrypt==4.0.1` (passlib 1.7.4 crashes with bcrypt 5.x).
* Demo user email `manager@pms.local` was rejected by the email validator (reserved TLD) → `manager@pmsdemo.in`;
  seeded password hash was not a valid bcrypt hash of `password123` → regenerated.
* Schema/code mismatches fixed in `01_create_tables.sql` (+ idempotent migrations 07/08): `portfolios.inception_date`, `holdings.as_of_date`.
* Migration 09: `issuers`, `issuer_gics_classifications`, `securities.issuer_id` + seed (sector-breakdown returned HTTP 500 before).
* `05_rename_...sql` made idempotent.
* Price data contained **unadjusted** corporate actions (RELIANCE bonus Oct-2024, HDFCBANK bonus Aug-2025, KOTAKBANK 5:1 split Jan-2026)
  which showed as fake portfolio losses → `scripts/adjust_corporate_actions.py` back-adjusts them (idempotent).
* Holdings API is history-oriented: optional `as_of_date` (default = portfolio inception) and optional `avg_price` (defaults to the close on that date).
  Inception date validated against the available data range. Removed remaining `CURRENT_DATE` usages.
* `last_price_date` now updated by the importer; refresh cookie `secure=False` for local http; CORS allows localhost + 127.0.0.1.
* New `scripts/setup_demo.py` (one command setup) and `seed_demo_portfolios.py` made idempotent, ACTIVE status.

## Frontend
* The UI guessed response field names; most did not match the API (drift, performance, sectors, holdings, transactions, preview). Added `src/adapt.js` adapters.
* New `src/views.jsx`: replay-driven Overview (Play/Pause/scrub, portfolio vs benchmark chart, alpha/CAGR, alerts + timeline) and Performance page
  (cumulative return vs benchmark, drawdown, volatility, best/worst day).
* Alerts: drawdown, sharp daily moves, trailing/beating benchmark, rebalance due (from the portfolio's frequency), allocation drift.
* Create-portfolio uses a bounded historical inception date; Add-holding takes a purchase date and auto-prices from history.
* API base defaults to `http://localhost:8000` so the refresh cookie is same-site.
