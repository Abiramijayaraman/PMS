# Northstar PMS – Portfolio Management Demo (historical: Sep 2022 → Sep 2026)

FastAPI + PostgreSQL backend, React (Vite) frontend. All data is **historical only**:
the app's "today" is the last date in your price data (25-Sep-2026), never the wall-clock date.

## What you get
* 3 ready portfolios (2022 Conservative, 2023 Growth, 2024 High Growth) with real holdings and transactions
* **Dashboard replay** – press Play to walk the portfolio through time; portfolio vs NIFTY 50 chart, value / return % toggle,
  alpha, CAGR, volatility, drawdown, live alerts + alert timeline
* Benchmark comparison (rebased to the same starting capital), sector exposure (GICS), allocation & drift
* Rebalancing preview + execute (drift returns to 0 after execution)
* Create portfolio (pick any inception date in the data range) → add securities on any historical date (price auto-filled from history)
* Data-quality page, transactions ledger with CSV export

## Run in VS Code (about 5 minutes)

### 0. Prerequisites
PostgreSQL running locally, Python 3.10+, Node 20+.
Edit `backend/.env` if your Postgres password/port differs (default: `postgres:abi2004@localhost:5432/pms`).

### 1. Backend
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python scripts/setup_demo.py    # creates DB if missing, tables, prices, split adjustment, 3 demo portfolios
uvicorn app.main:app --reload   # API on http://localhost:8000  (docs: /docs)
```
`setup_demo.py` is safe to re-run.

### 2. Frontend (second terminal)
```bash
cd frontend
npm install
npm run dev                     # http://localhost:5173
```

### 3. Log in
`manager@pmsdemo.in` / `password123`   (pre-filled on the login screen)

## Suggested demo script
1. **Overview** → press **Play** (try the 21× speed) and watch value, alpha and alerts change through 2022-2026.
2. **Performance** → cumulative return vs benchmark, drawdown chart, volatility, best/worst day.
3. **Allocation & Risk** → drift vs targets (Equity/Gold breaches on the 2024 portfolio) and sector exposure.
4. **Rebalancing** → preview trades → *Confirm & execute* → drift goes to ~0.
   (To reset the demo afterwards, drop the `pms` database and run `python scripts/setup_demo.py` again.)
5. **New portfolio** → choose theme + inception date (e.g. 2023-06-01) → **Holdings → Add security**
   (date defaults to inception, price auto-filled; theme limits are enforced).

## Notes on what was fixed / wired (see CHANGES.md for the full list)
