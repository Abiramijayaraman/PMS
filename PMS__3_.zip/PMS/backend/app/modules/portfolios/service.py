from app.core.exceptions import NotFoundError, ValidationError
from app.common.dates import get_data_as_of_date
from app.modules.portfolios import repository

def create_portfolio(db, user_id: int, data: dict) -> dict:
    latest = get_data_as_of_date(db)
    db.execute("SELECT MIN(price_date) AS d FROM price_history")
    earliest = db.fetchone()["d"]
    if not data.get("inception_date"):
        data["inception_date"] = latest
    if data["inception_date"] < earliest or data["inception_date"] > latest:
        raise ValidationError(f"Inception date must be between {earliest} and {latest} (available historical data)")
    return repository.insert_portfolio(db, user_id, data)

def list_my_portfolios(db, user_id: int) -> list:
    return repository.list_portfolios_for_user(db, user_id)

def get_portfolio_or_404(db, portfolio_id: int) -> dict:
    portfolio = repository.get_portfolio(db, portfolio_id)
    if not portfolio:
        raise NotFoundError("Portfolio", portfolio_id)
    return portfolio

def update_portfolio(db, portfolio_id: int, fields: dict) -> dict:
    get_portfolio_or_404(db, portfolio_id)
    clean_fields = {k: v for k, v in fields.items() if v is not None}
    return repository.update_portfolio(db, portfolio_id, clean_fields)

def close_portfolio(db, portfolio_id: int) -> dict:
    get_portfolio_or_404(db, portfolio_id)
    return repository.close_portfolio(db, portfolio_id)