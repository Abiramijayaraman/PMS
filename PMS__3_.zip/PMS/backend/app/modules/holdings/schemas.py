from datetime import date
from decimal import Decimal

from pydantic import BaseModel, Field


class HoldingCreate(BaseModel):
    security_id: int = Field(gt=0)
    quantity: Decimal = Field(gt=0)
    avg_price: Decimal | None = Field(default=None, ge=0)  # None = close price on as_of_date
    as_of_date: date | None = None  # None = portfolio inception date


class HoldingUpdate(BaseModel):
    quantity: Decimal = Field(gt=0)