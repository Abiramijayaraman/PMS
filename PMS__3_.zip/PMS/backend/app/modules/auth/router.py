from fastapi import APIRouter, Depends, Response, Cookie
from app.core.database import get_db
from app.modules.auth import service
from app.modules.auth.schemas import LoginRequest, TokenResponse

router = APIRouter()

@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest, response: Response, db=Depends(get_db)):
    tokens = service.login(db, body.email, body.password)
    # Refresh token: httpOnly cookie, never readable by JS (XSS protection)
    response.set_cookie(
        key="refresh_token",
        value=tokens["refresh_token"],
        httponly=True,
        secure=False,      # local http dev (Vite + uvicorn on localhost);
                            # set True once served over https in production
        samesite="lax",
        max_age=7 * 24 * 3600,
    )
    return {"access_token": tokens["access_token"]}

@router.post("/refresh", response_model=TokenResponse)
def refresh(refresh_token: str | None = Cookie(default=None)):
    from app.core.exceptions import AuthError
    if not refresh_token:
        raise AuthError("No refresh token provided")
    new_access_token = service.refresh(refresh_token)
    return {"access_token": new_access_token}

@router.post("/logout")
def logout(response: Response):
    # TODO: also add the refresh token's jti to a denylist (Redis or a
    # denylisted_tokens table) so a stolen cookie can't be replayed
    # after logout, before its natural expiry.
    response.delete_cookie("refresh_token")
    return {"detail": "Logged out"}
