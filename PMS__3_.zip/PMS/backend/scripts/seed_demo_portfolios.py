"""
Creates 3 demo portfolios, each starting on a different historical date,
so a demo has real multi-year backtest data immediately - no manual
API calls needed first.

Usage:
    python scripts/seed_demo_portfolios.py
"""
import sys
from pathlib import Path

import psycopg2
from psycopg2.extras import RealDictCursor

sys.path.append(str(Path(__file__).resolve().parents[1]))
from app.core.config import settings  # noqa: E402

DEMO_USER_EMAIL = "manager@pmsdemo.in"

# (theme_name, portfolio_name, inception_date, initial_investment, [(symbol, weight_pct), ...])
PORTFOLIOS = [
    (
        "Conservative", "Legacy Conservative 2022", "2022-10-03", 500000,
        [("NIFTYBEES", 40), ("LIQUIDBEES", 20), ("EMBASSY", 20), ("RELIANCE", 20)],
    ),
    (
        "Moderately Aggressive", "Growth Portfolio 2023", "2023-10-02", 750000,
        [("RELIANCE", 20), ("TCS", 20), ("HDFCBANK", 20), ("NIFTYBEES", 20), ("GOLDBEES", 5), ("EMBASSY", 10), ("LIQUIDBEES", 5)],
    ),
    (
        "Aggressive", "High Growth 2024", "2024-10-01", 1000000,
        [("RELIANCE", 17.5), ("TCS", 17.5), ("INFY", 17.5), ("HDFCBANK", 17.5), ("GOLDBEES", 10), ("EMBASSY", 10), ("LIQUIDBEES", 10)],
    ),
]


def get_price_on_date(cur, security_id, as_of_date):
    cur.execute(
        "SELECT close_price FROM price_history WHERE security_id = %s AND price_date <= %s ORDER BY price_date DESC LIMIT 1",
        (security_id, as_of_date),
    )
    row = cur.fetchone()
    return float(row["close_price"]) if row else None


def main():
    conn = psycopg2.connect(settings.database_url, cursor_factory=RealDictCursor)
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT user_id FROM users WHERE email = %s", (DEMO_USER_EMAIL,))
            user = cur.fetchone()
            if not user:
                raise SystemExit(f"No user with email {DEMO_USER_EMAIL} - run seed_reference_data.py first")
            user_id = user["user_id"]

        for theme_name, portfolio_name, inception_date, initial_investment, holdings in PORTFOLIOS:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT portfolio_id FROM portfolios WHERE user_id = %s AND portfolio_name = %s",
                    (user_id, portfolio_name),
                )
                if cur.fetchone():
                    print(f"SKIP {portfolio_name}: already exists for this user")
                    continue

                cur.execute("SELECT theme_id FROM investment_themes WHERE theme_name = %s", (theme_name,))
                theme = cur.fetchone()
                if not theme:
                    print(f"SKIP {portfolio_name}: theme '{theme_name}' not found")
                    continue

                cur.execute(
                    """
                    INSERT INTO portfolios
                        (user_id, portfolio_name, portfolio_type, currency, exchange,
                         benchmark_symbol, theme_id, rebalancing_frequency, initial_investment,
                         inception_date, status)
                    VALUES (%s, %s, 'WEIGHTAGE', 'INR', 'NSE', '^NSEI', %s, 'QUARTERLY', %s, %s, 'ACTIVE')
                    RETURNING portfolio_id
                    """,
                    (user_id, portfolio_name, theme["theme_id"], initial_investment, inception_date),
                )
                portfolio_id = cur.fetchone()["portfolio_id"]
            conn.commit()

            for symbol, weight_pct in holdings:
                with conn.cursor() as cur:
                    cur.execute("SELECT security_id FROM securities WHERE symbol = %s", (symbol,))
                    security = cur.fetchone()
                    if not security:
                        print(f"  SKIP {symbol}: not in securities table")
                        continue
                    security_id = security["security_id"]

                    price = get_price_on_date(cur, security_id, inception_date)
                    if price is None:
                        print(f"  SKIP {symbol}: no price on/before {inception_date}")
                        continue

                    quantity = round((weight_pct / 100) * initial_investment / price, 4)

                    cur.execute(
                        """
                        INSERT INTO holdings (portfolio_id, security_id, quantity, avg_price, as_of_date)
                        VALUES (%s, %s, %s, %s, %s)
                        ON CONFLICT (portfolio_id, security_id) DO NOTHING
                        """,
                        (portfolio_id, security_id, quantity, price, inception_date),
                    )
                    cur.execute(
                        """
                        INSERT INTO transactions (portfolio_id, security_id, action, quantity, price, txn_date)
                        VALUES (%s, %s, 'BUY', %s, %s, %s)
                        """,
                        (portfolio_id, security_id, quantity, price, inception_date),
                    )
                conn.commit()
                print(f"  {symbol}: {quantity} units @ Rs.{price} on {inception_date}")

            print(f"Created '{portfolio_name}' (id={portfolio_id}), inception {inception_date}\n")
    finally:
        conn.close()


if __name__ == "__main__":
    main()