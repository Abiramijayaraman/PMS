"""
Back-adjusts historical closes for stock splits / bonus issues.

The source CSVs contain RAW prices, so on the ex-date the price falls by the
split ratio although no value was lost. Because holdings store a fixed
quantity, that fake drop would show up as a huge portfolio loss.
This divides every close BEFORE the ex-date by the split factor
(standard "adjusted close" practice).

Safe to re-run: it only adjusts when the raw price jump is still present.

Usage:
    python scripts/adjust_corporate_actions.py
"""
import sys
from pathlib import Path

import psycopg2

sys.path.append(str(Path(__file__).resolve().parents[1]))
from app.core.config import settings  # noqa: E402

# (symbol, ex-date, split factor)   1:1 bonus = 2, 5:1 split = 5
ACTIONS = [
    ("RELIANCE", "2024-10-28", 2),
    ("HDFCBANK", "2025-08-26", 2),
    ("KOTAKBANK", "2026-01-14", 5),
]


def main():
    conn = psycopg2.connect(settings.database_url)
    try:
        with conn.cursor() as cur:
            for symbol, ex_date, factor in ACTIONS:
                cur.execute("SELECT security_id FROM securities WHERE symbol = %s", (symbol,))
                row = cur.fetchone()
                if not row:
                    print(f"SKIP {symbol}: not in securities")
                    continue
                sid = row[0]
                cur.execute(
                    "SELECT close_price FROM price_history WHERE security_id=%s AND price_date=%s",
                    (sid, ex_date),
                )
                on_day = cur.fetchone()
                cur.execute(
                    "SELECT close_price FROM price_history WHERE security_id=%s AND price_date<%s ORDER BY price_date DESC LIMIT 1",
                    (sid, ex_date),
                )
                before = cur.fetchone()
                if not on_day or not before:
                    print(f"SKIP {symbol}: no prices around {ex_date}")
                    continue
                ratio = float(on_day[0]) / float(before[0])
                if abs(ratio - 1 / factor) > 0.15 / factor:
                    print(f"OK   {symbol}: already adjusted (ratio {ratio:.3f})")
                    continue
                cur.execute(
                    "UPDATE price_history SET close_price = ROUND((close_price / %s)::numeric, 6) "
                    "WHERE security_id = %s AND price_date < %s",
                    (factor, sid, ex_date),
                )
                print(f"ADJ  {symbol}: {cur.rowcount} rows before {ex_date} divided by {factor}")
        conn.commit()
    finally:
        conn.close()


if __name__ == "__main__":
    main()
