"""
ONE-COMMAND DEMO SETUP  (run from the backend folder)

    python scripts/setup_demo.py

What it does (safe to re-run):
  1. Creates the database from DATABASE_URL in backend/.env if it is missing
  2. Runs every sql/*.sql migration in order
  3. Imports the 2022-09 -> 2026-09 historical price + benchmark CSVs
  4. Back-adjusts splits/bonus issues so portfolio values are correct
  5. Seeds 3 demo portfolios (2022 / 2023 / 2024 inception)

Login afterwards:  manager@pmsdemo.in / password123
"""
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse

import psycopg2

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))
from app.core.config import settings  # noqa: E402


def ensure_database():
    u = urlparse(settings.database_url)
    dbname = u.path.lstrip("/")
    conn = psycopg2.connect(host=u.hostname, port=u.port or 5432, user=u.username,
                            password=u.password, dbname="postgres")
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (dbname,))
        if not cur.fetchone():
            cur.execute(f'CREATE DATABASE "{dbname}"')
            print(f"Created database '{dbname}'")
        else:
            print(f"Database '{dbname}' exists")
    conn.close()


def run_sql():
    conn = psycopg2.connect(settings.database_url)
    conn.autocommit = True
    with conn.cursor() as cur:
        for f in sorted((ROOT / "sql").glob("*.sql")):
            print(f"  SQL  {f.name}")
            cur.execute(f.read_text(encoding="utf-8"))
    conn.close()


def run_script(name):
    print(f"  RUN  scripts/{name}")
    subprocess.check_call([sys.executable, str(ROOT / "scripts" / name)], cwd=str(ROOT))


if __name__ == "__main__":
    print("== 1/5 database"); ensure_database()
    print("== 2/5 migrations"); run_sql()
    conn = psycopg2.connect(settings.database_url); cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM price_history"); have_prices = cur.fetchone()[0] > 0; conn.close()
    if have_prices:
        # Re-run safety: stored prices are already adjusted, so re-importing the
        # raw CSVs would look like price conflicts. Skip both steps.
        print("== 3/5 historical prices: already loaded, skipping")
        print("== 4/5 split/bonus adjustment: already applied, skipping")
    else:
        print("== 3/5 historical prices"); run_script("import_historical_prices.py")
        print("== 4/5 split/bonus adjustment"); run_script("adjust_corporate_actions.py")
    print("== 5/5 demo portfolios"); run_script("seed_demo_portfolios.py")
    print("\nDONE.  Start API:  uvicorn app.main:app --reload   |  Login: manager@pmsdemo.in / password123")
