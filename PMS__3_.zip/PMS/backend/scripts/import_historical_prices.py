import csv
import sys
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from psycopg2.extras import execute_values


# ============================================================
# 1. PROJECT CONFIGURATION
# ============================================================

# Project root: the backend directory
BASE_DIR = Path(__file__).resolve().parents[1]

# Add backend to Python's import path so this script can be run
# from the backend directory with:
# python scripts\import_historical_prices.py
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from app.core.database import get_connection


DATA_DIR = BASE_DIR / "data" / "DATA_PMS"


# Maps source folder names to database security symbols.
FOLDER_TO_SYMBOL = {
    "AXISBANK": "AXISBANK",
    "BHARTIARTL": "BHARTIARTL",
    "HCLTECH": "HCLTECH",
    "HDFC": "HDFCBANK",
    "ICICI": "ICICIBANK",
    "INFY": "INFY",
    "ITC": "ITC",
    "KOTAK": "KOTAKBANK",
    "LT": "LT",
    "MARUTI": "MARUTI",
    "Reliance": "RELIANCE",
    "SBIN": "SBIN",
    "SUNPHARMA": "SUNPHARMA",
    "TCS": "TCS",
    "TITAN": "TITAN",
    "GOLDBEES": "GOLDBEES",
    "EBBETF0430": "EBBETF0430",
    "ITBEES": "ITBEES",
    "NIFTYBEES": "NIFTYBEES",
    "LIQUIDBEES": "LIQUIDBEES",
    "EMBASSY": "EMBASSY",
    "MINDSPACE": "MINDSPACE",
}


# ============================================================
# 2. DISCOVER CSV FILES
# ============================================================

def discover_csv_files():
    """Find CSV files and identify their instrument or benchmark."""

    if not DATA_DIR.is_dir():
        raise FileNotFoundError(
            f"Market-data directory not found: {DATA_DIR}"
        )

    discovered = []

    for file_path in sorted(DATA_DIR.rglob("*.csv")):

        # NIFTY 50 benchmark files
        if file_path.parent.name.upper() == "NIFTY50":
            discovered.append({
                "file_path": file_path,
                "dataset_type": "benchmark",
                "symbol": "^NSEI",
            })
            continue

        # Instrument files
        folder_name = file_path.parent.name
        symbol = FOLDER_TO_SYMBOL.get(folder_name)

        if symbol is None:
            raise ValueError(
                f"Unknown instrument folder: {folder_name}\n"
                f"File: {file_path}"
            )

        discovered.append({
            "file_path": file_path,
            "dataset_type": "instrument",
            "symbol": symbol,
        })

    if not discovered:
        raise FileNotFoundError(
            f"No CSV files found under: {DATA_DIR}"
        )

    return discovered


# ============================================================
# 3. PARSE SOURCE DATES
# ============================================================

def parse_source_date(value):
    """Parse dates such as 25-Sep-2023 or 25-SEP-2023."""

    value = value.strip()

    return datetime.strptime(
        value,
        "%d-%b-%Y",
    ).date()


# ============================================================
# 4. PARSE CLOSING PRICES
# ============================================================

def parse_close_price(value):
    """Parse prices such as 1525.00 or 1,525.00."""

    value = value.strip()

    if not value:
        raise ValueError("Closing price is blank")

    # Remove thousands separators.
    normalized = value.replace(",", "")

    try:
        price = Decimal(normalized)
    except InvalidOperation as exc:
        raise ValueError(
            f"Invalid closing price: {value!r}"
        ) from exc

    if not price.is_finite():
        raise ValueError(
            f"Non-finite closing price: {value!r}"
        )

    if price <= 0:
        raise ValueError(
            f"Closing price must be positive: {value!r}"
        )

    return price


# ============================================================
# 5. PARSE ONE CSV FILE
# ============================================================

def parse_csv_file(file_info):
    """Return valid records and rejected rows for one CSV file."""

    file_path = file_info["file_path"]

    valid_rows = []
    rejected_rows = []

    with file_path.open(
        mode="r",
        encoding="utf-8-sig",
        newline="",
    ) as csv_file:

        reader = csv.DictReader(csv_file)

        if not reader.fieldnames:
            raise ValueError(
                f"CSV has no header: {file_path}"
            )

        # Normalize headers such as "Date ", "DATE", and "Date".
        column_map = {
            header.strip().upper(): header
            for header in reader.fieldnames
            if header is not None
        }

        date_column = column_map.get("DATE")
        close_column = column_map.get("CLOSE")

        if not date_column or not close_column:
            raise ValueError(
                f"Required DATE/CLOSE column missing: {file_path}\n"
                f"Found columns: {reader.fieldnames}"
            )

        for row in reader:
            row_number = reader.line_num

            try:
                raw_date = row.get(date_column)
                raw_close = row.get(close_column)

                if raw_date is None or not raw_date.strip():
                    raise ValueError("Date is blank")

                if raw_close is None:
                    raise ValueError("Closing price is missing")

                price_date = parse_source_date(raw_date)
                close_price = parse_close_price(raw_close)

                valid_rows.append({
                    "dataset_type": file_info["dataset_type"],
                    "symbol": file_info["symbol"],
                    "price_date": price_date,
                    "close_price": close_price,
                    "source_file": str(
                        file_path.relative_to(DATA_DIR)
                    ),
                    "source_row": row_number,
                })

            except (ValueError, InvalidOperation) as exc:
                rejected_rows.append({
                    "source_file": str(
                        file_path.relative_to(DATA_DIR)
                    ),
                    "source_row": row_number,
                    "symbol": file_info["symbol"],
                    "reason": str(exc),
                    "raw_date": row.get(date_column),
                    "raw_close": row.get(close_column),
                })

    return valid_rows, rejected_rows


# ============================================================
# 6. PARSE ALL CSV FILES
# ============================================================

def parse_all_files(files):
    """Parse all discovered files and collect valid/rejected rows."""

    all_valid_rows = []
    all_rejected_rows = []

    for file_info in files:
        valid_rows, rejected_rows = parse_csv_file(file_info)

        all_valid_rows.extend(valid_rows)
        all_rejected_rows.extend(rejected_rows)

        print(
            f'{file_info["symbol"]:12} '
            f'{file_info["file_path"].name}: '
            f'{len(valid_rows)} valid, '
            f'{len(rejected_rows)} rejected'
        )

    return all_valid_rows, all_rejected_rows


# ============================================================
# 7. DEDUPLICATE AND DETECT PRICE CONFLICTS
# ============================================================

def deduplicate_rows(rows):
    """
    Keep one record per dataset, symbol, and date.

    Same key + same price = identical duplicate.
    Same key + different price = conflict.
    """

    unique_rows = {}
    duplicate_rows = []
    price_conflicts = []

    for row in rows:
        key = (
            row["dataset_type"],
            row["symbol"],
            row["price_date"],
        )

        existing = unique_rows.get(key)

        # First occurrence of this record.
        if existing is None:
            unique_rows[key] = row
            continue

        # Same date, symbol, dataset, and price.
        if existing["close_price"] == row["close_price"]:
            duplicate_rows.append({
                "key": key,
                "kept_source": existing["source_file"],
                "duplicate_source": row["source_file"],
                "price": row["close_price"],
            })

        # Same key but different closing price.
        else:
            price_conflicts.append({
                "key": key,
                "existing_price": existing["close_price"],
                "conflicting_price": row["close_price"],
                "existing_source": existing["source_file"],
                "conflicting_source": row["source_file"],
            })

    return (
        list(unique_rows.values()),
        duplicate_rows,
        price_conflicts,
    )


# ============================================================
# 8. VALIDATE DATABASE SECURITY MAPPINGS
# ============================================================

def validate_database_mappings(rows):
    """
    Read-only database validation.

    Checks:
    - Every instrument maps to exactly one active NSE security.
    - The source benchmark symbol is ^NSEI.

    This function does not insert or update database records.
    """

    instrument_symbols = sorted({
        row["symbol"]
        for row in rows
        if row["dataset_type"] == "instrument"
    })

    benchmark_symbols = sorted({
        row["symbol"]
        for row in rows
        if row["dataset_type"] == "benchmark"
    })

    errors = []
    security_mappings = {}

    # Check the source benchmark symbol.
    if benchmark_symbols != ["^NSEI"]:
        errors.append(
            f"Unexpected benchmark symbols: {benchmark_symbols}"
        )

    # Fetch matching NSE securities from PostgreSQL.
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    security_id,
                    exchange,
                    symbol,
                    is_active
                FROM public.securities
                WHERE exchange = %s
                  AND symbol = ANY(%s)
                ORDER BY symbol, security_id
                """,
                ("NSE", instrument_symbols),
            )

            db_rows = cur.fetchall()

    # Group database records by symbol.
    db_by_symbol = {}

    for security_id, exchange, symbol, is_active in db_rows:
        db_by_symbol.setdefault(symbol, []).append({
            "security_id": security_id,
            "exchange": exchange,
            "is_active": is_active,
        })

    # Validate each instrument.
    for symbol in instrument_symbols:
        matches = db_by_symbol.get(symbol, [])

        if not matches:
            errors.append(
                f"{symbol}: no NSE security mapping found"
            )
            continue

        if len(matches) > 1:
            errors.append(
                f"{symbol}: multiple NSE security mappings found"
            )
            continue

        security = matches[0]

        if not security["is_active"]:
            errors.append(
                f"{symbol}: security is inactive"
            )
            continue

        security_mappings[symbol] = security["security_id"]

    return security_mappings, errors


# ============================================================
# 9. IMPORT HISTORICAL PRICES TRANSACTIONALLY
# ============================================================

def import_historical_prices(rows, security_mappings):
    """
    Import instrument and benchmark prices transactionally.

    Existing same-price records are skipped.
    Existing different-price records cause a rollback.

    Also refreshes securities.last_price from the latest
    historical close for each imported security.
    """

    instrument_rows = []
    benchmark_rows = []

    for row in rows:
        if row["dataset_type"] == "instrument":
            security_id = security_mappings[row["symbol"]]

            instrument_rows.append((
                security_id,
                row["price_date"],
                row["close_price"],
            ))

        elif row["dataset_type"] == "benchmark":
            benchmark_rows.append((
                row["symbol"],
                row["price_date"],
                row["close_price"],
            ))

        else:
            raise ValueError(
                f'Unknown dataset type: {row["dataset_type"]}'
            )

    # get_connection() commits on success and rolls back on exception.
    with get_connection() as conn:
        with conn.cursor() as cur:

            # Prevent concurrent writes to these tables while we
            # check for conflicts and insert new rows.
            cur.execute("""
                LOCK TABLE public.price_history,
                           public.benchmark_history
                IN SHARE ROW EXCLUSIVE MODE
            """)

            # Stage instrument prices in a transaction-scoped table.
            cur.execute("""
                CREATE TEMP TABLE stage_prices (
                    security_id BIGINT NOT NULL,
                    price_date DATE NOT NULL,
                    close_price NUMERIC NOT NULL,
                    PRIMARY KEY (security_id, price_date)
                ) ON COMMIT DROP
            """)

            # Stage benchmark prices in a transaction-scoped table.
            cur.execute("""
                CREATE TEMP TABLE stage_benchmarks (
                    benchmark_symbol TEXT NOT NULL,
                    price_date DATE NOT NULL,
                    close_price NUMERIC NOT NULL,
                    PRIMARY KEY (benchmark_symbol, price_date)
                ) ON COMMIT DROP
            """)

            if instrument_rows:
                execute_values(
                    cur,
                    """
                    INSERT INTO stage_prices
                        (security_id, price_date, close_price)
                    VALUES %s
                    """,
                    instrument_rows,
                )

            if benchmark_rows:
                execute_values(
                    cur,
                    """
                    INSERT INTO stage_benchmarks
                        (benchmark_symbol, price_date, close_price)
                    VALUES %s
                    """,
                    benchmark_rows,
                )

            # Detect existing instrument records with different prices.
            cur.execute("""
                SELECT
                    s.security_id,
                    s.price_date,
                    s.close_price AS incoming_price,
                    p.close_price AS existing_price
                FROM stage_prices AS s
                JOIN public.price_history AS p
                  ON p.security_id = s.security_id
                 AND p.price_date = s.price_date
                WHERE p.close_price IS DISTINCT FROM s.close_price
                ORDER BY s.security_id, s.price_date
            """)

            instrument_conflicts = cur.fetchall()

            # Detect existing benchmark records with different prices.
            cur.execute("""
                SELECT
                    s.benchmark_symbol,
                    s.price_date,
                    s.close_price AS incoming_price,
                    b.close_price AS existing_price
                FROM stage_benchmarks AS s
                JOIN public.benchmark_history AS b
                  ON b.benchmark_symbol = s.benchmark_symbol
                 AND b.price_date = s.price_date
                WHERE b.close_price IS DISTINCT FROM s.close_price
                ORDER BY s.benchmark_symbol, s.price_date
            """)

            benchmark_conflicts = cur.fetchall()

            # Any conflict aborts the entire transaction.
            if instrument_conflicts or benchmark_conflicts:
                details = [
                    "Existing database prices differ from incoming prices."
                ]

                for conflict in instrument_conflicts[:10]:
                    details.append(
                        "Instrument conflict: "
                        f"security_id={conflict[0]}, "
                        f"date={conflict[1]}, "
                        f"existing={conflict[3]}, "
                        f"incoming={conflict[2]}"
                    )

                for conflict in benchmark_conflicts[:10]:
                    details.append(
                        "Benchmark conflict: "
                        f"symbol={conflict[0]}, "
                        f"date={conflict[1]}, "
                        f"existing={conflict[3]}, "
                        f"incoming={conflict[2]}"
                    )

                total_conflicts = (
                    len(instrument_conflicts)
                    + len(benchmark_conflicts)
                )

                if total_conflicts > 20:
                    details.append(
                        f"...and {total_conflicts - 20} more conflicts"
                    )

                raise ValueError("\n".join(details))

            # Insert only new instrument records.
            # Same-price existing records are skipped.
            cur.execute("""
                INSERT INTO public.price_history
                    (security_id, price_date, close_price)
                SELECT
                    s.security_id,
                    s.price_date,
                    s.close_price
                FROM stage_prices AS s
                ON CONFLICT (security_id, price_date)
                DO NOTHING
            """)

            instrument_inserted = cur.rowcount

            # Insert only new benchmark records.
            # Same-price existing records are skipped.
            cur.execute("""
                INSERT INTO public.benchmark_history
                    (benchmark_symbol, price_date, close_price)
                SELECT
                    s.benchmark_symbol,
                    s.price_date,
                    s.close_price
                FROM stage_benchmarks AS s
                ON CONFLICT (benchmark_symbol, price_date)
                DO NOTHING
            """)

            benchmark_inserted = cur.rowcount

            # Refresh last_price from the latest stored close for every
            # security represented in this import. This runs in the same
            # transaction as the history inserts, so failures roll it back.
            cur.execute("""
                WITH affected_securities AS (
                    SELECT DISTINCT security_id
                    FROM stage_prices
                ),
                latest_prices AS (
                    SELECT DISTINCT ON (p.security_id)
                        p.security_id,
                        p.close_price,
                        p.price_date
                    FROM public.price_history AS p
                    JOIN affected_securities AS a
                      ON a.security_id = p.security_id
                    ORDER BY p.security_id, p.price_date DESC
                )
                UPDATE public.securities AS s
                SET last_price = lp.close_price,
                    last_price_date = lp.price_date
                FROM latest_prices AS lp
                WHERE s.security_id = lp.security_id
                  AND (s.last_price IS DISTINCT FROM lp.close_price
                       OR s.last_price_date IS DISTINCT FROM lp.price_date)
            """)

            securities_updated = cur.rowcount

    # The context manager has committed successfully by this point.
    return (
        instrument_inserted,
        benchmark_inserted,
        securities_updated,
    )


# ============================================================
# 10. IMPORT-RUN AUDIT LOGGING
# ============================================================

def create_import_run():
    """Create and commit a RUNNING audit record before processing."""

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO public.data_import_runs
                    (dataset_name, source_name, status)
                VALUES (%s, %s, %s)
                RETURNING import_id
                """,
                (
                    "historical_prices",
                    "DATA_PMS CSV files",
                    "RUNNING",
                ),
            )
            import_id = cur.fetchone()[0]

    # get_connection() commits when its context exits successfully.
    return import_id


def finish_import_run(
    import_id,
    status,
    row_read,
    rows_inserted,
    rows_updated,
    rows_rejected,
    error_message=None,
):
    """Update the audit record in its own database transaction."""

    if status not in {"COMPLETED", "FAILED"}:
        raise ValueError(f"Unsupported final import status: {status}")

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE public.data_import_runs
                SET completed_at = NOW(),
                    status = %s,
                    rows_read = %s,
                    rows_inserted = %s,
                    rows_updated = %s,
                    rows_rejected = %s,
                    error_message = %s
                WHERE import_id = %s
                """,
                (
                    status,
                    row_read,
                    rows_inserted,
                    rows_updated,
                    rows_rejected,
                    error_message,
                    import_id,
                ),
            )

            if cur.rowcount != 1:
                raise RuntimeError(
                    f"Expected to update one audit row for import_id={import_id}; "
                    f"updated {cur.rowcount}."
                )


# ============================================================
# 11. MAIN PROGRAM
# ============================================================

def main():
    # Commit the audit row separately, before any import work starts.
    import_id = create_import_run()
    print(f"Import audit ID: {import_id}")

    row_read = 0
    rows_inserted = 0
    rows_updated = 0
    rows_rejected = 0

    # These flags distinguish a failed price transaction from an audit
    # finalization issue that happens after the price transaction commits.
    price_import_committed = False

    try:
        # Step 1: Discover files.
        files = discover_csv_files()

        instrument_files = [
            item for item in files
            if item["dataset_type"] == "instrument"
        ]

        benchmark_files = [
            item for item in files
            if item["dataset_type"] == "benchmark"
        ]

        print(f"Total CSV files: {len(files)}")
        print(f"Instrument files: {len(instrument_files)}")
        print(f"Benchmark files: {len(benchmark_files)}")

        # Step 2: Parse files.
        print("\nParsing CSV files...")
        valid_rows, rejected_rows = parse_all_files(files)

        # row_read means source data rows parsed, valid or rejected.
        row_read = len(valid_rows) + len(rejected_rows)
        rows_rejected = len(rejected_rows)

        # Step 3: Deduplicate parsed records.
        unique_rows, duplicate_rows, price_conflicts = (
            deduplicate_rows(valid_rows)
        )

        # Step 4: Validate database mappings.
        print("\nValidating database mappings...")
        security_mappings, mapping_errors = (
            validate_database_mappings(unique_rows)
        )

        # Step 5: Print preflight summary.
        print("\n" + "=" * 50)
        print("HISTORICAL PRICE IMPORT PREFLIGHT")
        print("=" * 50)

        print(f"Files processed:       {len(files)}")
        print(f"Instrument files:      {len(instrument_files)}")
        print(f"Benchmark files:       {len(benchmark_files)}")
        print(f"Parsed valid rows:     {len(valid_rows)}")
        print(f"Rejected rows:         {len(rejected_rows)}")
        print(f"Identical duplicates:  {len(duplicate_rows)}")
        print(f"Price conflicts:       {len(price_conflicts)}")
        print(f"Unique records:        {len(unique_rows)}")
        print(f"Mapped instruments:    {len(security_mappings)}")
        print(f"Mapping errors:        {len(mapping_errors)}")

        if rejected_rows:
            print("\nREJECTED ROWS:")
            for rejected in rejected_rows[:20]:
                print(rejected)
            if len(rejected_rows) > 20:
                print(
                    f"...and {len(rejected_rows) - 20} more rejected rows"
                )

        if price_conflicts:
            print("\nSOURCE CSV PRICE CONFLICTS:")
            for conflict in price_conflicts[:20]:
                print(conflict)
            if len(price_conflicts) > 20:
                print(
                    f"...and {len(price_conflicts) - 20} more conflicts"
                )

        if mapping_errors:
            print("\nDATABASE MAPPING ERRORS:")
            for error in mapping_errors:
                print(f"ERROR: {error}")

        print("\n" + "=" * 50)

        # A failed preflight is an unsuccessful import run, and is audited.
        if rejected_rows or price_conflicts or mapping_errors:
            error_parts = ["Preflight failed; no price rows were imported."]
            if rejected_rows:
                error_parts.append(f"Rejected rows: {len(rejected_rows)}.")
            if price_conflicts:
                error_parts.append(
                    f"Source CSV price conflicts: {len(price_conflicts)}."
                )
            if mapping_errors:
                error_parts.append(
                    f"Database mapping errors: {len(mapping_errors)}."
                )

            error_message = " ".join(error_parts)
            finish_import_run(
                import_id=import_id,
                status="FAILED",
                row_read=row_read,
                rows_inserted=0,
                rows_updated=0,
                rows_rejected=rows_rejected,
                error_message=error_message,
            )
            print("PREFLIGHT FAILED")
            print("Import skipped. Resolve the issues first.")
            print("Audit status: FAILED")
            print("=" * 50)
            return

        print("PREFLIGHT PASSED")
        print("Starting transactional import...")

        # Import history and update last_price atomically.
        (
            instrument_inserted,
            benchmark_inserted,
            rows_updated,
        ) = import_historical_prices(
            unique_rows,
            security_mappings,
        )

        rows_inserted = instrument_inserted + benchmark_inserted
        price_import_committed = True

    except Exception as exc:
        error_message = f"{type(exc).__name__}: {exc}"

        print("\nIMPORT FAILED")
        print(error_message)
        if not price_import_committed:
            print("The price import transaction did not commit.")

        try:
            finish_import_run(
                import_id=import_id,
                status="FAILED",
                row_read=row_read,
                rows_inserted=rows_inserted,
                rows_updated=rows_updated,
                rows_rejected=rows_rejected,
                error_message=error_message,
            )
            print(f"Audit status: FAILED (import_id={import_id})")
        except Exception as audit_exc:
            print(
                "WARNING: Could not update the audit record to FAILED: "
                f"{type(audit_exc).__name__}: {audit_exc}"
            )
        print("=" * 50)
        return

    # The price transaction has committed. Finalize its audit record in a
    # separate transaction so audit failure cannot undo committed prices.
    print("\nIMPORT COMPLETED")
    print(f"Instrument records inserted: {instrument_inserted}")
    print(f"Benchmark records inserted:  {benchmark_inserted}")
    print(f"Total records inserted:      {rows_inserted}")
    print(f"Security last_price updated: {rows_updated}")
    print("Existing historical records with identical prices were skipped.")

    try:
        finish_import_run(
            import_id=import_id,
            status="COMPLETED",
            row_read=row_read,
            rows_inserted=rows_inserted,
            rows_updated=rows_updated,
            rows_rejected=rows_rejected,
            error_message=None,
        )
        print(f"Audit status: COMPLETED (import_id={import_id})")
    except Exception as audit_exc:
        print(
            "WARNING: Prices were committed, but the audit record could not "
            "be marked COMPLETED. "
            f"import_id={import_id}; "
            f"{type(audit_exc).__name__}: {audit_exc}"
        )

    print("=" * 50)


if __name__ == "__main__":
    main()