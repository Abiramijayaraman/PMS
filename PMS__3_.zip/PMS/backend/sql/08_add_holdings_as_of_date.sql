-- holdings.repository / holdings.service / performance.repository have
-- always read and written holdings.as_of_date (the historical date a
-- position was opened - used to know from which date onward a holding
-- contributes to the portfolio's value/performance/drift series), but
-- 01_create_tables.sql never created the column. Every "add holding"
-- call failed with UndefinedColumn until this migration is applied.

ALTER TABLE holdings
    ADD COLUMN IF NOT EXISTS as_of_date DATE;

-- Backfill safety net for any pre-existing rows: fall back to the date
-- the row was added (added_at), truncated to a date.
UPDATE holdings
SET as_of_date = added_at::date
WHERE as_of_date IS NULL;

ALTER TABLE holdings
    ALTER COLUMN as_of_date SET NOT NULL;

CREATE INDEX IF NOT EXISTS idx_holdings_as_of_date
    ON holdings (portfolio_id, as_of_date);
