-- GICS classification subsystem expected by app/modules/classification and
-- performance.get_sector_breakdown. The code queried these objects but no
-- earlier migration created them (sector-breakdown returned HTTP 500).

CREATE TABLE IF NOT EXISTS issuers (
    issuer_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    issuer_name VARCHAR(200) NOT NULL,
    country VARCHAR(60) NOT NULL DEFAULT 'India',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_issuer_name_country UNIQUE (issuer_name, country)
);

CREATE TABLE IF NOT EXISTS issuer_gics_classifications (
    classification_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    issuer_id BIGINT NOT NULL REFERENCES issuers(issuer_id),
    gics_sector_code VARCHAR(2) NOT NULL,
    gics_industry_group_code VARCHAR(4) NOT NULL,
    gics_industry_code VARCHAR(6) NOT NULL,
    gics_sub_industry_code VARCHAR(8) NOT NULL,
    source VARCHAR(60) NOT NULL DEFAULT 'manual',
    effective_from DATE NOT NULL,
    effective_to DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gics_issuer ON issuer_gics_classifications (issuer_id, effective_from);

ALTER TABLE securities ADD COLUMN IF NOT EXISTS issuer_id BIGINT REFERENCES issuers(issuer_id);

-- One issuer per equity security
INSERT INTO issuers (issuer_name, country)
SELECT s.security_name, 'India'
FROM securities s JOIN asset_classes ac ON ac.asset_id = s.asset_id
WHERE ac.asset_class = 'Equity'
ON CONFLICT (issuer_name, country) DO NOTHING;

UPDATE securities s SET issuer_id = i.issuer_id
FROM issuers i
WHERE i.issuer_name = s.security_name AND i.country = 'India' AND s.issuer_id IS NULL;

-- GICS sector mapped from the sector/industry already stored on each security
INSERT INTO issuer_gics_classifications
    (issuer_id, gics_sector_code, gics_industry_group_code, gics_industry_code, gics_sub_industry_code, source, effective_from)
SELECT s.issuer_id,
       m.sector, m.grp, m.ind, m.sub, 'seed', DATE '2022-01-01'
FROM securities s
JOIN (VALUES
    ('Oil & Gas',         '10','1010','101020','10102020'),
    ('Banking',           '40','4010','401010','40101010'),
    ('IT Services',       '45','4510','451020','45102010'),
    ('Telecom Services',  '50','5010','501010','50101010'),
    ('Construction',      '20','2010','201030','20103010'),
    ('FMCG',              '30','3020','302020','30202010'),
    ('Automobile',        '25','2510','251020','25102010'),
    ('Pharmaceuticals',   '35','3520','352020','35202010'),
    ('Consumer Durables', '25','2520','252030','25203010')
) AS m(industry, sector, grp, ind, sub) ON m.industry = s.industry
WHERE s.issuer_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM issuer_gics_classifications c WHERE c.issuer_id = s.issuer_id);
