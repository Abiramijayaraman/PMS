-- The application (schemas.PortfolioCreate/PortfolioOut, portfolios.service,
-- portfolios.repository) has always read/written portfolios.inception_date,
-- but 01_create_tables.sql never created the column. Every portfolio create
-- failed with UndefinedColumn until this migration is applied.
--
-- inception_date is the historical "start date" of a portfolio's backtest -
-- when it defaults, it is set to the latest date covered by the static
-- price dataset (see app/common/dates.get_data_as_of_date), never the OS
-- wall-clock date, since this system only ever operates on historical data.

ALTER TABLE portfolios
    ADD COLUMN IF NOT EXISTS inception_date DATE;

-- Backfill safety net for any pre-existing rows (none expected on a fresh
-- install): fall back to the portfolio's own creation date.
UPDATE portfolios
SET inception_date = created_at::date
WHERE inception_date IS NULL;

ALTER TABLE portfolios
    ALTER COLUMN inception_date SET NOT NULL;

CREATE INDEX IF NOT EXISTS idx_portfolios_inception_date
    ON portfolios (inception_date);
