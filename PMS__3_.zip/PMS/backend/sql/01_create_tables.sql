-- =========================================================
-- PORTFOLIO MANAGEMENT SYSTEM
-- PostgreSQL | React + FastAPI + psycopg2
-- =========================================================

CREATE TABLE IF NOT EXISTS users (
    user_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'FUND_MANAGER',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =========================================================
-- 1. ASSET CLASSES
-- =========================================================

CREATE TABLE IF NOT EXISTS asset_classes (
    asset_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    asset_code VARCHAR(30) NOT NULL UNIQUE,
    asset_class VARCHAR(80) NOT NULL,
    asset_description TEXT,
    sub_asset_class VARCHAR(100),
    sub_asset_description TEXT,
    risk VARCHAR(30),
    investment_horizon VARCHAR(30),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_asset_risk
        CHECK (
            risk IS NULL OR
            risk IN ('LOW', 'LOW_MODERATE', 'MEDIUM',
                     'MODERATE', 'HIGH', 'VERY_HIGH')
        )
);

-- =========================================================
-- 2. INVESTMENT THEMES
-- =========================================================

CREATE TABLE IF NOT EXISTS investment_themes (
    theme_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    theme_name VARCHAR(80) NOT NULL UNIQUE,
    description TEXT,
    risk_level VARCHAR(30) NOT NULL,
    investment_horizon VARCHAR(30) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_theme_risk
        CHECK (
            risk_level IN (
                'LOW', 'LOW_MODERATE', 'MODERATE', 'HIGH', 'VERY_HIGH'
            )
        )
);

-- =========================================================
-- 3. THEME ALLOCATION
-- =========================================================

CREATE TABLE IF NOT EXISTS theme_allocation (
    theme_id BIGINT NOT NULL REFERENCES investment_themes(theme_id),
    asset_id BIGINT NOT NULL REFERENCES asset_classes(asset_id),
    allocation_pct NUMERIC(5,2) NOT NULL,
    PRIMARY KEY (theme_id, asset_id),
    CONSTRAINT chk_theme_allocation_pct CHECK (allocation_pct BETWEEN 0 AND 100)
);

-- =========================================================
-- 4. SECURITIES MASTER
-- =========================================================

CREATE TABLE IF NOT EXISTS securities (
    security_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    exchange VARCHAR(10) NOT NULL DEFAULT 'NSE',
    symbol VARCHAR(40) NOT NULL,
    security_series VARCHAR(20),
    security_code VARCHAR(50),
    isin VARCHAR(20),
    security_name VARCHAR(250) NOT NULL,
    asset_id BIGINT NOT NULL REFERENCES asset_classes(asset_id),
    sector VARCHAR(120),
    industry VARCHAR(150),
    equity_category VARCHAR(30),
    country VARCHAR(80) NOT NULL DEFAULT 'India',
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    last_price NUMERIC(20,6),
    last_price_date DATE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_security_exchange_symbol UNIQUE (exchange, symbol),
    CONSTRAINT chk_security_exchange CHECK (exchange IN ('NSE', 'BSE')),
    CONSTRAINT chk_security_equity_category CHECK (
        equity_category IS NULL OR
        equity_category IN ('LARGE_CAP', 'MID_CAP', 'SMALL_CAP')
    ),
    CONSTRAINT chk_security_price CHECK (last_price IS NULL OR last_price >= 0)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_securities_exchange_isin
ON securities (exchange, isin)
WHERE isin IS NOT NULL;

-- =========================================================
-- 5. PORTFOLIOS
-- =========================================================

CREATE TABLE IF NOT EXISTS portfolios (
    portfolio_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(user_id),
    portfolio_name VARCHAR(150) NOT NULL,
    portfolio_type VARCHAR(20) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    exchange VARCHAR(10) NOT NULL DEFAULT 'NSE',
    benchmark_symbol VARCHAR(40) NOT NULL DEFAULT '^NSEI',
    theme_id BIGINT NOT NULL REFERENCES investment_themes(theme_id),
    rebalancing_frequency VARCHAR(20) NOT NULL,
    initial_investment NUMERIC(20,2) NOT NULL,
    inception_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'NEW',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ,

    CONSTRAINT chk_portfolio_type CHECK (portfolio_type IN ('WEIGHTAGE', 'AMOUNT')),
    CONSTRAINT chk_portfolio_exchange CHECK (exchange IN ('NSE', 'BSE')),
    CONSTRAINT chk_rebalancing_frequency CHECK (
        rebalancing_frequency IN ('DAILY','MONTHLY','QUARTERLY','HALF_YEARLY','YEARLY')
    ),
    CONSTRAINT chk_portfolio_investment CHECK (initial_investment > 0),
    CONSTRAINT chk_portfolio_status CHECK (status IN ('NEW', 'ACTIVE', 'CLOSED'))
);

-- =========================================================
-- 6. HOLDINGS
-- =========================================================

CREATE TABLE IF NOT EXISTS holdings (
    holding_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    portfolio_id BIGINT NOT NULL REFERENCES portfolios(portfolio_id),
    security_id BIGINT NOT NULL REFERENCES securities(security_id),
    quantity NUMERIC(24,8) NOT NULL,
    avg_price NUMERIC(20,6) NOT NULL,
    as_of_date DATE NOT NULL,
    target_weight_pct NUMERIC(7,4),
    target_amount NUMERIC(20,2),
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_portfolio_security UNIQUE (portfolio_id, security_id),
    CONSTRAINT chk_holding_quantity CHECK (quantity > 0),
    CONSTRAINT chk_holding_avg_price CHECK (avg_price >= 0),
    CONSTRAINT chk_holding_target_weight CHECK (
        target_weight_pct IS NULL OR target_weight_pct BETWEEN 0 AND 100
    ),
    CONSTRAINT chk_holding_target_amount CHECK (target_amount IS NULL OR target_amount >= 0)
);

-- =========================================================
-- 7. TRANSACTIONS
-- =========================================================

CREATE TABLE IF NOT EXISTS transactions (
    txn_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    portfolio_id BIGINT NOT NULL REFERENCES portfolios(portfolio_id),
    security_id BIGINT NOT NULL REFERENCES securities(security_id),
    action VARCHAR(10) NOT NULL,
    quantity NUMERIC(24,8) NOT NULL,
    price NUMERIC(20,6) NOT NULL,
    txn_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_transaction_action CHECK (action IN ('BUY', 'SELL')),
    CONSTRAINT chk_transaction_quantity CHECK (quantity > 0),
    CONSTRAINT chk_transaction_price CHECK (price >= 0)
);

-- =========================================================
-- 8. PRICE HISTORY
-- =========================================================

CREATE TABLE IF NOT EXISTS price_history (
    security_id BIGINT NOT NULL REFERENCES securities(security_id),
    price_date DATE NOT NULL,
    adjusted_close NUMERIC(20,6) NOT NULL,
    source VARCHAR(50),
    imported_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (security_id, price_date),
    CONSTRAINT chk_adjusted_close CHECK (adjusted_close >= 0)
);

-- =========================================================
-- 9. BENCHMARK HISTORY
-- =========================================================

CREATE TABLE IF NOT EXISTS benchmark_history (
    benchmark_symbol VARCHAR(40) NOT NULL,
    price_date DATE NOT NULL,
    adjusted_close NUMERIC(20,6) NOT NULL,
    source VARCHAR(50),
    imported_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (benchmark_symbol, price_date),
    CONSTRAINT chk_benchmark_price CHECK (adjusted_close >= 0)
);

-- =========================================================
-- 10. DATA IMPORT RUNS
-- =========================================================

CREATE TABLE IF NOT EXISTS data_import_runs (
    import_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    dataset_name VARCHAR(80) NOT NULL,
    source_name VARCHAR(100),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'RUNNING',
    rows_read BIGINT NOT NULL DEFAULT 0,
    rows_inserted BIGINT NOT NULL DEFAULT 0,
    rows_updated BIGINT NOT NULL DEFAULT 0,
    rows_rejected BIGINT NOT NULL DEFAULT 0,
    error_message TEXT,
    CONSTRAINT chk_import_status CHECK (status IN ('RUNNING', 'COMPLETED', 'FAILED'))
);
