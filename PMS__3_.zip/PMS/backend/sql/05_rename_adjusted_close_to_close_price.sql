-- Idempotent: renames adjusted_close -> close_price only if it still exists.
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_name = 'price_history' AND column_name = 'adjusted_close') THEN
        ALTER TABLE price_history RENAME COLUMN adjusted_close TO close_price;
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.columns
               WHERE table_name = 'benchmark_history' AND column_name = 'adjusted_close') THEN
        ALTER TABLE benchmark_history RENAME COLUMN adjusted_close TO close_price;
    END IF;
END $$;
