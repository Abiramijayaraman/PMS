-- =========================================================
-- DEMO USER
-- =========================================================

INSERT INTO users (name, email, password_hash, role)
VALUES (
    'Demo Fund Manager',
    'manager@pmsdemo.in',
    -- Real bcrypt hash of 'password123' -- CHANGE THIS before any real use.
    -- (The hash previously here was a fabricated placeholder string that
    -- did not actually correspond to any password, so no demo login could
    -- ever succeed until it was regenerated with passlib's bcrypt scheme.)
    '$2b$12$gXDSBNT97yR5Yk7nAk/kROTJeMQd/9bVZdgB4hO1uv5AGjCqtdhou',
    'FUND_MANAGER'
)
ON CONFLICT (email) DO NOTHING;

-- =========================================================
-- ASSET CLASSES
-- =========================================================

INSERT INTO asset_classes (
    asset_code, asset_class, asset_description, sub_asset_class, risk, investment_horizon
)
VALUES
('EQUITY',    'Equity',            'Individual listed equity securities',   'Listed Stocks', 'HIGH',   'LONG'),
('BROAD_ETF', 'Broad Market ETF',  'Broad-market exchange-traded funds',    'Index ETF',     'MEDIUM', 'LONG'),
('GOLD',      'Gold',              'Gold-linked exchange-traded instruments','Gold ETF',      'LOW',    'LONG'),
('REIT',      'Real Estate',       'Listed real estate investment trusts',  'REIT',          'MEDIUM', 'LONG'),
('DEBT',      'Debt',              'Debt and fixed-income instruments',     'Debt ETF',      'LOW',    'SHORT')
ON CONFLICT (asset_code) DO NOTHING;

-- =========================================================
-- INVESTMENT THEMES
-- =========================================================

INSERT INTO investment_themes (theme_name, description, risk_level, investment_horizon)
VALUES
('Conservative',             'Lower equity exposure with debt and diversified assets', 'LOW',          'LONG'),
('Moderately Conservative',  'Moderate equity exposure with diversified holdings',     'LOW_MODERATE', 'LONG'),
('Moderately Aggressive',    'Growth-oriented portfolio with diversified exposure',    'MODERATE',     'LONG'),
('Aggressive',                'High equity exposure with alternative asset allocation', 'HIGH',        'LONG'),
('Very Aggressive',          'Very high equity exposure',                              'VERY_HIGH',    'LONG')
ON CONFLICT (theme_name) DO NOTHING;

-- =========================================================
-- THEME ALLOCATIONS
-- =========================================================

WITH allocation_seed (theme_name, asset_code, allocation_pct) AS (
    VALUES
    ('Conservative', 'EQUITY', 20.00::NUMERIC),
    ('Conservative', 'BROAD_ETF', 40.00::NUMERIC),
    ('Conservative', 'GOLD', 0.00::NUMERIC),
    ('Conservative', 'REIT', 20.00::NUMERIC),
    ('Conservative', 'DEBT', 20.00::NUMERIC),

    ('Moderately Conservative', 'EQUITY', 40.00::NUMERIC),
    ('Moderately Conservative', 'BROAD_ETF', 20.00::NUMERIC),
    ('Moderately Conservative', 'GOLD', 5.00::NUMERIC),
    ('Moderately Conservative', 'REIT', 20.00::NUMERIC),
    ('Moderately Conservative', 'DEBT', 15.00::NUMERIC),

    ('Moderately Aggressive', 'EQUITY', 60.00::NUMERIC),
    ('Moderately Aggressive', 'BROAD_ETF', 20.00::NUMERIC),
    ('Moderately Aggressive', 'GOLD', 5.00::NUMERIC),
    ('Moderately Aggressive', 'REIT', 10.00::NUMERIC),
    ('Moderately Aggressive', 'DEBT', 5.00::NUMERIC),

    ('Aggressive', 'EQUITY', 70.00::NUMERIC),
    ('Aggressive', 'BROAD_ETF', 0.00::NUMERIC),
    ('Aggressive', 'GOLD', 10.00::NUMERIC),
    ('Aggressive', 'REIT', 10.00::NUMERIC),
    ('Aggressive', 'DEBT', 10.00::NUMERIC),

    ('Very Aggressive', 'EQUITY', 90.00::NUMERIC),
    ('Very Aggressive', 'BROAD_ETF', 0.00::NUMERIC),
    ('Very Aggressive', 'GOLD', 5.00::NUMERIC),
    ('Very Aggressive', 'REIT', 5.00::NUMERIC),
    ('Very Aggressive', 'DEBT', 0.00::NUMERIC)
)
INSERT INTO theme_allocation (theme_id, asset_id, allocation_pct)
SELECT t.theme_id, a.asset_id, s.allocation_pct
FROM allocation_seed s
JOIN investment_themes t ON t.theme_name = s.theme_name
JOIN asset_classes a ON a.asset_code = s.asset_code
ON CONFLICT (theme_id, asset_id) DO UPDATE SET allocation_pct = EXCLUDED.allocation_pct;
