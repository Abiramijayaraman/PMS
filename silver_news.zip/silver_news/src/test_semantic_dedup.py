from deduplicate_news import (
    calculate_similarity,
    has_shared_event_context,
    detect_new_information
)

# ==========================================
# TEST 3: SAME COMPANY, DIFFERENT EVENT
# ==========================================

original = (
    "Infosys announces a 500 crore share buyback"
)

incoming = (
    "Infosys wins a major AI transformation contract "
    "from a global banking client"
)

print("\n========== TEST 3 ==========")

similarity = calculate_similarity(
    original,
    incoming
)

context_match, shared_terms = has_shared_event_context(
    incoming,
    original
)

has_new_info, new_terms, new_numbers = detect_new_information(
    incoming,
    original
)

print("Original:", original)
print("Incoming:", incoming)

print("\nCosine similarity:", round(similarity, 4))
print("Shared context:", context_match)
print("Shared terms:", shared_terms)
print("New material terms:", new_terms)
print("New numbers:", new_numbers)
print("New information detected:", has_new_info)

# ==========================================
# DECISION LOGIC
# ==========================================

if similarity >= 0.90:

    if has_new_info:
        print("\nRESULT: HIGH SIMILARITY, BUT NEW INFORMATION")
        print("ACTION: RETAIN incoming article")

    else:
        print("\nRESULT: HIGH-CONFIDENCE DUPLICATE")
        print("ACTION: DISCARD incoming article")

elif similarity >= 0.70:

    if context_match and not has_new_info:
        print("\nRESULT: MIDDLE-ZONE DUPLICATE")
        print("ACTION: DISCARD incoming article")

    else:
        print("\nRESULT: RELATED NEWS WITH ADDITIONAL INFORMATION")
        print("ACTION: RETAIN incoming article")

else:
    print("\nRESULT: UNIQUE NEWS")
    print("ACTION: RETAIN incoming article")