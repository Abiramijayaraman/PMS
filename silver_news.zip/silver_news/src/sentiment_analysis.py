
import torch
import time

from pathlib import Path

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification
)

from pyspark.sql import functions as F
from pyspark.sql.types import StringType, DoubleType



PROJECT_FOLDER = Path(__file__).resolve().parents[1]

MODEL_PATH = PROJECT_FOLDER / "models" / "finbert"

BATCH_SIZE = 24
MAX_LENGTH = 512  
_FINBERT_CACHE = None



def load_finbert():

    global _FINBERT_CACHE
    if _FINBERT_CACHE is not None:
        print("FinBERT already loaded; reusing the in-memory model.")
        return _FINBERT_CACHE

    print("\n========== LOADING FINBERT ==========")

    required_files = [
        "config.json",
        "model.safetensors",
        "tokenizer_config.json",
        "special_tokens_map.json",
        "vocab.txt"
    ]

    missing_files = [
        filename
        for filename in required_files
        if not (MODEL_PATH / filename).exists()
    ]

    if missing_files:
        raise FileNotFoundError(
            f"Missing FinBERT model files: {missing_files}"
        )

    
    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    print("Using device:", device)

    
    tokenizer = AutoTokenizer.from_pretrained(
        str(MODEL_PATH),
        local_files_only=True
    )

    print("Tokenizer loaded successfully.")

    
    model = AutoModelForSequenceClassification.from_pretrained(
        str(MODEL_PATH),
        local_files_only=True
    )

    model.to(device)
    model.eval()

    print("FinBERT model loaded successfully!")

   
    id2label = model.config.id2label

    labels = {
        str(
            id2label.get(
                index,
                id2label.get(str(index), f"LABEL_{index}")
            )
        ).lower(): index
        for index in range(model.config.num_labels)
    }

    print("\nModel sentiment labels:")
    print(labels)

    required_labels = {
        "positive",
        "negative",
        "neutral"
    }

    if not required_labels.issubset(labels):
        raise ValueError(
            f"Unexpected FinBERT labels: {labels}"
        )

    _FINBERT_CACHE = (tokenizer, model, device, labels)
    return _FINBERT_CACHE




def analyse_batch(
    news_texts,
    tokenizer,
    model,
    device,
    labels
):

   
    tokenization_started = time.perf_counter()
    inputs = tokenizer(
        news_texts,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=MAX_LENGTH
    )
    tokenization_seconds = time.perf_counter() - tokenization_started

    
    inputs = {
        key: value.to(device)
        for key, value in inputs.items()
    }

   
    inference_started = time.perf_counter()
    with torch.inference_mode():

        outputs = model(**inputs)

        probabilities = torch.softmax(
            outputs.logits,
            dim=-1
        )

    inference_seconds = time.perf_counter() - inference_started
    probabilities = probabilities.cpu().tolist()

    print(
        f"FinBERT batch profile: {len(news_texts)} article(s) | "
        f"tokenization={tokenization_seconds:.3f}s | "
        f"model_inference={inference_seconds:.3f}s"
    )

    results = []

    for article_probabilities in probabilities:

        scores = {
            label: article_probabilities[index]
            for label, index in labels.items()
        }

        positive_score = scores["positive"]
        negative_score = scores["negative"]
        neutral_score = scores["neutral"]

        sentiment = max(
            ("positive", "negative", "neutral"),
            key=lambda label: scores[label]
        )

        sentiment_score = (
            positive_score - negative_score
        )

        results.append({

            "sentiment": sentiment,

            "positive_score": positive_score,

            "negative_score": negative_score,

            "neutral_score": neutral_score,

            "sentiment_score": sentiment_score

        })

    return results



def prepare_news_text(article):

    text = article.get("text_for_analysis")

    # Fallback to cleaned headline.
    if not text or not str(text).strip():

        text = article.get("cleaned_headline")

    # Fallback to original headline.
    if not text or not str(text).strip():

        text = article.get("headline")

    # No usable text.
    if not text or not str(text).strip():

        raise ValueError(
            f"No usable text for article: "
            f"{article.get('article_id')}"
        )

    return str(text)



def analyse_sentiment(
    news_with_tickers_df,
    news_by_ticker_df
):

    print("\n========== STARTING FINBERT SENTIMENT ANALYSIS ==========")

    # Get Spark session from the input DataFrame.
    spark = news_with_tickers_df.sparkSession


    article_collect_started = time.perf_counter()
    news_records = [
        row.asDict(recursive=True)
        for row in news_with_tickers_df.collect()
    ]
    print(
        "Article records collected in "
        f"{time.perf_counter() - article_collect_started:.3f} seconds"
    )

    if not news_records:
        raise ValueError(
            "No news articles available for sentiment analysis."
        )

    print(
        "Total unique articles:",
        len(news_records)
    )

   

    tokenizer, model, device, labels = load_finbert()

 

    news_texts = [
        prepare_news_text(article)
        for article in news_records
    ]

   

    print("\nStarting FinBERT inference...")

    sentiment_results = []

    total_articles = len(news_texts)

    for start in range(
        0,
        total_articles,
        BATCH_SIZE
    ):

        end = min(
            start + BATCH_SIZE,
            total_articles
        )

        batch_texts = news_texts[start:end]

        batch_results = analyse_batch(
            batch_texts,
            tokenizer,
            model,
            device,
            labels
        )

        sentiment_results.extend(batch_results)

        print(
            f"Processed {end}/{total_articles} articles"
        )

   

    news_with_sentiment = []

    for article, sentiment in zip(
        news_records,
        sentiment_results
    ):

        enriched_article = {
            **article,
            **sentiment
        }

        news_with_sentiment.append(
            enriched_article
        )

 

    sentiment_lookup = {
        article["article_id"]: {

            "sentiment": article["sentiment"],

            "positive_score": article["positive_score"],

            "negative_score": article["negative_score"],

            "neutral_score": article["neutral_score"],

            "sentiment_score": article["sentiment_score"]

        }
        for article in news_with_sentiment
    }

   

    ticker_collect_started = time.perf_counter()
    ticker_records = [
        row.asDict(recursive=True)
        for row in news_by_ticker_df.collect()
    ]
    print(
        "Ticker records collected in "
        f"{time.perf_counter() - ticker_collect_started:.3f} seconds"
    )

    news_by_ticker_with_sentiment = []

    for record in ticker_records:

        article_id = record["article_id"]

        sentiment = sentiment_lookup.get(article_id)

        if sentiment is None:

            raise ValueError(
                f"Sentiment missing for article: {article_id}"
            )

        enriched_record = {
            **record,
            **sentiment
        }

        news_by_ticker_with_sentiment.append(
            enriched_record
        )

   

    article_sentiment_df = spark.createDataFrame(
        news_with_sentiment
    )

    if news_by_ticker_with_sentiment:

        ticker_sentiment_df = spark.createDataFrame(
            news_by_ticker_with_sentiment
        )

    else:

        # Preserve the original schema when there are no
        # article-ticker mappings.
        ticker_sentiment_df = (
            news_by_ticker_df
            .withColumn(
                "sentiment",
                F.lit(None).cast(StringType())
            )
            .withColumn(
                "positive_score",
                F.lit(None).cast(DoubleType())
            )
            .withColumn(
                "negative_score",
                F.lit(None).cast(DoubleType())
            )
            .withColumn(
                "neutral_score",
                F.lit(None).cast(DoubleType())
            )
            .withColumn(
                "sentiment_score",
                F.lit(None).cast(DoubleType())
            )
        )

 
    print("\\n========== ARTICLE-LEVEL FINBERT RESULTS ==========")
    for article in news_with_sentiment:
        print(f"Article ID       : {article.get('article_id', '')}")
        print(f"Headline         : {article.get('cleaned_headline') or article.get('headline', '')}")
        tickers = article.get('matched_tickers') or []
        if isinstance(tickers, str):
            tickers = [tickers]
        print(f"Matched tickers  : {', '.join(tickers)}")
        print(f"Sentiment        : {str(article.get('sentiment', '')).upper()}")
        print(f"Positive score   : {article.get('positive_score', 0.0):.4f}")
        print(f"Negative score   : {article.get('negative_score', 0.0):.4f}")
        print(f"Neutral score    : {article.get('neutral_score', 0.0):.4f}")
        print(f"Sentiment score  : {article.get('sentiment_score', 0.0):.4f}")
        print("-" * 72)

    print("\\n========== TICKER-LEVEL FINBERT RESULTS ==========")
    print(f"{'Ticker':<18} {'Sentiment':<12} {'Score':>12}")
    for record in news_by_ticker_with_sentiment:
        print(
            f"{str(record.get('ticker', '')):<18} "
            f"{str(record.get('sentiment', '')).upper():<12} "
            f"{float(record.get('sentiment_score') or 0.0):>12.4f}"
        )

    

    print("\n========================================")
    print("FINBERT SENTIMENT ANALYSIS COMPLETED")
    print("========================================")

    print(
        "Articles processed:",
        len(news_with_sentiment)
    )

    print(
        "Article-ticker records:",
        len(news_by_ticker_with_sentiment)
    )

    print("\nSentiment analysis completed successfully.")

    # Return both DataFrames to the main pipeline.
    return (
        article_sentiment_df,
        ticker_sentiment_df
    )