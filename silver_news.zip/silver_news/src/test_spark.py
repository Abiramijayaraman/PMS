import os
import sys
 
os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable
from pyspark.sql import SparkSession
 

spark = SparkSession.builder \
    .appName("SilverNewsTest") \
    .master("local[*]") \
    .getOrCreate()
 

data = [
    (1, "Reliance shares rise today"),
    (2, "TCS announces strong quarterly results"),
    (3, "Infosys expands its AI business")
]
 
columns = ["article_id", "headline"]
 
df = spark.createDataFrame(data, columns)
 

df.show()

spark.stop()