
import hashlib
import sys
import os
from pathlib import Path

# --------------------------------------------------
# 1. PYSPARK CONFIGURATION FOR WINDOWS
# --------------------------------------------------

os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable


# --------------------------------------------------
# 2. IMPORT REQUIRED MODULES
# --------------------------------------------------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim, lit

from read_bronze import read_new_bronze

from deduplicate_news import (
    deduplicate_news,
    semantic_deduplicate_news
)

from validate_news import validate_news
from clean_news import clean_news
from extract_tickers import extract_tickers
from sentiment_analysis import analyse_sentiment

from checkpoint_manager import (
    load_processed_files,
    save_processed_files,
    load_processed_article_ids,
    save_processed_article_ids
)

from safe_output_writer import (
    write_batch_outputs,
    create_commit_marker,
    recover_checkpoints
)


# --------------------------------------------------
# 3. GENERATE A STABLE BATCH ID
# --------------------------------------------------

def generate_batch_id(bronze_files):

    filenames = sorted(
        Path(file).name
        for file in bronze_files
    )

    file_string = "|".join(filenames)

    batch_hash = hashlib.sha256(
        file_string.encode("utf-8")
    ).hexdigest()[:16]

    return f"batch_{batch_hash}"


# --------------------------------------------------
# 4. GET ARTICLE IDS FROM A DATAFRAME
# --------------------------------------------------

def get_article_ids(news_df):

    if news_df is None:
        return set()

    rows = (
        news_df
        .select("article_id")
        .where(
            col("article_id").isNotNull()
            & (trim(col("article_id")) != "")
        )
        .distinct()
        .collect()
    )

    return {
        row["article_id"]
        for row in rows
    }


# --------------------------------------------------
# 5. ADD EMPTY SENTIMENT COLUMNS
# --------------------------------------------------

def add_empty_sentiment_columns(dataframe):

    sentiment_columns = {
        "sentiment": "string",
        "positive_score": "double",
        "negative_score": "double",
        "neutral_score": "double",
        "sentiment_score": "double"
    }

    for column_name, data_type in sentiment_columns.items():

        if column_name not in dataframe.columns:

            dataframe = dataframe.withColumn(
                column_name,
                lit(None).cast(data_type)
            )

    return dataframe


# --------------------------------------------------
# 6. MAIN SILVER PIPELINE
# --------------------------------------------------

def run_silver_pipeline():

    print("\n")
    print("================================================")
    print("          STARTING SILVER NEWS PIPELINE")
    print("================================================")

    spark = (
        SparkSession.builder
        .appName("SilverNewsPipeline")
        .master("local[*]")
        .getOrCreate()
    )

    try:

        # ------------------------------------------
        # STEP 1: RECOVER CHECKPOINTS
        # ------------------------------------------

        print("\n========== STEP 1: CHECKPOINT RECOVERY ==========")

        recover_checkpoints()

        # ------------------------------------------
        # STEP 2: READ NEW BRONZE FILES
        # ------------------------------------------

        print("\n========== STEP 2: READ BRONZE ==========")

        news_df, new_files = read_new_bronze(spark)

        if not new_files:

            print("\nNo new Bronze files found.")
            print("Nothing to process.")

            return

        bronze_filenames = sorted(
            Path(file).name
            for file in new_files
        )

        print("New Bronze files:", len(bronze_filenames))

        for filename in bronze_filenames:
            print(" -", filename)

        batch_id = generate_batch_id(bronze_filenames)

        print("\nBatch ID:", batch_id)

        # ------------------------------------------
        # STEP 3: HANDLE EMPTY BRONZE FILES
        # ------------------------------------------

        if news_df is None:

            print("\nNo records found in the new Bronze files.")

            create_commit_marker(
                batch_id=batch_id,
                bronze_files=bronze_filenames,
                processed_article_ids=[]
            )

            recover_checkpoints()

            print("Empty batch committed successfully.")

            return

        # ------------------------------------------
        # STEP 4: ARTICLE-LEVEL EXACT DEDUPLICATION
        # ------------------------------------------

        print("\n========== STEP 3: EXACT DEDUPLICATION ==========")

        unique_new_df, missing_id_df = deduplicate_news(
            news_df
        )

        # Keep missing-ID records so validation can
        # route them to the DLQ.

        candidates_df = unique_new_df.unionByName(
            missing_id_df,
            allowMissingColumns=True
        )

        candidate_count = candidates_df.count()

        print("Records proceeding to validation:", candidate_count)

        # Collect IDs before validation.
        # They will only be checkpointed after a successful commit.

        batch_article_ids = get_article_ids(candidates_df)

        # ------------------------------------------
        # STEP 5: VALIDATION
        # ------------------------------------------

        print("\n========== STEP 4: VALIDATION ==========")

        valid_df, invalid_df = validate_news(
            candidates_df
        )

        valid_count = valid_df.count()
        invalid_count = invalid_df.count()

        print("Valid articles:", valid_count)
        print("Invalid articles:", invalid_count)

        # ------------------------------------------
        # STEP 6: HTML CLEANING
        # ------------------------------------------

        print("\n========== STEP 5: HTML CLEANING ==========")

        cleaned_df = clean_news(valid_df)

        # ------------------------------------------
        # STEP 7: TICKER EXTRACTION
        # ------------------------------------------

        print("\n========== STEP 6: TICKER EXTRACTION ==========")

        (
            news_with_tickers_df,
            news_by_ticker_df
        ) = extract_tickers(cleaned_df)

        # ------------------------------------------
        # STEP 8: SEMANTIC DEDUPLICATION
        # ------------------------------------------

        print("\n========== STEP 7: SEMANTIC DEDUPLICATION ==========")

        (
            unique_news_df,
            semantic_duplicates_df
        ) = semantic_deduplicate_news(
            news_with_tickers_df
        )

        unique_count = unique_news_df.count()
        duplicate_count = semantic_duplicates_df.count()

        print("Articles after semantic deduplication:", unique_count)
        print("Semantic duplicates detected:", duplicate_count)

        # ------------------------------------------
        # KEEP TICKER MAPPINGS FOR UNIQUE ARTICLES
        # ------------------------------------------

        unique_article_ids = (
            unique_news_df
            .select("article_id")
            .distinct()
        )

        unique_news_by_ticker_df = (
            news_by_ticker_df
            .join(
                unique_article_ids,
                on="article_id",
                how="inner"
            )
        )

        print(
            "Unique article-ticker mappings:",
            unique_news_by_ticker_df.count()
        )

        # ------------------------------------------
        # STEP 9: FINBERT SENTIMENT ANALYSIS
        # ------------------------------------------

        print("\n========== STEP 9: FINBERT SENTIMENT ==========")

        if unique_count > 0:

            (
                news_with_sentiment_df,
                news_by_ticker_with_sentiment_df
            ) = analyse_sentiment(
                unique_news_df,
                unique_news_by_ticker_df
            )

        else:

            print("No unique articles. Skipping FinBERT.")

            news_with_sentiment_df = (
                add_empty_sentiment_columns(
                    unique_news_df
                )
            )

            news_by_ticker_with_sentiment_df = (
                add_empty_sentiment_columns(
                    unique_news_by_ticker_df
                )
            )

        # ------------------------------------------
        # STEP 10: WRITE SILVER AND DLQ OUTPUTS
        # ------------------------------------------

        print("\n========== STEP 9: WRITE OUTPUTS ==========")

        committed = write_batch_outputs(
            batch_id=batch_id,
            news_with_sentiment_df=news_with_sentiment_df,
            news_by_ticker_with_sentiment_df=news_by_ticker_with_sentiment_df,
            invalid_df=invalid_df,
            bronze_files=bronze_filenames,
            processed_article_ids=batch_article_ids
        )

        # ------------------------------------------
        # STEP 11: UPDATE CHECKPOINTS
        # ------------------------------------------

        print("\n========== STEP 10: UPDATE CHECKPOINTS ==========")

        if committed:

            processed_files = load_processed_files()

            processed_files.update(
                bronze_filenames
            )

            save_processed_files(
                processed_files
            )

            processed_ids = load_processed_article_ids()

            processed_ids.update(
                batch_article_ids
            )

            save_processed_article_ids(
                processed_ids
            )

            print("Checkpoint files updated successfully.")

        else:

            print("Batch already committed.")

            recover_checkpoints()

        # ------------------------------------------
        # STEP 12: FINAL SUMMARY
        # ------------------------------------------

        print("\n")
        print("================================================")
        print("          SILVER NEWS PIPELINE COMPLETED")
        print("================================================")

        print("Batch ID:", batch_id)
        print("Bronze files processed:", len(bronze_filenames))
        print("Articles considered:", candidate_count)
        print("Valid articles:", valid_count)
        print("Invalid articles:", invalid_count)
        print("Semantic duplicates:", duplicate_count)
        print("Unique articles:", unique_count)
        print("Article IDs checkpointed:", len(batch_article_ids))

    except Exception as error:

        print("\n")
        print("================================================")
        print("          SILVER NEWS PIPELINE FAILED")
        print("================================================")

        print("Error:", str(error))

        raise

    finally:

        spark.stop()

        print("\nSpark session stopped.")


# --------------------------------------------------
# 13. EXECUTE PIPELINE
# --------------------------------------------------

if __name__ == "__main__":

    run_silver_pipeline()